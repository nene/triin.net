# HTTP 1.0 and 1.1 status codes.
# Taken from RFC 2616:
# http://www.ietf.org/rfc/rfc2616.txt
#
# Also found from in Wikipedia:
# http://en.wikipedia.org/wiki/List_of_HTTP_status_codes

INSERT INTO http_statuses
    (http_status_code, http_status_phrase)

VALUES
    # 1xx Informational
    ('100', 'Continue'),
    ('101', 'Switching Protocols'),

    # 2xx Success
    ('200', 'OK'),
    ('201', 'Created'),
    ('202', 'Accepted'),
    ('203', 'Non-Authoritative Information'),
    ('204', 'No Content'),
    ('205', 'Reset Content'),
    ('206', 'Partial Content'),

    # 3xx Redirection
    ('300', 'Multiple Choices'),
    ('301', 'Moved Permanently'),
    # The first phrase is for HTTP/1.0, the second for HTTP/1.1
    ('302', 'Moved Temporarily / Found'),
    ('303', 'See Other '), # HTTP/1.1 only
    ('304', 'Not Modified'),
    ('305', 'Use Proxy'),
    ('306', '(unused, but reserved)'),
    ('307', 'Temporary Redirect'),

    # 4xx Client Error
    ('400', 'Bad Request'),
    ('401', 'Unauthorized'),
    ('402', 'Payment Required'),
    ('403', 'Forbidden'),
    ('404', 'Not Found'),
    ('405', 'Method Not Allowed'),
    ('406', 'Not Acceptable'),
    ('407', 'Proxy Authentication Required'),
    ('408', 'Request Timeout'),
    ('409', 'Conflict'),
    ('410', 'Gone'),
    ('411', 'Length Required'),
    ('412', 'Precondition Failed'),
    ('413', 'Request Entity Too Large'),
    ('414', 'Request-URI Too Long'),
    ('415', 'Unsupported Media Type'),
    ('416', 'Requested Range Not Satisfiable'),
    ('417', 'Expectation Failed'),

    # 5xx Server Error
    ('500', 'Internal Server Error'),
    ('501', 'Not Implemented'),
    ('502', 'Bad Gateway'),
    ('503', 'Service Unavailable'),
    ('504', 'Gateway Timeout'),
    ('505', 'HTTP Version Not Supported'),
    ('509', 'Bandwidth Limit Exceeded');





