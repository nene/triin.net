
# The main table which stores all the webpages,
# that we are going to visit.
DROP TABLE IF EXISTS webpages;
CREATE TABLE webpages (
    webpage_id       INTEGER        NOT NULL    PRIMARY KEY     AUTO_INCREMENT,
    webpage_uri      VARCHAR(255)   NOT NULL    UNIQUE       # URI-s can be larger than 255 characters,
        COMMENT 'Address of the webpage',                    # but we ignore uris longer than 255
    http_version     ENUM('1.0','1.1')  NULL
        COMMENT 'Version of HTTP protocol',

    webpage_filesize INTEGER            NULL
        COMMENT 'Number of bytes in downloaded HTML file',
    webpage_textsize INTEGER            NULL
        COMMENT 'Amount of text content in HTML file',
    webpage_commentsize INTEGER         NULL
        COMMENT 'Size of all comments in HTML file',
    webpage_html_error_count INTEGER   NULL
        COMMENT 'Count of validation errors encountered during validating HTML of this page',

    webpage_css_inline_size INTEGER     NULL
        COMMENT 'Size of inline styles in HTML file',
    webpage_css_embedded_size INTEGER   NULL
        COMMENT 'Size of embedded styles in HTML file',
    webpage_css_external_size INTEGER   NULL
        COMMENT 'Size of all external stylesheets',
    webpage_css_external_count INTEGER   NULL
        COMMENT 'Count of all external stylesheets',
    webpage_css_comment_size INTEGER    NULL
        COMMENT 'Size of all CSS comments',
    webpage_css_important_count INTEGER NULL
        COMMENT 'Number of !important keywords in stylesheets',
    webpage_css_parse_error_count INTEGER   NULL
        COMMENT 'Count of parse error encountered during parsing CSS files of this page',
    webpage_css_error_count INTEGER   NULL
        COMMENT 'Count of validation errors encountered during validating CSS of this page',

    webpage_javascript_inline_size INTEGER     NULL
        COMMENT 'Size of inline JavaScript in HTML file',
    webpage_javascript_embedded_size INTEGER   NULL
        COMMENT 'Size of embedded JavaScript in HTML file',
    webpage_javascript_external_size INTEGER   NULL
        COMMENT 'Size of all external JavaScript files',
    webpage_javascript_external_count INTEGER   NULL
        COMMENT 'Count of all external JavaScript files',
    webpage_javascript_xml_http_request ENUM('Y','N')  NULL
        COMMENT 'Weather the page uses AJAX or not',
    webpage_javascript_comment_size INTEGER    NULL
        COMMENT 'Size of all JavaScript comments',

    encoding_id      INTEGER            NULL
        REFERENCES encodings,
    doctype_id       INTEGER            NULL
        REFERENCES doctypes,
    xml_prolog_id    INTEGER            NULL
        REFERENCES xml_prologs,
    http_status_code INTEGER            NULL
        REFERENCES http_statuses
)
engine=MyISAM
avg_row_length=125 # 4*22 + 35+1 + 1
MIN_ROWS=4000000
MAX_ROWS=5000000  # maximum table size ~500 MB
;

# Character encodings
DROP TABLE IF EXISTS encodings;
CREATE TABLE encodings (
    encoding_id      INTEGER        NOT NULL    PRIMARY KEY     AUTO_INCREMENT,
    encoding_name    VARCHAR(255)   NOT NULL    UNIQUE
        COMMENT 'Name of the encoding'
);

# DOCTYPEs
DROP TABLE IF EXISTS doctypes;
CREATE TABLE doctypes (
    doctype_id       INTEGER               NOT NULL    PRIMARY KEY     AUTO_INCREMENT,
    root_element     VARCHAR(50)  BINARY   NOT NULL
        COMMENT 'Root element name', # Case sensitive
    doctype_fpi      VARCHAR(200) BINARY   NOT NULL
        COMMENT 'Formal Public Identifier', # Case sensitive
    doctype_si       VARCHAR(200) BINARY   NOT NULL
        COMMENT 'System Identifier (URI)' # Case sensitive
);
CREATE UNIQUE INDEX doctypes_index
ON doctypes (root_element, doctype_fpi, doctype_si);


# XML Processing Instructions
DROP TABLE IF EXISTS xml_prologs;
CREATE TABLE xml_prologs (
    xml_prolog_id    INTEGER        NOT NULL    PRIMARY KEY     AUTO_INCREMENT,
    xml_version      VARCHAR(10)    NOT NULL
        COMMENT 'XML version number',
    encoding_id      INTEGER        NULL
        REFERENCES encodings
);
CREATE UNIQUE INDEX xml_prolog_index
ON xml_prologs (xml_version, encoding_id);



################################################################################
#
# HTTP headers
#
################################################################################

# Stores HTTP headers, associated with given page.
# linking table: webpages <--> header_contents
DROP TABLE IF EXISTS webpage_header_contents;
CREATE TABLE webpage_header_contents (
    webpage_id           INTEGER      NOT NULL
        REFERENCES webpages,
    header_content_id    INTEGER      NOT NULL
        REFERENCES header_contents
)
engine=MyISAM
avg_row_length=8  # 4 + 4
MIN_ROWS=40000000
MAX_ROWS=50000000 # maximum table size ~380 MB
;

# This table is exactly the same as previous,
# but instead of storing data about real HTTP headers,
# data from <meta http-equiv's is stored here.
# linking table: webpages <--> header_contents
DROP TABLE IF EXISTS webpage_http_equivs;
CREATE TABLE webpage_http_equivs (
    webpage_id           INTEGER      NOT NULL
        REFERENCES webpages,
    header_content_id    INTEGER      NOT NULL
        REFERENCES header_contents
)
engine=MyISAM
avg_row_length=8  # 4 + 4 + 4
MIN_ROWS=6000000
MAX_ROWS=7500000 # maximum table size ~60 MB
;

# stores values associated to HTTP headers
DROP TABLE IF EXISTS header_contents;
CREATE TABLE header_contents (
    header_content_id    INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    header_content_value VARCHAR(255) NOT NULL     # empty string (''), when not meant to store in db
        COMMENT 'Content of HTTP header',
    header_id            INTEGER      NOT NULL
        REFERENCES headers
);

# The header_content_value - header_id pairs in the above table must be uniqe.
# That's why we create a unique index for those.
CREATE UNIQUE INDEX header_contents_index
ON header_contents (header_content_value, header_id);


# stores HTTP header names
DROP TABLE IF EXISTS headers;
CREATE TABLE headers (
    header_id            INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    header_name          VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'HTTP header name'
);

# Stores HTTP status lines.
# We don't need artificial PK in this table,
# because we can use the status code itself
# (thatswhy there's also no AUTO_INCREMENT).
DROP TABLE IF EXISTS http_statuses;
CREATE TABLE http_statuses (
    http_status_code     INTEGER      NOT NULL  PRIMARY KEY
        COMMENT 'HTTP status code',
    http_status_phrase   VARCHAR(50)  NOT NULL
        COMMENT 'HTTP reason phrase'
);


################################################################################
#
# HTML elements and attributes
#
################################################################################

# linking table: webpages <--> html_elements
DROP TABLE IF EXISTS webpage_html_elements;
CREATE TABLE webpage_html_elements (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    html_element_id                 INTEGER      NOT NULL
        REFERENCES html_elements,
    webpage_html_element_count      INTEGER      NOT NULL
        COMMENT 'Count of this kind of elements'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=48000000
MAX_ROWS=60000000  # maximum table size ~700 MB
;


# HTML element names
DROP TABLE IF EXISTS html_elements;
CREATE TABLE html_elements (
    html_element_id                 INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    html_element_name               VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'HTML element name'
);



# linking table: webpages <--> html_element_attributes
DROP TABLE IF EXISTS webpage_html_element_attributes;
CREATE TABLE webpage_html_element_attributes (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    html_element_attribute_id       INTEGER      NOT NULL
        REFERENCES html_element_attributes,
    webpage_html_element_attribute_count INTEGER NOT NULL
        COMMENT 'Count of this kind of attributes'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=48000000
MAX_ROWS=120000000 # maximum table size ~1373 MB
;
-- Selle tabeli MAX_ROWS on oletuslik
-- testid peavad veel näitama, milline arv oleks sobilik


# linking table: html_elements <--> html_attributes
DROP TABLE IF EXISTS html_element_attributes;
CREATE TABLE html_element_attributes (
    html_element_attribute_id       INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    html_element_id                 INTEGER      NOT NULL
        REFERENCES html_elements,
    html_attribute_id               INTEGER      NOT NULL
        REFERENCES html_attributes
);
CREATE UNIQUE INDEX html_element_attributes_index
ON html_element_attributes (html_element_id, html_attribute_id);

# HTML attribute names
DROP TABLE IF EXISTS html_attributes;
CREATE TABLE html_attributes (
    html_attribute_id               INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    html_attribute_name             VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'HTML attribute name'
);




# linking table: webpages <--> html_element_attribute_values
DROP TABLE IF EXISTS webpage_html_element_attribute_values;
CREATE TABLE webpage_html_element_attribute_values (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    html_element_attribute_value_id INTEGER      NOT NULL
        REFERENCES html_element_attribute_values,
    webpage_html_element_attribute_value_count INTEGER NOT NULL
        COMMENT 'Count of this kind of attribute values'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=48000000
MAX_ROWS=240000000 # maximum table size ~2747 MB or ~2.7 GB
;


# linking table: html_element_attributes <--> html_attribute_values
DROP TABLE IF EXISTS html_element_attribute_values;
CREATE TABLE html_element_attribute_values (
    html_element_attribute_value_id INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    html_element_attribute_id       INTEGER      NOT NULL
        REFERENCES html_element_attributes,
    html_attribute_value_id         VARCHAR(255) NOT NULL
        REFERENCES html_attribute_values
);
CREATE UNIQUE INDEX html_element_attribute_values_index
ON html_element_attribute_values (html_element_attribute_id, html_attribute_value_id);

# HTML attribute values
DROP TABLE IF EXISTS html_attribute_values;
CREATE TABLE html_attribute_values (
    html_attribute_value_id         INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    html_attribute_value_value      VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'HTML attribute value'
);




################################################################################
#
# CSS selectors
#
################################################################################

# linking table: webpages <--> css_selector_types
DROP TABLE IF EXISTS webpage_css_selector_types;
CREATE TABLE webpage_css_selector_types (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    css_selector_type_id            INTEGER      NOT NULL
        REFERENCES css_selector_types,
    webpage_css_selector_type_count INTEGER      NOT NULL
        COMMENT 'Count of this kind of selector'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=20000000
MAX_ROWS=25000000 # maximum table size ~300 MB
;

# Different types of CSS selectors, for example:
# UNIVERSAL_SELECTOR, CHILD_SELECTOR, CLASS_SELECTOR...
DROP TABLE IF EXISTS css_selector_types;
CREATE TABLE css_selector_types (
    css_selector_type_id            INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    css_selector_type_name          VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'CSS selector name'
);



# Selectors of type ELEMENT_NODE_SELECTOR selecting different HTML elements
# linking table: webpages <--> html_elements
DROP TABLE IF EXISTS webpage_html_element_selectors;
CREATE TABLE webpage_html_element_selectors (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    html_element_id                 INTEGER      NOT NULL
        REFERENCES html_elements,
    webpage_html_element_selector_count INTEGER  NOT NULL
        COMMENT 'Count of this kind of selector'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=24000000
MAX_ROWS=30000000 # maximum table size ~350 MB
;


# Stores selector parameters of webpages
# linking table: webpages <--> css_selector_parameters
DROP TABLE IF EXISTS webpage_css_selector_parameters;
CREATE TABLE webpage_css_selector_parameters (
    webpage_id                          INTEGER       NOT NULL
        REFERENCES webpages,
    css_selector_parameter_id           INTEGER       NOT NULL
        REFERENCES css_selector_parameters,
    webpage_css_selector_parameter_count INTEGER      NOT NULL
        COMMENT 'Count of CSS selector parameter'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=6000000
MAX_ROWS=7500000 # maximum table size ~85 MB
;

# Stores selector parameters, for example:
# [href^="?"], :unknown-pseudoclass, :nth-child(28)
DROP TABLE IF EXISTS css_selector_parameters;
CREATE TABLE css_selector_parameters (
    css_selector_parameter_id           INTEGER       NOT NULL  PRIMARY KEY  AUTO_INCREMENT,
    css_selector_parameter_name         VARCHAR(255)  NOT NULL
        COMMENT 'Name/value of CSS selector parameter'
);


# Stores names of classes from CSS class selectors
# Note! This table is not at all connected to webpages table,
# because we only store the number of pages, the classname is in.
DROP TABLE IF EXISTS css_class_selectors;
CREATE TABLE css_class_selectors (
    css_class_selector_name VARCHAR(255) NOT NULL   PRIMARY KEY
        COMMENT 'Name of class',
    css_class_selector_pagecount INTEGER NOT NULL   DEFAULT '0'
        COMMENT 'Number of pages containing this classname'
)
engine=MyISAM
avg_row_length=12  # 4 + 10
MIN_ROWS=20000000
MAX_ROWS=25000000 # maximum table size ~333 MB
;


# Stores names of ID-s from CSS ID selectors
# Note! This table is not at all connected to webpages table,
# because we only store the number of pages, the ID name is in.
DROP TABLE IF EXISTS css_id_selectors;
CREATE TABLE css_id_selectors (
    css_id_selector_name    VARCHAR(255) NOT NULL   PRIMARY KEY
        COMMENT 'Name of ID',
    css_id_selector_pagecount INTEGER NOT NULL   DEFAULT '0'
        COMMENT 'Number of pages containing this ID name'
)
engine=MyISAM
avg_row_length=14  # 4 + 10
MIN_ROWS=4000000
MAX_ROWS=5000000 # maximum table size ~66 MB
;




################################################################################
#
# CSS properties and values
#
################################################################################

# linking table: webpages <--> css_properties
DROP TABLE IF EXISTS webpage_css_properties;
CREATE TABLE webpage_css_properties (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    css_property_id                 INTEGER      NOT NULL
        REFERENCES css_properties,
    webpage_css_property_count      INTEGER      NOT NULL
        COMMENT 'Count of this kind of property'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=68000000
MAX_ROWS=85000000 # maximum table size ~1000 MB
;

# CSS property names
DROP TABLE IF EXISTS css_properties;
CREATE TABLE css_properties (
    css_property_id                 INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    css_property_name               VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'CSS property name'
);





# linking table: webpages <--> css_property_values
DROP TABLE IF EXISTS webpage_css_property_values;
CREATE TABLE webpage_css_property_values (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    css_property_value_id           INTEGER      NOT NULL
        REFERENCES css_property_values,
    webpage_css_property_value_count  INTEGER    NOT NULL
        COMMENT 'Count of this kind of unit'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=120000000
MAX_ROWS=150000000 # maximum table size ~1716 MB
;

# linking table: css_properties <--> css_values
# This table stores <property:value> pairs of CSS.
DROP TABLE IF EXISTS css_property_values;
CREATE TABLE css_property_values (
    css_property_value_id           INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    css_property_id                 INTEGER      NOT NULL
        REFERENCES css_properties,
    css_value_id                    INTEGER      NOT NULL
        REFERENCES css_values
);
CREATE UNIQUE INDEX css_property_values_index
ON css_property_values (css_property_id, css_value_id);

# CSS property values
#
# fonts, image types, colors, "inherit"...
#
DROP TABLE IF EXISTS css_values;
CREATE TABLE css_values (
    css_value_id                    INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    css_value_value                 VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'CSS value name'
);




################################################################################
#
# CSS at-rules
#
################################################################################

# linking table: webpages <--> css_at_rules
DROP TABLE IF EXISTS webpage_css_at_rules;
CREATE TABLE webpage_css_at_rules (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    css_at_rule_id                  INTEGER      NOT NULL
        REFERENCES css_at_rules,
    webpage_css_at_rule_count       INTEGER      NOT NULL
        COMMENT 'Count of this kind of @rule'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=6000000
MAX_ROWS=7500000 # maximum table size ~85 MB
;

# CSS @rules
#
# @import, @media, @page, @charset ...
#
DROP TABLE IF EXISTS css_at_rules;
CREATE TABLE css_at_rules (
    css_at_rule_id                  INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    css_at_rule_name                VARCHAR(200) NOT NULL
        COMMENT 'CSS @rule name',
    css_at_rule_parameters          VARCHAR(200) NOT NULL
        COMMENT 'CSS @rule parameters'
);
CREATE UNIQUE INDEX css_at_rules_index
ON css_at_rules (css_at_rule_name, css_at_rule_parameters);




################################################################################
#
# JavaScript elements
#
################################################################################

# linking table: webpages <--> javascript_elements
DROP TABLE IF EXISTS webpage_javascript_elements;
CREATE TABLE webpage_javascript_elements (
    webpage_id                            INTEGER      NOT NULL
        REFERENCES webpages,
    javascript_element_id                 INTEGER      NOT NULL
        REFERENCES javascript_elements,
    webpage_javascript_element_count      INTEGER      NOT NULL
        COMMENT 'Count of this kind of element'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=64000000
MAX_ROWS=80000000 # maximum table size ~920 MB
;

# JavaScript elements
DROP TABLE IF EXISTS javascript_elements;
CREATE TABLE javascript_elements (
    javascript_element_id                 INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    javascript_element_name               VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'JavaScript element'
);


################################################################################
#
# Validation errors
#
################################################################################

# linking table: webpages <--> html_errors
DROP TABLE IF EXISTS webpage_html_errors;
CREATE TABLE webpage_html_errors (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    html_error_id                   INTEGER      NOT NULL
        REFERENCES html_errors,
    webpage_html_error_count        INTEGER      NOT NULL
        COMMENT 'Count of this kind of error message'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=24000000
MAX_ROWS=30000000  # maximum table size ~350 MB
;


# HTML Validator error messages
DROP TABLE IF EXISTS html_errors;
CREATE TABLE html_errors (
    html_error_id                   INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    html_error_name                 VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'HTML Validator error message'
);



# linking table: webpages <--> css_errors
DROP TABLE IF EXISTS webpage_css_errors;
CREATE TABLE webpage_css_errors (
    webpage_id                      INTEGER      NOT NULL
        REFERENCES webpages,
    css_error_id                    INTEGER      NOT NULL
        REFERENCES css_errors,
    webpage_css_error_count         INTEGER      NOT NULL
        COMMENT 'Count of this kind of error message'
)
engine=MyISAM
avg_row_length=12  # 4 + 4 + 4
MIN_ROWS=7600000
MAX_ROWS=9500000  # maximum table size ~100 MB
;

# CSS Validator error messages
DROP TABLE IF EXISTS css_errors;
CREATE TABLE css_errors (
    css_error_id                    INTEGER      NOT NULL  PRIMARY KEY     AUTO_INCREMENT,
    css_error_name                  VARCHAR(255) NOT NULL  UNIQUE
        COMMENT 'CSS Validator error message'
);
















