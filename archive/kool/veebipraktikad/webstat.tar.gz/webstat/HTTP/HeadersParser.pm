package HTTP::HeadersParser;

use warnings;
use strict;

use vars qw(
    $RE_HTTP_TOKEN
    $RE_HTTP_STATUS_LINE
    $RE_HTTP_HEADER_LINE
);


# Token is any character from ASCII range 32-126,
# except separators     = "(" | ")" | "<" | ">" | "@"
#                       | "," | ";" | ":" | "\" | <">
#                       | "/" | "[" | "]" | "?" | "="
#                       | "{" | "}" | SPACE | TAB
$RE_HTTP_TOKEN = qr{[0-9A-Za-z!#$%&'*+-.^_`|~]};

$RE_HTTP_STATUS_LINE = qr{
    ^
    HTTP                # Protocol name
    /
    ([0-9]+\.[0-9]+)    # Version number            $1
    \s+
    ([0-9]{3})          # Status code               $2

    (?:\s+
        (\S.*)          # Optional Reason phrase    $3
    )?

    $
}xs;

$RE_HTTP_HEADER_LINE = qr{
    ^
    ($RE_HTTP_TOKEN+)   # Header name               $1
    \s*
    :                   # Separator
    \s*
    (.*)?               # Header value              $2
    $
}xs;


# constructor
sub new {
    my $type = shift;
    my $options = shift || {};

    my $self = bless {}, $type;

    # set error handler
    $self->{_eh_} = $options->{ErrorHandler}     || HTTP::HeadersParser::DefaultErrorHandler->new;

    #set document handler
    $self->{_dh_can_} = {};
    $self->set_document_handler($options->{DocumentHandler}) if $options->{DocumentHandler};

    return $self;
}


# set the document handler
sub set_document_handler {
    my $self = shift;
    my $dh = shift;

    # set the doc handler, and see what it can do
    if ($dh) {
        $self->{_dh_} = $dh;

        my @dh_methods = qw(
            header_line
            status_line
        );

        for my $method (@dh_methods) {
            $self->{_dh_can_}->{$method} = $dh->can($method);
        }
    }

    return $self->{_dh_};
}


# takes a string containing HTTP headers
# and parses it
sub parse_header_string {
    my $self = shift;
    my $headers = shift;

    # trim whitespace from the beginning and end
    $headers =~ s/^\s+//;
    $headers =~ s/\s+$//;

    # split the single multiline string into an array of strings
    my @header_list = split(m{\r\n|\r|\n}, $headers);

    # and pass it to another routine
    $self->parse_header_list( \@header_list );
}


# takes a reference to array containing HTTP header lines
# and parses those
sub parse_header_list {
    my $self = shift;
    my $header_list = shift;

    foreach my $header_line ( @{$header_list} ) {
        $self->parse_header_line( $header_line );
    }
}


# takes a single string containing HTTP header line
# and parses it
sub parse_header_line {
    my $self = shift;
    my $header_line = shift;

    # remove whitespace from beginning and end
    $header_line =~ s/^\s+//;
    $header_line =~ s/\s+$//;

    if ($header_line =~ m{^HTTP/}) {
        # if header-line starts with HTTP and slash,
        # then assume, it's a HTTP status line and parse accordingly
        $self->parse_status_line($header_line);
    }
    else {
        # if it's not a status line,
        # then process it as normal HTTP header
        $self->parse_regular_header_line($header_line);
    }
}


# parse HTTP Status line
sub parse_status_line {
    my $self = shift;
    my $status_line = shift;

    # split to split the status line into parts
    if ( $status_line =~ m{$RE_HTTP_STATUS_LINE} ) {
        my $http_version = $1;
        my $http_status_code = $2;
        my $http_reason_phrase = $3 || "";

        # Raise appropriate event, if possible
        if ( $self->{_dh_can_}->{status_line} ) {
            $self->{_dh_}->status_line($http_version, $http_status_code, $http_reason_phrase);
        }
    }
    else {
        # if this was not a correct status line, then raise error
        $self->{_eh_}->fatal_error("Invalid HTTP status line. '$status_line'");
    }
}


# parse regular HTTP header line
sub parse_regular_header_line {
    my $self = shift;
    my $header_line = shift;

    # try to split the header line into parts
    if ( $header_line =~ m{$RE_HTTP_HEADER_LINE} ) {
        my $http_header_name = $1;
        my $http_header_value = $2;

        # Raise appropriate event, if possible
        if ( $self->{_dh_can_}->{header_line} ) {
            $self->{_dh_}->header_line($http_header_name, $http_header_value);
        }
    }
    else {
        # if this was not a correct header line, then raise error
        $self->{_eh_}->error("Invalid HTTP header.");
    }
}




# This is pretty much a non package, it is just there to provide the
# default error handler.

package HTTP::HeadersParser::DefaultErrorHandler;

use warnings;
use strict;

sub new {
    my $type = shift;
    return bless {}, $type;
}

sub error {
    warn "[error] $_[1] (line " . (caller)[2] . ")";
}

sub fatal_error {
    die "[fatal] $_[1] (line " . (caller)[2] . ")";
}


1;


=pod

=head1 NAME

HttpHeaders::Parser - HTTP headers parser

=head1 SYNOPSIS

  use HTTP::HeadersParser;
  use My::HttpHandler;
  use My::HttpErrors;
  
  my $doc_handler = My::HttpHandler->new;
  my $err_handler = My::HttpErrors->new;
  
  my $parser = HTTP::HeadersParser->new({
                                         DocumentHandler => $doc_handler,
                                         ErrorHandler => $err_handler,
                                       });
  
  my $headers = "
                 HTTP/1.1 200 OK
                 Server: Apache/1.3.26 (Unix)
                 Content-Language: en
                 Content-type: text/html; charset=iso-8859-1
                 X-Powered-By: PHP/4.4.0-gentoo-r1
                 Date: Wed, 15 Mar 2006 11:10:05 GMT
                ";
  
  # generate a stream of events
  $parser->parse_header_string( $headers );

=head1 DESCRIPTION

Simple module for parsing HTTP headers.

=head1 METHODS

=over 4

=item * HTTP::HeadersParser->new(\%options)

Constructs a new parser object.

Takes DocumentHandler and ErrorHandler objects as parameters.

=item * HTTP::HeadersParser->parse_header_string($headers)

Takes headers as single string.

  $parser->parse_header_string( "HTTP/1.0 200 OK\nServer: Apache\nAge: 7" );

=item * HTTP::HeadersParser->parse_header_list(\@header_list)

Takes headers as a reference to a list of strings.

  $parser->parse_header_list( [ "HTTP/1.0 200 OK", "Server: Apache", "Age: 7" ] );

=item * HTTP::HeadersParser->parse_header_line($header_line)

Takes one header at a time.

  $parser->parse_header_line( "Server: Apache" );

=back

=head2 Interface for DocumentHandler

The class functioning as DocumentHandler, CAN implement
the following two methods:

=over 4

=item * $dh->status_line($http_version, $http_status_code, $http_reason_phrase)

This method will be invoked when an HTTP status line
(the first line in HTTP response) is found.

$http_version is the HTTP protocol version number.

$http_status_code is the status code, represented as three-letter-digit.

$http_reason_phrase is the human-understandable explanation of former.

=item * $dh->header_line($http_header_name, $http_header_value)

This method will be invoked for all the other HTTP headers.

The parameters represent the name-value pair of HTTP header data.

=back

=head2 Interface for ErrorHandler

The class functioning as ErrorHandler, MUST implement the following
one method:

=over 4

=item * $eh->fatal_error($error_message)

The method will be called, when parser confronts with misformatted
HTTP header.

The default behavior (provided by HTTP::HeadersParser::DefaultErrorHandler)
is to use simple die().

=back

=head1 AUTHOR

Rene Saarsoo <nene@triin.net>

This module is licensed under the same terms as Perl itself.

=cut
