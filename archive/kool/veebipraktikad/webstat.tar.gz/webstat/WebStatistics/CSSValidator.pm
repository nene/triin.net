package WebStatistics::CSSValidator;

use warnings;
use strict;
use WebStatistics::DBGeneral;
use Data::Dumper;

use WebStatistics::CSSValidatorPatterns;

use vars qw(
    $RE_CONTEXT_LINE
    $RE_ERROR_LINE
    $RE_ERROR_MESSAGE
);


$RE_CONTEXT_LINE = qr{^ Line : [0-9]* Context : .*$}i;

$RE_ERROR_LINE = qr{
    ^
    \s
    Line        # begins with a " Line : "
    \s:\s
    [0-9]*      # line nr
    [^\t]*      # Possible CONTEXT text
    \t          # error message is separated with tab
    (.*)        # error message
    $
}xi;

$RE_ERROR_MESSAGE = qr{^\t(.*?)$}i;

=head1 NAME

WebStatistics::CSSValidator - interface for offline W3C CSS Validator.

=head1 SYNOPSIS

    use WebStatistics::CSSValidator;

    # Create database and cache objects
    my $db = DBI->connect( "DBI:mysql:DatabaseName", "user", "pass");
    my $sql = new WebStatistics::SQL::General( $db );
    my $cache = new WebStatistics::Cache::General();

    my $validator = new WebStatistics::CSSValidator( {
        DatabaseCache => $cache,
        SQLStatements => $sql,
    } );

    $validator->validate( "/home/john/www/style.css" );

    if ( $validator->is_valid ) {
        print "VALID CSS :)\n";
    }
    else {
        print "INVALID CSS :(\n";
        print $validator->get_error_count . " errors.\n";
    }

=head1 DESCRIPTION

This module simplifies the usage of wget program.

=head1 METHODS

At the moment this module provides only one method.

=cut




# constructor
sub new {
    my $type = shift;
    my $options = shift;

    my $self = bless {}, $type;

    # manage options
    $self->{cache} = $options->{DatabaseCache} || die("No database cache specified");
    $self->{sql} = $options->{SQLStatements} || die("No SQL statements manager specified");
    $self->{current_page_id} = $options->{CurrentPageId} || 0;

    # Init statistical attributes
    $self->init_statistical_attributes();

    return $self;
}





=head2 GET and SET methods

=head3 set_current_page_id( $id )

Set the ID of current webpage in the database.

=cut
sub set_current_page_id {
    my $self = shift;
    my $current_page_id = shift;

    $self->{current_page_id} = $current_page_id || die("No current page ID specified.");
}


=head3 get_error_count

Returns the number of validation errors.

=cut
sub get_error_count {
    my $self = shift;

    return $self->{error_count};
}




=head3 is_valid

Returns true, if CSS file was valid.

=cut
sub is_valid {
    my $self = shift;

    if ( $self->{error_count} == 0 ) {
        return 1;
    }
    else {
        return 0;
    }
}




=head2 validate( $filename, $css_version )

Validate CSS file using given CSS version.

CSS version is "css2" by default.

=cut
sub validate {
    my $self = shift;
    my $filename = shift;
    my $css_version = shift || "css2";

    # execute CSS validator
    # only output errors ( no warnings )
    open(
        my $validator,
        "java -jar ~/css-validator/css-validator.jar -e -$css_version '$filename' |"
    ) ||
        die "Can't execute css-validator!";

    # read validator output
    my $previous_line_was_context_line = 0;
    while ( my $line = <$validator> ) {

        if ( $line =~ $RE_ERROR_LINE ) {
            # Single line, containing error message
            $self->error_message_found( $1 );
            $previous_line_was_context_line = 0;
        }
        elsif ( $line =~ $RE_CONTEXT_LINE ) {
            # The first line, containing the context of error
            $previous_line_was_context_line = 1;
        }
        elsif ( $line =~ $RE_ERROR_MESSAGE && $previous_line_was_context_line ) {
            # The second line, containing the error message itself
            $self->error_message_found( $1 );
            $previous_line_was_context_line = 0;
        }
        else {
            # Ignorable validator output
            $previous_line_was_context_line = 0;
        }

    }
}

sub error_message_found {
    my $self = shift;
    my $error_message = shift;

    $self->{cache}->{css_errors}->increment_count( get_error_message_id( $error_message ) );
    $self->{error_count}++;
}


################################################################################
#
#  Initialization
#
################################################################################


=head2 init_statistical_attributes

Initialize the values of statistical attributes,
like setting error-count to zero.

=cut
sub init_statistical_attributes {
    my $self = shift;

    $self->{error_count} = 0;
}




=head2 commit

Commit results of CSS validation to database.

=cut
sub commit {
    my $self = shift;

    my $cache = $self->{cache}->{css_errors}->{cache};
    my $page_id = $self->{current_page_id} || die("No current page ID specified.");

    while ( my ($error_id, $attributes) = each( %$cache ) ) {
        # add error message count to database
        if ($attributes->{count} > 0) {
            $self->{sql}->{css_errors}->{insert_webpage_element}->execute(
                $page_id,
                $error_id,
                $attributes->{count}
            );
        }

        # reset count
        $attributes->{count} = 0;
    }
}







1;
