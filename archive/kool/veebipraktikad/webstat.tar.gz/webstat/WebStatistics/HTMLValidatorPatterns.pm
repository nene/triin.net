package WebStatistics::HTMLValidatorPatterns;

use warnings;
use strict;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(get_error_message_id);


sub get_error_message_id {
    $_ = shift;

    if ( m!#IMPLIED already linked to result element type .*!i ) {
        return 1;
    }
    elsif ( m!#PCDATA in model group that does not have rep occurrence indicator!i ) {
        return 2;
    }
    elsif ( m!#PCDATA in nested model group!i ) {
        return 3;
    }
    elsif ( m!#PCDATA in seq group!i ) {
        return 4;
    }
    elsif ( m!#PCDATA not first in model group!i ) {
        return 5;
    }
    elsif ( m!.* cannot be the replacement for a reference reserved name because it is another reference reserved name!i ) {
        return 6;
    }
    elsif ( m!.* cannot be the replacement for a reference reserved name because it is the replacement of another reference reserved name!i ) {
        return 7;
    }
    elsif ( m!.* declaration illegal after document element!i ) {
        return 8;
    }
    elsif ( m!.* declaration not allowed in DTD subset!i ) {
        return 9;
    }
    elsif ( m!.* declaration not allowed in LPD subset!i ) {
        return 10;
    }
    elsif ( m!.* declaration not allowed in instance!i ) {
        return 11;
    }
    elsif ( m!.* declaration not allowed in prolog!i ) {
        return 12;
    }
    elsif ( m!.* invalid: only .* and parameter separators allowed!i ) {
        return 13;
    }
    elsif ( m!.* invalid: only .* and parameter separators are allowed!i ) {
        return 14;
    }
    elsif ( m!.* invalid: only .* and token separators are allowed!i ) {
        return 15;
    }
    elsif ( m!.* invalid: only s and tagc allowed here!i ) {
        return 16;
    }
    elsif ( m!.* is already a function name!i ) {
        return 17;
    }
    elsif ( m!.* is not a character number in the document character set!i ) {
        return 18;
    }
    elsif ( m!.* is not a data or subdocument entity!i ) {
        return 19;
    }
    elsif ( m!.* is not a function name!i ) {
        return 20;
    }
    elsif ( m!.* is not a general entity name!i ) {
        return 21;
    }
    elsif ( m!.* is not a member of a group specified for any attribute!i ) {
        return 22;
    }
    elsif ( m!.* is not a notation name!i ) {
        return 23;
    }
    elsif ( m!.* is not a reserved name!i ) {
        return 24;
    }
    elsif ( m!.* is not a short reference delimiter!i ) {
        return 25;
    }
    elsif ( m!.* is not a valid name in the declared concrete syntax!i ) {
        return 26;
    }
    elsif ( m!.* is not a valid short reference delimiter because it has more than one B sequence!i ) {
        return 27;
    }
    elsif ( m!.* is not a valid short reference delimiter because it is adjacent to a character that can occur in a blank sequence!i ) {
        return 28;
    }
    elsif ( m!.* is not a valid syntax reference character number!i ) {
        return 29;
    }
    elsif ( m!.* is not a valid token here!i ) {
        return 30;
    }
    elsif ( m!.* is not allowed as a reserved name here!i ) {
        return 31;
    }
    elsif ( m!.* not finished but containing element ended!i ) {
        return 32;
    }
    elsif ( m!.* not finished but document ended!i ) {
        return 33;
    }
    elsif ( m!.* used both a rank stem and generic identifier!i ) {
        return 34;
    }
    elsif ( m!.*attribute minimization.* is not supported in .*XML.*!i ) {
        return 35;
    }
    elsif ( m!AFDR declaration required before use of AFDR extensions!i ) {
        return 36;
    }
    elsif ( m!CDATA declared content!i ) {
        return 37;
    }
    elsif ( m!DATATAG feature not implemented!i ) {
        return 38;
    }
    elsif ( m!DTD not allowed after an LPD!i ) {
        return 39;
    }
    elsif ( m!DTDs other than base allowed only if CONCUR YES or EXPLICIT YES!i ) {
        return 40;
    }
    elsif ( m!ENR extensions were used but minimum literal was not "+ISO 8879:1986 \(ENR\)"+ or "+ISO 8879:1986 \(WWW\)"+!i ) {
        return 41;
    }
    elsif ( m!ID .* already defined!i ) {
        return 42;
    }
    elsif ( m!ID .* first defined here!i ) {
        return 43;
    }
    elsif ( m!ID link set declaration not allowed in simple link declaration subset!i ) {
        return 44;
    }
    elsif ( m!LPD .* has neither internal nor external subset!i ) {
        return 45;
    }
    elsif ( m!LPD not allowed before first DTD!i ) {
        return 46;
    }
    elsif ( m!NAME or NAMES declared value!i ) {
        return 47;
    }
    elsif ( m!NETENABL IMMEDNET requires EMPTYNRM YES!i ) {
        return 48;
    }
    elsif ( m!NUMBER or NUMBERS declared value!i ) {
        return 49;
    }
    elsif ( m!NUTOKEN or NUTOKENS declared value!i ) {
        return 50;
    }
    elsif ( m!RCDATA declared content!i ) {
        return 51;
    }
    elsif ( m!RCDATA marked section!i ) {
        return 52;
    }
    elsif ( m!RNI delimiter must be followed by name start character!i ) {
        return 53;
    }
    elsif ( m!SGML declaration cannot be parsed because the character set does not contain characters having the following numbers in ISO 646: .*!i ) {
        return 54;
    }
    elsif ( m!SGML declaration reference was used but minimum literal was not "+ISO 8879:1986 \(WWW\)"+!i ) {
        return 55;
    }
    elsif ( m!SGML declaration was not implied!i ) {
        return 56;
    }
    elsif ( m!TEMP marked section!i ) {
        return 57;
    }
    elsif ( m!UCNMCHAR must have the same number of characters as LCNMCHAR!i ) {
        return 58;
    }
    elsif ( m!UCNMSTRT must have the same number of characters as LCNMSTRT!i ) {
        return 59;
    }
    elsif ( m!Web SGML adaptations were used but minimum literal was not "+ISO 8879:1986 \(WWW\)"+!i ) {
        return 60;
    }
    elsif ( m!a name group is not allowed in a general entity reference in a start tag!i ) {
        return 61;
    }
    elsif ( m!a name group is not allowed in a general entity reference in the prolog!i ) {
        return 62;
    }
    elsif ( m!a name group is not allowed in a parameter entity reference in the prolog!i ) {
        return 63;
    }
    elsif ( m!a net-enabling start-tag cannot include a document type specification!i ) {
        return 64;
    }
    elsif ( m!a parameter entity reference can only occur in a group where a token could occur!i ) {
        return 65;
    }
    elsif ( m!a parameter entity reference cannot occur in an SGML declaration!i ) {
        return 66;
    }
    elsif ( m!a parameter entity referenced in a parameter separator must end in the same declaration!i ) {
        return 67;
    }
    elsif ( m!a parameter entity referenced in a token separator must end in the same group!i ) {
        return 68;
    }
    elsif ( m!a parameter literal in a data tag pattern must not contain a numeric character reference to a function character!i ) {
        return 69;
    }
    elsif ( m!a parameter literal in a data tag pattern must not contain a numeric character reference to a non-SGML character!i ) {
        return 70;
    }
    elsif ( m!a parameter separator is required after a number that is followed by a name start character!i ) {
        return 71;
    }
    elsif ( m!a reference to a CDATA or SDATA entity is allowed only in a context where a data character could occur!i ) {
        return 72;
    }
    elsif ( m!a reference to a PI entity is allowed only in a context where a processing instruction could occur!i ) {
        return 73;
    }
    elsif ( m!a reference to a PI entity is not allowed in replaceable character data!i ) {
        return 74;
    }
    elsif ( m!a reference to a subdocument entity or external data entity is allowed only in a context where a data character could occur!i ) {
        return 75;
    }
    elsif ( m!a reference to a subdocument entity or external data entity is not allowed in replaceable character data!i ) {
        return 76;
    }
    elsif ( m!a short reference mapping declaration is allowed only in the base DTD!i ) {
        return 77;
    }
    elsif ( m!a short reference use declaration is allowed only in the base DTD!i ) {
        return 78;
    }
    elsif ( m!an attribute specification must start with a name or name token!i ) {
        return 79;
    }
    elsif ( m!an attribute value literal can occur in an attribute specification list only after a vi delimiter!i ) {
        return 80;
    }
    elsif ( m!an attribute value must be quoted if it contains any character other than letters \(A-Za-z\), digits, hyphens, and periods; use quotes if in doubt!i ) {
        return 81;
    }
    elsif ( m!an attribute value specification must start with a literal or a name character!i ) {
        return 82;
    }
    elsif ( m!an entity end in a literal must terminate an entity referenced in the same literal!i ) {
        return 83;
    }
    elsif ( m!an entity end in a parameter separator must terminate an entity referenced in the same declaration!i ) {
        return 84;
    }
    elsif ( m!an entity end in a token separator must terminate an entity referenced in the same group!i ) {
        return 85;
    }
    elsif ( m!an entity end is not allowed in a token separator that does not follow a token!i ) {
        return 86;
    }
    elsif ( m!and group!i ) {
        return 87;
    }
    elsif ( m!attribute definition list declaration for group of element types!i ) {
        return 88;
    }
    elsif ( m!attribute definition list declaration for notation!i ) {
        return 89;
    }
    elsif ( m!attribute name missing!i ) {
        return 90;
    }
    elsif ( m!attribute value not a literal!i ) {
        return 91;
    }
    elsif ( m!attribute values must be quoted in .*XML.* !i ) {
        return 92;
    }
    elsif ( m!attributes can only be defined for base document element \(not .*\) in simple link declaration subset!i ) {
        return 93;
    }
    elsif ( m!base character set .* is unknown!i ) {
        return 94;
    }
    elsif ( m!both document type and link type .*!i ) {
        return 95;
    }
    elsif ( m!bracketed text entity!i ) {
        return 96;
    }
    elsif ( m!cannot continue because of previous errors!i ) {
        return 97;
    }
    elsif ( m!cannot continue with subdocument because of previous errors!i ) {
        return 98;
    }
    elsif ( m!cannot convert character reference to number .* because character .* from baseset .* unknown!i ) {
        return 99;
    }
    elsif ( m!cannot convert character reference to number .* because character not in internal character set!i ) {
        return 100;
    }
    elsif ( m!cannot convert character reference to number .* because description .* unrecognized!i ) {
        return 101;
    }
    elsif ( m!cannot generate system identifier for SGML declaration reference!i ) {
        return 102;
    }
    elsif ( m!cannot generate system identifier for document type .*!i ) {
        return 103;
    }
    elsif ( m!cannot generate system identifier for general entity .*!i ) {
        return 104;
    }
    elsif ( m!cannot generate system identifier for link type .*!i ) {
        return 105;
    }
    elsif ( m!cannot generate system identifier for notation .*!i ) {
        return 106;
    }
    elsif ( m!cannot generate system identifier for parameter entity .*!i ) {
        return 107;
    }
    elsif ( m!cannot generate system identifier for public text .*!i ) {
        return 108;
    }
    elsif ( m!capacity .* already specified!i ) {
        return 109;
    }
    elsif ( m!capacity set .* is unknown!i ) {
        return 110;
    }
    elsif ( m!character .* invalid: only .* and parameter separators allowed!i ) {
        return 111;
    }
    elsif ( m!character .* invalid: only .* and token separators allowed!i ) {
        return 112;
    }
    elsif ( m!character .* invalid: only minimum data characters allowed!i ) {
        return 113;
    }
    elsif ( m!character .* is not allowed in the value of attribute .*!i ) {
        return 114;
    }
    elsif ( m!character .* is not significant in the reference concrete syntax and so cannot occur in a comment in the SGML declaration!i ) {
        return 115;
    }
    elsif ( m!character .* is not significant in the reference concrete syntax and so cannot occur in a literal in the SGML declaration except as the replacement of a character reference!i ) {
        return 116;
    }
    elsif ( m!character .* is the first character of a delimiter but occurred as data!i ) {
        return 117;
    }
    elsif ( m!character .* not allowed in attribute specification list \(possibly caused by a missing quotation mark ending a previous attribute value\)!i ) {
        return 118;
    }
    elsif ( m!character .* not allowed in declaration subset!i ) {
        return 119;
    }
    elsif ( m!character .* not allowed in end tag!i ) {
        return 120;
    }
    elsif ( m!character .* not allowed in prolog!i ) {
        return 121;
    }
    elsif ( m!character number .* assigned to more than one function!i ) {
        return 122;
    }
    elsif ( m!character number .* cannot be assigned to LCNMCHAR, UCNMCHAR, LCNMSTRT or UCNMSTRT because it is RE!i ) {
        return 123;
    }
    elsif ( m!character number .* cannot be assigned to LCNMCHAR, UCNMCHAR, LCNMSTRT or UCNMSTRT because it is RS!i ) {
        return 124;
    }
    elsif ( m!character number .* cannot be assigned to LCNMCHAR, UCNMCHAR, LCNMSTRT or UCNMSTRT because it is SPACE!i ) {
        return 125;
    }
    elsif ( m!character number .* cannot be switched because it is a Digit, LC Letter or UC Letter!i ) {
        return 126;
    }
    elsif ( m!character number .* in the syntax reference character set was specified as a character to be switched but is not a markup character!i ) {
        return 127;
    }
    elsif ( m!character number .* was specified as a character to be switched but is not in the syntax reference character set!i ) {
        return 128;
    }
    elsif ( m!character numbers .* in the document character set have been assigned the same meaning, but this is the meaning of a significant character!i ) {
        return 129;
    }
    elsif ( m!character numbers assigned to both LCNMCHAR or UCNMCHAR and LCNMSTRT or UCNMSTRT: .*!i ) {
        return 130;
    }
    elsif ( m!character numbers declared more than once: .*!i ) {
        return 131;
    }
    elsif ( m!character numbers missing in base set: .*!i ) {
        return 132;
    }
    elsif ( m!character numbers should have been declared UNUSED: .*!i ) {
        return 133;
    }
    elsif ( m!character reference illegal after document element!i ) {
        return 134;
    }
    elsif ( m!character reference to number .* cannot be converted because of problem with internal character set!i ) {
        return 135;
    }
    elsif ( m!characters in the document character set with numbers exceeding .* not supported!i ) {
        return 136;
    }
    elsif ( m!characters with the following numbers in ISO 646 are significant in the concrete syntax but are not in the document character set: .*!i ) {
        return 137;
    }
    elsif ( m!characters with the following numbers in the syntax reference character set are significant in the concrete syntax but are not in the document character set: .*!i ) {
        return 138;
    }
    elsif ( m!comment declaration started here!i ) {
        return 139;
    }
    elsif ( m!comment in parameter separator!i ) {
        return 140;
    }
    elsif ( m!comment started here!i ) {
        return 141;
    }
    elsif ( m!concrete syntax scope is INSTANCE but value of .* quantity is less than value in reference quantity set!i ) {
        return 142;
    }
    elsif ( m!conref attribute!i ) {
        return 143;
    }
    elsif ( m!content model is ambiguous: when no tokens have been matched, both the .* and .* occurrences of .* are possible!i ) {
        return 144;
    }
    elsif ( m!content model is ambiguous: when the current token is the .* occurrence of .* and the innermost .* containing and groups have been matched, both the .* and .* occurrences of .* are possible!i ) {
        return 145;
    }
    elsif ( m!content model is ambiguous: when the current token is the .* occurrence of .* and the innermost containing and group has been matched, both the .* and .* occurrences of .* are possible!i ) {
        return 146;
    }
    elsif ( m!content model is ambiguous: when the current token is the .* occurrence of .*, both the .* and .* occurrences of .* are possible!i ) {
        return 147;
    }
    elsif ( m!content model is mixed but does not allow #PCDATA everywhere!i ) {
        return 148;
    }
    elsif ( m!content model nesting level exceeds GRPLVL \(.*\)!i ) {
        return 149;
    }
    elsif ( m!current attribute!i ) {
        return 150;
    }
    elsif ( m!data attribute specification must be omitted if attribute specification list is empty!i ) {
        return 151;
    }
    elsif ( m!data or replaceable character data in declaration subset!i ) {
        return 152;
    }
    elsif ( m!declaration of default entity!i ) {
        return 153;
    }
    elsif ( m!declared value of data attribute cannot be ENTITY, ENTITIES, ID, IDREF, IDREFS or NOTATION!i ) {
        return 154;
    }
    elsif ( m!declared value of link attribute cannot be ID, IDREF, IDREFS or NOTATION!i ) {
        return 155;
    }
    elsif ( m!default entity used in entity attribute .*!i ) {
        return 156;
    }
    elsif ( m!default value of data attribute cannot be CONREF or CURRENT!i ) {
        return 157;
    }
    elsif ( m!default value of link attribute cannot be CURRENT or CONREF!i ) {
        return 158;
    }
    elsif ( m!definition of general entity .* is unstable!i ) {
        return 159;
    }
    elsif ( m!definition of parameter entity .* is unstable!i ) {
        return 160;
    }
    elsif ( m!delimiter cannot be an empty string!i ) {
        return 161;
    }
    elsif ( m!delimiter set is ambiguous: .* and .* can be recognized in the same mode!i ) {
        return 162;
    }
    elsif ( m!digits assigned to LCNMCHAR, UCNMCHAR, LCNMSTRT or UCNMSTRT: .*!i ) {
        return 163;
    }
    elsif ( m!document instance must start with document element!i ) {
        return 164;
    }
    elsif ( m!document type .* already defined!i ) {
        return 165;
    }
    elsif ( m!duplicate attribute definition list for element .*!i ) {
        return 166;
    }
    elsif ( m!duplicate attribute definition list for notation .*!i ) {
        return 167;
    }
    elsif ( m!duplicate declaration of entity .*!i ) {
        return 168;
    }
    elsif ( m!duplicate declaration of parameter entity .*!i ) {
        return 169;
    }
    elsif ( m!duplicate definition of attribute .*!i ) {
        return 170;
    }
    elsif ( m!duplicate specification of attribute .*!i ) {
        return 171;
    }
    elsif ( m!earlier reference to entity .* used default entity!i ) {
        return 172;
    }
    elsif ( m!element ".*" not allowed here; assuming missing ".*" start-tag!i ) {
        return 173;
    }
    elsif ( m!element ".*" not allowed here; check which elements this element may be contained within!i ) {
        return 174;
    }
    elsif ( m!element ".*" not allowed here; possible cause is an .*inline element.* containing a .*block-level element.*!i ) {
        return 175;
    }
    elsif ( m!element .* has a declared content of EMPTY and a CONREF attribute!i ) {
        return 176;
    }
    elsif ( m!element .* has a declared content of EMPTY and a NOTATION attribute!i ) {
        return 177;
    }
    elsif ( m!element .* not defined in this HTML version!i ) {
        return 178;
    }
    elsif ( m!element declaration for group of element types!i ) {
        return 179;
    }
    elsif ( m!element type .* already defined!i ) {
        return 180;
    }
    elsif ( m!element type .* both included and excluded!i ) {
        return 181;
    }
    elsif ( m!element type minimization parameter!i ) {
        return 182;
    }
    elsif ( m!element types have different link attribute definitions!i ) {
        return 183;
    }
    elsif ( m!empty comment declaration!i ) {
        return 184;
    }
    elsif ( m!empty end tag but no open elements!i ) {
        return 185;
    }
    elsif ( m!empty end-tag!i ) {
        return 186;
    }
    elsif ( m!empty result attribute specification!i ) {
        return 187;
    }
    elsif ( m!empty start-tag!i ) {
        return 188;
    }
    elsif ( m!end of document in DTD subset!i ) {
        return 189;
    }
    elsif ( m!end of document in LPD subset!i ) {
        return 190;
    }
    elsif ( m!end of document in prolog!i ) {
        return 191;
    }
    elsif ( m!end of entity other than document entity after document element!i ) {
        return 192;
    }
    elsif ( m!end tag for ".*" omitted; end tags are required in .*XML.* for .*non-empty elements.*; .*empty elements.* require an end tag or the start tag must end with "+/>"+!i ) {
        return 193;
    }
    elsif ( m!end tag for ".*" omitted; possible causes include a missing end tag, .*improper nesting.* of elements, or use of an element where it is not allowed!i ) {
        return 194;
    }
    elsif ( m!end tag for element ".*" which is not open; try removing the end tag or check for .*improper nesting.* of elements!i ) {
        return 195;
    }
    elsif ( m!end-tag minimization should be "+O"+ for element .* because it has CONREF attribute!i ) {
        return 196;
    }
    elsif ( m!end-tag minimization should be "+O"+ for element with declared content of EMPTY!i ) {
        return 197;
    }
    elsif ( m!entity .* declared SUBDOC, but SUBDOC NO specified in SGML declaration!i ) {
        return 198;
    }
    elsif ( m!entity .* in short reference map .* uses default entity!i ) {
        return 199;
    }
    elsif ( m!entity .* is already open!i ) {
        return 200;
    }
    elsif ( m!entity .* undefined in short reference map .*!i ) {
        return 201;
    }
    elsif ( m!entity end in character data, replaceable character data or ignored marked section!i ) {
        return 202;
    }
    elsif ( m!entity end in different element from entity reference!i ) {
        return 203;
    }
    elsif ( m!entity end not allowed in attribute specification list except in attribute value literal!i ) {
        return 204;
    }
    elsif ( m!entity end not allowed in end tag!i ) {
        return 205;
    }
    elsif ( m!entity end not allowed in processing instruction!i ) {
        return 206;
    }
    elsif ( m!entity reference illegal after document element!i ) {
        return 207;
    }
    elsif ( m!entity reference with no applicable DTD!i ) {
        return 208;
    }
    elsif ( m!entity was defined here!i ) {
        return 209;
    }
    elsif ( m!exclusion!i ) {
        return 210;
    }
    elsif ( m!explicit link requires EXPLICIT YES!i ) {
        return 211;
    }
    elsif ( m!external CDATA entity!i ) {
        return 212;
    }
    elsif ( m!external SDATA entity!i ) {
        return 213;
    }
    elsif ( m!external parameter entity .* cannot be CDATA, SDATA, NDATA or SUBDOC!i ) {
        return 214;
    }
    elsif ( m!first defined here!i ) {
        return 215;
    }
    elsif ( m!first occurrence of current attribute .* not specified!i ) {
        return 216;
    }
    elsif ( m!general delimiter .* consists solely of function characters!i ) {
        return 217;
    }
    elsif ( m!general delimiter role .* already defined!i ) {
        return 218;
    }
    elsif ( m!generic identifier .* used in DTD but not defined!i ) {
        return 219;
    }
    elsif ( m!generic identifier specification missing after document type specification in end-tag!i ) {
        return 220;
    }
    elsif ( m!generic identifier specification missing after document type specification in start-tag!i ) {
        return 221;
    }
    elsif ( m!grand total of content tokens exceeds GRPGTCNT \(.*\)!i ) {
        return 222;
    }
    elsif ( m!if the declared value is ID the default value must be IMPLIED or REQUIRED!i ) {
        return 223;
    }
    elsif ( m!ignored marked section in the instance!i ) {
        return 224;
    }
    elsif ( m!illegal character number .*!i ) {
        return 225;
    }
    elsif ( m!illegal numeric character reference to non-SGML character .* in literal!i ) {
        return 226;
    }
    elsif ( m!implicit link requires IMPLICIT YES!i ) {
        return 227;
    }
    elsif ( m!included marked section in the instance!i ) {
        return 228;
    }
    elsif ( m!inclusion!i ) {
        return 229;
    }
    elsif ( m!internal CDATA entity!i ) {
        return 230;
    }
    elsif ( m!internal SDATA entity!i ) {
        return 231;
    }
    elsif ( m!internal parameter entity .* cannot be CDATA or SDATA!i ) {
        return 232;
    }
    elsif ( m!invalid attribute value!i ) {
        return 233;
    }
    elsif ( m!invalid comment declaration; check your .*comment syntax.*!i ) {
        return 234;
    }
    elsif ( m!invalid declaration; check your .*comment syntax.*!i ) {
        return 235;
    }
    elsif ( m!invalid default SGML declaration!i ) {
        return 236;
    }
    elsif ( m!invalid formal public identifer .*: public text display version not permitted with this text class!i ) {
        return 237;
    }
    elsif ( m!invalid formal public identifier .*: extra field!i ) {
        return 238;
    }
    elsif ( m!invalid formal public identifier .*: invalid public text class!i ) {
        return 239;
    }
    elsif ( m!invalid formal public identifier .*: missing //!i ) {
        return 240;
    }
    elsif ( m!invalid formal public identifier .*: no SPACE after public text class!i ) {
        return 241;
    }
    elsif ( m!invalid formal public identifier .*: public text language must be a name containing only upper case letters!i ) {
        return 242;
    }
    elsif ( m!length of attribute value must not exceed .* characters!i ) {
        return 243;
    }
    elsif ( m!length of attribute value must not exceed LITLEN less NORMSEP \(-.*\)!i ) {
        return 244;
    }
    elsif ( m!length of delimiter .* exceeds NAMELEN \(.*\)!i ) {
        return 245;
    }
    elsif ( m!length of hex number must not exceed NAMELEN \(.*\)!i ) {
        return 246;
    }
    elsif ( m!length of interpreted minimum literal must not exceed reference LITLEN \(.*\)!i ) {
        return 247;
    }
    elsif ( m!length of interpreted parameter literal in bracketed text plus the length of the bracketing delimiters must not exceed LITLEN \(.*\)!i ) {
        return 248;
    }
    elsif ( m!length of interpreted parameter literal in data tag pattern must not exceed DTEMPLEN!i ) {
        return 249;
    }
    elsif ( m!length of interpreted parameter literal must not exceed LITLEN \(.*\)!i ) {
        return 250;
    }
    elsif ( m!length of name must not exceed NAMELEN \(.*\)!i ) {
        return 251;
    }
    elsif ( m!length of name token must not exceed NAMELEN \(.*\)!i ) {
        return 252;
    }
    elsif ( m!length of number must not exceed NAMELEN \(.*\)!i ) {
        return 253;
    }
    elsif ( m!length of parameter entity name must not exceed NAMELEN less the length of the PERO delimiter \(.*\)!i ) {
        return 254;
    }
    elsif ( m!length of processing instruction must not exceed PILEN \(.*\)!i ) {
        return 255;
    }
    elsif ( m!length of rank stem plus length of rank suffix must not exceed NAMELEN \(.*\)!i ) {
        return 256;
    }
    elsif ( m!length of reserved name .* exceeds NAMELEN \(.*\)!i ) {
        return 257;
    }
    elsif ( m!length of start-tag before interpretation of literals must not exceed TAGLEN \(.*\)!i ) {
        return 258;
    }
    elsif ( m!length of system identifier must not exceed LITLEN \(.*\)!i ) {
        return 259;
    }
    elsif ( m!length of tokenized attribute value must not exceed LITLEN less NORMSEP \(-.*\)!i ) {
        return 260;
    }
    elsif ( m!length of tokenized attribute value must not exceed LITLEN less NORMSEP \(.*\)!i ) {
        return 261;
    }
    elsif ( m!letters assigned to LCNMCHAR, UCNMCHAR, LCNMSTRT or UCNMSTRT: .*!i ) {
        return 262;
    }
    elsif ( m!link process must be activated before base DTD!i ) {
        return 263;
    }
    elsif ( m!link set .* already defined!i ) {
        return 264;
    }
    elsif ( m!link set .* used in LPD but not defined!i ) {
        return 265;
    }
    elsif ( m!link set declaration not allowed in simple link declaration subset!i ) {
        return 266;
    }
    elsif ( m!link set use declaration for simple link process!i ) {
        return 267;
    }
    elsif ( m!link type .* already defined!i ) {
        return 268;
    }
    elsif ( m!link type .* does not have a link set .*!i ) {
        return 269;
    }
    elsif ( m!literal is missing closing delimiter!i ) {
        return 270;
    }
    elsif ( m!magnitude of .* too big \(length exceeds NAMELEN\)!i ) {
        return 271;
    }
    elsif ( m!marked section end not in marked section declaration!i ) {
        return 272;
    }
    elsif ( m!marked section illegal after document element!i ) {
        return 273;
    }
    elsif ( m!marked section in internal DTD subset!i ) {
        return 274;
    }
    elsif ( m!marked section started here!i ) {
        return 275;
    }
    elsif ( m!member of model group containing #PCDATA has occurrence indicator!i ) {
        return 276;
    }
    elsif ( m!member of model group containing #PCDATA is a model group!i ) {
        return 277;
    }
    elsif ( m!minimum data of AFDR declaration must be "+ISO/IEC 10744:1997"+ not .*!i ) {
        return 278;
    }
    elsif ( m!minimum data of first minimum literal in SGML declaration must be "+ISO 8879:1986"+ or "+ISO 8879:1986 \(ENR\)"+ or "+ISO 8879:1986 \(WWW\)"+ not .*!i ) {
        return 279;
    }
    elsif ( m!missing a required sub-element of ".*"!i ) {
        return 280;
    }
    elsif ( m!missing document type declaration.*!i ) {
        return 281;
    }
    elsif ( m!missing marked section end!i ) {
        return 282;
    }
    elsif ( m!missing pic delimiter!i ) {
        return 283;
    }
    elsif ( m!multiple comments in comment declaration!i ) {
        return 284;
    }
    elsif ( m!multiple link rules for ID .* but not all have link attribute specifications!i ) {
        return 285;
    }
    elsif ( m!multiple link rules for element type .* but not all have link attribute specifications!i ) {
        return 286;
    }
    elsif ( m!multiple status keywords!i ) {
        return 287;
    }
    elsif ( m!name group or name token group used connector other than OR!i ) {
        return 288;
    }
    elsif ( m!name missing after name group in entity reference!i ) {
        return 289;
    }
    elsif ( m!named character reference!i ) {
        return 290;
    }
    elsif ( m!net-enabling start-tag not immediately followed by null end-tag!i ) {
        return 291;
    }
    elsif ( m!net-enabling start-tag not supported in .*XML.*!i ) {
        return 292;
    }
    elsif ( m!no DTD .* declared!i ) {
        return 293;
    }
    elsif ( m!no attributes defined for notation .*!i ) {
        return 294;
    }
    elsif ( m!no current rank for rank stem .*!i ) {
        return 295;
    }
    elsif ( m!no document element!i ) {
        return 296;
    }
    elsif ( m!no document type declaration; implying .*!i ) {
        return 297;
    }
    elsif ( m!no document type declaration; will parse without validation!i ) {
        return 298;
    }
    elsif ( m!no initial link set defined for LPD .*!i ) {
        return 299;
    }
    elsif ( m!no internal or external document type declaration subset; will parse without validation!i ) {
        return 300;
    }
    elsif ( m!no link type .*!i ) {
        return 301;
    }
    elsif ( m!no result element type .*!i ) {
        return 302;
    }
    elsif ( m!no source element type .*!i ) {
        return 303;
    }
    elsif ( m!no start tag specified for implied empty element ".*"!i ) {
        return 304;
    }
    elsif ( m!no status keyword!i ) {
        return 305;
    }
    elsif ( m!no system id specified!i ) {
        return 306;
    }
    elsif ( m!non-SGML character not allowed in content!i ) {
        return 307;
    }
    elsif ( m!non-impliable attribute .* not specified but OMITTAG NO and SHORTTAG NO!i ) {
        return 308;
    }
    elsif ( m!normalized length of attribute specification list must not exceed ATTSPLEN \(.*\); length was .*!i ) {
        return 309;
    }
    elsif ( m!normalized length of attribute value literal must not exceed LITLEN \(.*\); length was .*!i ) {
        return 310;
    }
    elsif ( m!notation .* already defined!i ) {
        return 311;
    }
    elsif ( m!notation .* for entity .* undefined!i ) {
        return 312;
    }
    elsif ( m!notation .* is undefined but had attribute definition!i ) {
        return 313;
    }
    elsif ( m!notation .* not defined in source DTD!i ) {
        return 314;
    }
    elsif ( m!number of active simple link processes exceeds quantity specified for SIMPLE parameter in SGML declaration \(.*\)!i ) {
        return 315;
    }
    elsif ( m!number of attribute names and name tokens \(.*\) exceeds ATTCNT \(.*\)!i ) {
        return 316;
    }
    elsif ( m!number of entity names in attribute specification list must not exceed GRPCNT \(.*\)!i ) {
        return 317;
    }
    elsif ( m!number of first character in range must not exceed number of second character in range!i ) {
        return 318;
    }
    elsif ( m!number of id references in start-tag must not exceed GRPCNT \(.*\)!i ) {
        return 319;
    }
    elsif ( m!number of open elements exceeds TAGLVL \(.*\)!i ) {
        return 320;
    }
    elsif ( m!number of open marked sections must not exceed TAGLVL \(.*\)!i ) {
        return 321;
    }
    elsif ( m!number of open subdocuments exceeds quantity specified for SUBDOC parameter in SGML declaration \(.*\)!i ) {
        return 322;
    }
    elsif ( m!omitted tag minimization parameter can be omitted only if "+OMITTAG NO"+ is specified on the SGML declaration!i ) {
        return 323;
    }
    elsif ( m!one one implicit link process can be active!i ) {
        return 324;
    }
    elsif ( m!only fixed attributes can be defined in simple LPD!i ) {
        return 325;
    }
    elsif ( m!only one ID link set declaration allowed in an LPD subset!i ) {
        return 326;
    }
    elsif ( m!only one chain of explicit link processes can be active!i ) {
        return 327;
    }
    elsif ( m!only one type of connector should be used in a single group!i ) {
        return 328;
    }
    elsif ( m!parameter before "+LCNMSTRT"+ must be "+NAMING"+ not .*!i ) {
        return 329;
    }
    elsif ( m!parameter entity .* not defined!i ) {
        return 330;
    }
    elsif ( m!parameter entity reference in document instance!i ) {
        return 331;
    }
    elsif ( m!pointless for number of characters to be 0!i ) {
        return 332;
    }
    elsif ( m!processing instruction does not start with name!i ) {
        return 333;
    }
    elsif ( m!processing instruction entity!i ) {
        return 334;
    }
    elsif ( m!public text class of formal public identifier of SGML declaration must be SD!i ) {
        return 335;
    }
    elsif ( m!public text class of formal public identifier of base character set must be CHARSET!i ) {
        return 336;
    }
    elsif ( m!public text class of formal public identifier of capacity set must be CAPACITY!i ) {
        return 337;
    }
    elsif ( m!public text class of formal public identifier of concrete syntax must be SYNTAX!i ) {
        return 338;
    }
    elsif ( m!public text class of public identifier in notation identifier must be NOTATION!i ) {
        return 339;
    }
    elsif ( m!rank stem!i ) {
        return 340;
    }
    elsif ( m!reference not terminated by refc delimiter!i ) {
        return 341;
    }
    elsif ( m!reference to entity .* for which no system identifier could be generated!i ) {
        return 342;
    }
    elsif ( m!reference to entity .* uses default entity !i ) {
        return 343;
    }
    elsif ( m!reference to external data entity!i ) {
        return 344;
    }
    elsif ( m!reference to external entity in attribute value!i ) {
        return 345;
    }
    elsif ( m!reference to non-SGML character!i ) {
        return 346;
    }
    elsif ( m!reference to non-existent ID .*!i ) {
        return 347;
    }
    elsif ( m!reference to parameter entity in parameter literal in internal subset!i ) {
        return 348;
    }
    elsif ( m!reference to parameter entity in parameter separator in internal subset!i ) {
        return 349;
    }
    elsif ( m!reference to parameter entity in token separator in internal subset!i ) {
        return 350;
    }
    elsif ( m!replacement for reserved name .* already specified!i ) {
        return 351;
    }
    elsif ( m!required attribute .* not specified!i ) {
        return 352;
    }
    elsif ( m!result document type in simple link specification must be implied!i ) {
        return 353;
    }
    elsif ( m!s separator in comment declaration!i ) {
        return 354;
    }
    elsif ( m!s separator in status keyword specification in document instance!i ) {
        return 355;
    }
    elsif ( m!separator characters assigned to LCNMCHAR, UCNMCHAR, LCNMSTRT or UCNMSTRT: .*!i ) {
        return 356;
    }
    elsif ( m!short reference delimiter .* already mapped in this declaration!i ) {
        return 357;
    }
    elsif ( m!short reference delimiter .* already specified!i ) {
        return 358;
    }
    elsif ( m!short reference map .* already defined!i ) {
        return 359;
    }
    elsif ( m!short reference map .* for element .* not defined in DTD!i ) {
        return 360;
    }
    elsif ( m!short reference map .* not defined!i ) {
        return 361;
    }
    elsif ( m!short reference map in DTD must specify associated element type!i ) {
        return 362;
    }
    elsif ( m!short reference map in document instance cannot specify associated element type!i ) {
        return 363;
    }
    elsif ( m!simple link requires SIMPLE YES!i ) {
        return 364;
    }
    elsif ( m!single character short references were already specified for character numbers: .*!i ) {
        return 365;
    }
    elsif ( m!sorry, link type .* not activated: only one implicit or explicit link process can be active \(with base document type as source document type\)!i ) {
        return 366;
    }
    elsif ( m!source document type name for link type .* must be base document type since EXPLICIT NO!i ) {
        return 367;
    }
    elsif ( m!source document type name for link type .* must be base document type since EXPLICIT YES 1!i ) {
        return 368;
    }
    elsif ( m!start or end of range must specify a single character!i ) {
        return 369;
    }
    elsif ( m!start tag for ".*" omitted!i ) {
        return 370;
    }
    elsif ( m!start tag omitted for element ".*" with declared content!i ) {
        return 371;
    }
    elsif ( m!start tag was here!i ) {
        return 372;
    }
    elsif ( m!syntax .* is unknown!i ) {
        return 373;
    }
    elsif ( m!text is not allowed here; try wrapping the text in a more descriptive container!i ) {
        return 374;
    }
    elsif ( m!the .* occurrence of .* in the content model for .* cannot be excluded at this point because it is contextually required!i ) {
        return 375;
    }
    elsif ( m!the .* occurrence of .* in the content model for .* cannot be excluded because it is neither inherently optional nor a member of an or group!i ) {
        return 376;
    }
    elsif ( m!the attribute definition list already declared attribute .* as the ID attribute!i ) {
        return 377;
    }
    elsif ( m!the attribute definition list already declared attribute .* as the NOTATION attribute!i ) {
        return 378;
    }
    elsif ( m!the character with number .* in ISO 646 is significant but has no representation in the syntax reference character set!i ) {
        return 379;
    }
    elsif ( m!the following character numbers are shunned characters that are not significant and so should have been declared UNUSED: .*!i ) {
        return 380;
    }
    elsif ( m!the number of open entities cannot exceed ENTLVL!i ) {
        return 381;
    }
    elsif ( m!the number of tokens in a group must not exceed GRPCNT \(.*\)!i ) {
        return 382;
    }
    elsif ( m!the specified character set is invalid because it does not contain the minimum data characters having the following numbers in ISO 646: .*!i ) {
        return 383;
    }
    elsif ( m!there is no attribute .* for this element \(in this HTML version\)!i ) {
        return 384;
    }
    elsif ( m!there is no unique character in the document character set corresponding to character number .* in the syntax reference character set!i ) {
        return 385;
    }
    elsif ( m!there is no unique character in the internal character set corresponding to character number .* in the syntax reference character set!i ) {
        return 386;
    }
    elsif ( m!there is no unique character in the specified document character set corresponding to character number .* in ISO 646!i ) {
        return 387;
    }
    elsif ( m!this is not an SGML document!i ) {
        return 388;
    }
    elsif ( m!token .* can be value for more multiple attributes so attribute name required!i ) {
        return 389;
    }
    elsif ( m!token .* has already occurred in this group!i ) {
        return 390;
    }
    elsif ( m!token .* occurs more than once in attribute definition list!i ) {
        return 391;
    }
    elsif ( m!too many characters assigned same meaning with minimum literal!i ) {
        return 392;
    }
    elsif ( m!type .* of element with ID .* not associated element type for applicable link rule in ID link set!i ) {
        return 393;
    }
    elsif ( m!unclosed end-tag!i ) {
        return 394;
    }
    elsif ( m!unclosed start-tag!i ) {
        return 395;
    }
    elsif ( m!unexpected entity end in SGML declaration: only .*, S separators and comments allowed!i ) {
        return 396;
    }
    elsif ( m!unexpected entity end while starting second pass!i ) {
        return 397;
    }
    elsif ( m!unknown entity .*!i ) {
        return 398;
    }
    elsif ( m!unrecognized .*DOCTYPE.*; unable to check document!i ) {
        return 399;
    }
    elsif ( m!unterminated comment: found end of entity inside comment!i ) {
        return 400;
    }
    elsif ( m!unused parameter entity .*!i ) {
        return 401;
    }
    elsif ( m!unused short reference map .*!i ) {
        return 402;
    }
    elsif ( m!value cannot be specified both for notation attribute and content reference attribute!i ) {
        return 403;
    }
    elsif ( m!value of attribute .* cannot be .*; must be one of .*!i ) {
        return 404;
    }
    elsif ( m!value of attribute .* invalid: .* cannot start a number token!i ) {
        return 405;
    }
    elsif ( m!value of attribute .* must be a single token!i ) {
        return 406;
    }
    elsif ( m!value of attribute .* must start with a letter, not .*!i ) {
        return 407;
    }
    elsif ( m!value of capacity .* exceeds value of TOTALCAP!i ) {
        return 408;
    }
    elsif ( m!value of fixed attribute .* not equal to default!i ) {
        return 409;
    }
    elsif ( m!when the concrete syntax scope is INSTANCE the syntax reference character set of the declared syntax must be the same as that of the reference concrete syntax!i ) {
        return 410;
    }
    elsif ( m!when there is an MSOCHAR there must also be an MSICHAR!i ) {
        return 411;
    }
    elsif ( m!cannot open ".*"!i ) {
        return 412;
    }
    else {
        # die "Unknown error '$_'";
        return 413; # Unknown error
    }
}

1;
