package WebStatistics::CSSValidatorPatterns;

use warnings;
use strict;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(get_error_message_id);


sub get_error_message_id {
    $_ = shift;

    if ( m!.* and .* are incompatibles!i ) {
        return 1;
    }
    elsif ( m!.* appears twice!i ) {
        return 2;
    }
    elsif ( m!.* can not be used with ATSC profile!i ) {
        return 3;
    }
    elsif ( m!.* can not be used with mobile profile!i ) {
        return 4;
    }
    elsif ( m!.* can\'t appear here in the context .*!i ) {
        return 5;
    }
    elsif ( m!.* has not been set by toggle-group property!i ) {
        return 6;
    }
    elsif ( m!.* is an incorrect operator!i ) {
        return 7;
    }
    elsif ( m!.* is an incorrect percentage!i ) {
        return 8;
    }
    elsif ( m!.* is an incorrect string!i ) {
        return 9;
    }
    elsif ( m!.* is an incorrect unit!i ) {
        return 10;
    }
    elsif ( m!.* is not a .* value!i ) {
        return 11;
    }
    elsif ( m!.* is not a correct groupname. Use a valid identifier!i ) {
        return 12;
    }
    elsif ( m!.* is not a valid color 3 or 6 hexadecimals numbers!i ) {
        return 13;
    }
    elsif ( m!.* is not an incorrect URL!i ) {
        return 14;
    }
    elsif ( m!.* negative values are not allowed!i ) {
        return 15;
    }
    elsif ( m!.* this function is only for the atsc-tv medium!i ) {
        return 16;
    }
    elsif ( m!A shadow offset is specified with two <length> values \(A blur radius may optionally be specified after the shadow offset.\)!i ) {
        return 17;
    }
    elsif ( m!Attempt to find a semi-colon before the property name. add it!i ) {
        return 18;
    }
    elsif ( m!Combinator .* between selectors is not allowed in this profile or version!i ) {
        return 19;
    }
    elsif ( m!Generic family names are keywords, and therefore must not be quoted.!i ) {
        return 20;
    }
    elsif ( m!ID selector #.* is invalid \! Only one ID selector can be specified in a simple selector: .*.!i ) {
        return 21;
    }
    elsif ( m!If the attribute selector ~= is used, the word in the value .* must not contain spaces.!i ) {
        return 22;
    }
    elsif ( m!In CSS1, an? (?:id|class) name could start with a digit \(".55ft"\), unless it was a dimension \(".55in"\). In CSS2, such (?:ids|classes) are parsed as unknown dimensions \(to allow for future additions of new units\)!i ) {
        return 23;
    }
    elsif ( m!Invalid RGB function!i ) {
        return 24;
    }
    elsif ( m!Invalid attr definition attr\(X\)!i ) {
        return 25;
    }
    elsif ( m!Invalid counter definition counter.*!i ) {
        return 26;
    }
    elsif ( m!Invalid counters definition counters.*!i ) {
        return 27;
    }
    elsif ( m!Invalid format definition format.*!i ) {
        return 28;
    }
    elsif ( m!Invalid format definition local.*!i ) {
        return 29;
    }
    elsif ( m!Invalid function definition!i ) {
        return 30;
    }
    elsif ( m!Invalid separator in shape definition. It must be a comma.!i ) {
        return 31;
    }
    elsif ( m!Invalid shape definition rect.*!i ) {
        return 32;
    }
    elsif ( m!Missing comma separator.!i ) {
        return 33;
    }
    elsif ( m!Only 0 can be a .*. You must put an unit after your number!i ) {
        return 34;
    }
    elsif ( m!Other \@rules than \@import are not supported by CSS1 .*!i ) {
        return 35;
    }
    elsif ( m!Percentage value expected!i ) {
        return 36;
    }
    elsif ( m!Position must be described in terms of degrees.!i ) {
        return 37;
    }
    elsif ( m!Property .* doesn\'t exist for media .*!i ) {
        return 38;
    }
    elsif ( m!Property .* doesn\'t exist!i ) {
        return 39;
    }
    elsif ( m!Sorry the feature .* is not implemented yet.!i ) {
        return 40;
    }
    elsif ( m!Specifies the elevation as an angle, between \'-90deg\' and \'90deg\'.!i ) {
        return 41;
    }
    elsif ( m!The pseudo-class ..* can\'t appear here in the HTML context .*!i ) {
        return 42;
    }
    elsif ( m!The pseudo-element :.* can\'t appear here in the context .*!i ) {
        return 43;
    }
    elsif ( m!The value is out of range.This value must be between \'0\' and \'100\'.!i ) {
        return 44;
    }
    elsif ( m!This number should be an integer.!i ) {
        return 45;
    }
    elsif ( m!Too few values for the property .*!i ) {
        return 46;
    }
    elsif ( m!Too many values or values are not recognized!i ) {
        return 47;
    }
    elsif ( m!Unknown dimension : .*!i ) {
        return 48;
    }
    elsif ( m!Unknown pseudo-element or pseudo-class!i ) {
        return 49;
    }
    elsif ( m!Unrecognized link element or xml-stylesheet PI.!i ) {
        return 50;
    }
    elsif ( m!Unrecognized media .*!i ) {
        return 51;
    }
    elsif ( m!Unrecognized pseudo named page .*!i ) {
        return 52;
    }
    elsif ( m!Value .* does not exist for CSS1!i ) {
        return 53;
    }
    elsif ( m!Value must be between -360 and 360 and be divisable by 90!i ) {
        return 54;
    }
    elsif ( m!Parse error - Unrecognized!i ) {
        return 55;
    }
    elsif ( m!Unrecognized!i ) {
        return 56;
    }
    else {
        # die "Unknown error '$_'";
        return 57; # Unknown error
    }
}

1;
