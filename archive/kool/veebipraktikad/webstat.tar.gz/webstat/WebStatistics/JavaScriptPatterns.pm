package WebStatistics::JavaScriptPatterns;

use warnings;
use strict;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(
    get_single_ident_id
    get_multiple_ident_id
);


sub get_single_ident_id {
    my $ident = shift;

    if ( $ident eq "break" ) {
        return 1;
    }
    elsif ( $ident eq "case" ) {
        return 2;
    }
    elsif ( $ident eq "catch" ) {
        return 3;
    }
    elsif ( $ident eq "continue" ) {
        return 4;
    }
    elsif ( $ident eq "default" ) {
        return 5;
    }
    elsif ( $ident eq "delete" ) {
        return 6;
    }
    elsif ( $ident eq "do" ) {
        return 7;
    }
    elsif ( $ident eq "else" ) {
        return 8;
    }
    elsif ( $ident eq "finally" ) {
        return 9;
    }
    elsif ( $ident eq "for" ) {
        return 10;
    }
    elsif ( $ident eq "function" ) {
        return 11;
    }
    elsif ( $ident eq "if" ) {
        return 12;
    }
    elsif ( $ident eq "in" ) {
        return 13;
    }
    elsif ( $ident eq "instanceof" ) {
        return 14;
    }
    elsif ( $ident eq "new" ) {
        return 15;
    }
    elsif ( $ident eq "return" ) {
        return 16;
    }
    elsif ( $ident eq "switch" ) {
        return 17;
    }
    elsif ( $ident eq "this" ) {
        return 18;
    }
    elsif ( $ident eq "throw" ) {
        return 19;
    }
    elsif ( $ident eq "try" ) {
        return 20;
    }
    elsif ( $ident eq "typeof" ) {
        return 21;
    }
    elsif ( $ident eq "var" ) {
        return 22;
    }
    elsif ( $ident eq "void" ) {
        return 23;
    }
    elsif ( $ident eq "while" ) {
        return 24;
    }
    elsif ( $ident eq "with" ) {
        return 25;
    }
    elsif ( $ident eq "false" ) {
        return 26;
    }
    elsif ( $ident eq "null" ) {
        return 27;
    }
    elsif ( $ident eq "true" ) {
        return 28;
    }
    elsif ( $ident eq "NaN" ) {
        return 29;
    }
    elsif ( $ident eq "Infinity" ) {
        return 30;
    }
    elsif ( $ident eq "undefined" ) {
        return 31;
    }
    elsif ( $ident eq "eval" ) {
        return 32;
    }
    elsif ( $ident eq "alert" ) {
        return 33;
    }
    elsif ( $ident eq "confirm" ) {
        return 34;
    }
    elsif ( $ident eq "prompt" ) {
        return 35;
    }
    elsif ( $ident eq "getElementsByTagName" ) {
        return 36;
    }
    elsif ( $ident eq "getElementById" ) {
        return 37;
    }
    elsif ( $ident eq "nodeName" ) {
        return 38;
    }
    elsif ( $ident eq "nodeValue" ) {
        return 39;
    }
    elsif ( $ident eq "nodeType" ) {
        return 40;
    }
    elsif ( $ident eq "parentNode" ) {
        return 41;
    }
    elsif ( $ident eq "childNodes" ) {
        return 42;
    }
    elsif ( $ident eq "firstChild" ) {
        return 43;
    }
    elsif ( $ident eq "lastChild" ) {
        return 44;
    }
    elsif ( $ident eq "previousSibling" ) {
        return 45;
    }
    elsif ( $ident eq "nextSibling" ) {
        return 46;
    }
    elsif ( $ident eq "cloneNode" ) {
        return 47;
    }
    elsif ( $ident eq "insertBefore" ) {
        return 48;
    }
    elsif ( $ident eq "replaceChild" ) {
        return 49;
    }
    elsif ( $ident eq "removeChild" ) {
        return 50;
    }
    elsif ( $ident eq "appendChild" ) {
        return 51;
    }
    elsif ( $ident eq "tagName" ) {
        return 52;
    }
    elsif ( $ident eq "getAttribute" ) {
        return 53;
    }
    elsif ( $ident eq "setAttribute" ) {
        return 54;
    }
    elsif ( $ident eq "removeAttribute" ) {
        return 55;
    }
    elsif ( $ident eq "getAttributeNode" ) {
        return 56;
    }
    elsif ( $ident eq "setAttributeNode" ) {
        return 57;
    }
    elsif ( $ident eq "removeAttributeNode" ) {
        return 58;
    }
    elsif ( $ident eq "addEventListener" ) {
        return 59;
    }
    elsif ( $ident eq "removeEventListener" ) {
        return 60;
    }
    elsif ( $ident eq "attachEvent" ) {
        return 61;
    }
    elsif ( $ident eq "detachEvent" ) {
        return 62;
    }
    elsif ( $ident eq "XMLHttpRequest" ) {
        return 63;
    }
    elsif ( $ident eq "ActiveXObject" ) {
        return 64;
    }
    else {
        return;
    }
};

sub get_multiple_ident_id {
    my $ident = shift;

    if ( $ident =~ m/document\.all/ ) {
        return 65;
    }
    elsif ( $ident =~ m/document\.layers/ ) {
        return 66;
    }
    elsif ( $ident =~ m/navigator\.plugins/ ) {
        return 67;
    }
    elsif ( $ident =~ m/navigator\.javaEnabled/ ) {
        return 68;
    }
    elsif ( $ident =~ m/navigator\.userAgent/ ) {
        return 69;
    }
    elsif ( $ident =~ m/navigator\.appVersion/ ) {
        return 70;
    }
    elsif ( $ident =~ m/window\.status/ ) {
        return 71;
    }
    elsif ( $ident =~ m/window\.location/ ) {
        return 72;
    }
    elsif ( $ident =~ m/window\.event/ ) {
        return 73;
    }
    elsif ( $ident =~ m/window\.parent/ ) {
        return 74;
    }
    elsif ( $ident =~ m/window\.self/ ) {
        return 75;
    }
    elsif ( $ident =~ m/window\.referrer/ ) {
        return 76;
    }
    elsif ( $ident =~ m/window\.open/ ) {
        return 77;
    }
    elsif ( $ident =~ m/window\.setTimeOut/ ) {
        return 78;
    }
    elsif ( $ident =~ m/window\.clearTimeOut/ ) {
        return 79;
    }
    elsif ( $ident =~ m/window\.print/ ) {
        return 80;
    }
    elsif ( $ident =~ m/screen\.width/ ) {
        return 81;
    }
    elsif ( $ident =~ m/screen\.height/ ) {
        return 82;
    }
    elsif ( $ident =~ m/screen\.colorDepth/ ) {
        return 83;
    }
    elsif ( $ident =~ m/document\.createElement/ ) {
        return 84;
    }
    elsif ( $ident =~ m/document\.createTextNode/ ) {
        return 85;
    }
    elsif ( $ident =~ m/document\.createAttribute/ ) {
        return 86;
    }
    else {
        return;
    }
}

1;
