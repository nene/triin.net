package WebStatistics::JavaScriptParser;

use warnings;
use strict;
use WebStatistics::DBGeneral;
use WebStatistics::JavaScriptPatterns;
use Data::Dumper;


=head1 NAME

WebStatistics::JavaScriptParser - simple statistical JavaScript analyzer.

=head1 SYNOPSIS


=head1 DESCRIPTION

This parser is far from being good. Only some basic buggy functionality is provided.

=head1 METHODS


=cut



use constant DEBUG => 0;



# constructor
sub new {
    my $type = shift;
    my $options = shift;

    my $self = bless {}, $type;

    # manage options
    $self->{cache} = $options->{DatabaseCache} || die("No database cache specified");
    $self->{sql} = $options->{SQLStatements} || die("No SQL statements manager specified");
    $self->{current_page_id} = $options->{CurrentPageId} || 0;

    # Init statistical attributes
    $self->init_statistical_attributes();

    return $self;
}





=head2 GET and SET methods

=head3 set_current_page_id( $id )

Set the ID of current webpage in the database.

=cut
sub set_current_page_id {
    my $self = shift;
    my $current_page_id = shift;

    $self->{current_page_id} = $current_page_id || die("No current page ID specified.");
}


=head3 get_error_count

Returns the number of validation errors.

=cut
sub get_comment_length {
    my $self = shift;

    return $self->{comment_length};
}




=head2 parse( $js )

Validate string of javasrcipt

=cut
sub parse {
    my $self = shift;
    my $js = shift;

    while ( length($js) ) {
        # whitespace
        if ( $js =~ s{^\s+}{}is ) {
            # ignore
            print "whitespace\n" if DEBUG;
        }

        # multiline comment
        elsif ( $js =~ s{^(/\*.*?(?:\*/|$))}{}is ) {
            print "comment '$1'\n" if DEBUG;
            $self->comment( $1 );
        }

        # single-line comment
        elsif ( $js =~ s{^(//.*?(?:\n\r|\r|\n|$))}{}is ) {
            print "comment '$1'\n" if DEBUG;
            $self->comment( $1 );
        }

        # string
        elsif ( $js =~ s{^("(?:[^"\\]|\\")*"|'(?:[^'\\]|\\')*')}{}is ) {
            # ignore
            print "string $1\n" if DEBUG;
        }

        # regular expression ( always inside parenthesis )
        elsif ( $js =~ s{^\(\s*(/[^/]+/[a-z]*)\s*\)}{}is ) {
            # ignore
            print "punctuation (\n" if DEBUG;
            print "regex $1\n" if DEBUG;
            print "punctuation )\n" if DEBUG;
        }

        # identifier-sequence ( like "window.document.getElementById" )
        elsif ( $js =~ s{^([a-z_][a-z0-9_]*(?:\s*\.\s*[a-z_][a-z0-9_]*)*)}{}is ) {
            my $ident = $1;
            # truncate all whitespace
            $ident =~ s/\s+//sg;
            print "ident '$ident'\n" if DEBUG;
            $self->identifier( $ident );
        }

        # number
        elsif ( $js =~ s{^(-?(?:[0-9]+|[0-9]*.[0-9]+))}{}is ) {
            # ignore
            print "number $1\n" if DEBUG;
        }

        # punctuation (remove only one character at the time)
        elsif ( $js =~ s{^([^a-z0-9_])}{}is ) {
            # ignore
            print "punctuation $1\n" if DEBUG;
        }
    }
}



sub comment {
    my $self = shift;
    my $text = shift;

    # Measure the size of all comments
    $self->{comment_length} += length($text);
}




sub identifier {
    my $self = shift;
    my $multi_ident = shift;

    # first try to match multipart identifier
    if ( my $ident_id = get_multiple_ident_id( $multi_ident ) ) {
        $self->{cache}->{javascript_elements}->increment_count( $ident_id );
    }
    else {
        # split ident into pieces
        my @ident_list = split m{\.}, $multi_ident;
        foreach my $ident ( @ident_list ) {
            if ( my $ident_id = get_single_ident_id( $ident ) ) {
                $self->{cache}->{javascript_elements}->increment_count( $ident_id );
            }
        }
    }
}




################################################################################
#
#  Initialization
#
################################################################################


=head2 init_statistical_attributes

Initialize the values of statistical attributes,
like setting comment-length to zero.

=cut
sub init_statistical_attributes {
    my $self = shift;

    $self->{comment_length} = 0;
}




=head2 commit

Commit results of JS analyzation to database.

=cut
sub commit {
    my $self = shift;

    my $cache = $self->{cache}->{javascript_elements}->{cache};
    my $page_id = $self->{current_page_id} || die("No current page ID specified.");

    while ( my ($error_id, $attributes) = each( %$cache ) ) {
        # add error message count to database
        if ($attributes->{count} > 0) {
            $self->{sql}->{javascript_elements}->{insert_webpage_element}->execute(
                $page_id,
                $error_id,
                $attributes->{count}
            );
        }

        # reset count
        $attributes->{count} = 0;
    }
}




=head1 AUTHOR

Rene Saarsoo <nene@triin.net>

This module is licensed under the same terms as Perl itself.

=cut


1;
