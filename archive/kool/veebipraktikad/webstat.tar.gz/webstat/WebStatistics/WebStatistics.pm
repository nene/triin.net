package WebStatistics::WebStatistics;

use warnings;
use strict;

# wget
use WebStatistics::Wget;

# URIs
use URI;

# Filesystem info
use File::stat;

# database and cache
use DBI;
use WebStatistics::SQL::General;
use WebStatistics::Cache::General;

# HTTP Headers
use HTTP::HeadersParser;
use WebStatistics::HTTPHeaders;

# HTML
use HTML::Parser;
use WebStatistics::HTMLElements;
use WebStatistics::HTMLValidator;

# CSS
use CSS::SAC;
use WebStatistics::CSSElements;
use WebStatistics::SACErrorHandler;
use WebStatistics::CSSValidator;

# JavaScript
use WebStatistics::JavaScriptParser;

# Utilities
use Data::Dumper;

=head1 NAME

WebStatistics::WebStatistics - the main module of WebStatistics package

=head1 SYNOPSIS

    use WebStatistics::WebStatistics;

    $database = "webstat";
    $host = "localhost";
    $user = "bob";
    $pass = "UnBR32K2bl3P2ssW0rD";

    my $webstat = new WebStatistics::WebStatistics(
        $database,
        $host,
        $user,
        $pass
    );

    # analyze the URI and save results to database
    $webstat->parse_address( "www.example.com" );

    $webstat->cleanup;

=cut




=head1 METHODS

=head2 new( $db_name, $db_host, $db_user, $db_pass )

Constructor. Takes database name, host, username and password
as parameters, to establish the connection to the MySQL database.

=cut

sub new {
    my $type = shift;
    my $db_name = shift;
    my $db_host = shift;
    my $db_user = shift;
    my $db_pass = shift;

    my $self = bless {}, $type;

    $self->init( $db_name, $db_host, $db_user, $db_pass );

    return $self;
}




# initialization
sub init {
    my $self = shift;
    my $db_name = shift;
    my $db_host = shift;
    my $db_user = shift;
    my $db_pass = shift;


    # establish database connection
    my $database = "webstat";
    $self->{db} = DBI->connect(
        "DBI:mysql:database=$db_name;host=$db_host",
        $db_user,
        $db_pass,
        {PrintError => 0},
    );

    # SQL statements
    $self->{sql} = new WebStatistics::SQL::General( $self->{db} );
    # create cache
    $self->{cache} = new WebStatistics::Cache::General();


    # Headers handler
    $self->{headers_handler} = new WebStatistics::HTTPHeaders( {
        SQLStatements => $self->{sql},
        DatabaseCache => $self->{cache},
    } );
    # Headers parser
    $self->{headers_parser} = new HTTP::HeadersParser( {
        DocumentHandler => $self->{headers_handler},
    } );

    # The same things for Http-Equiv's
    $self->{http_equiv_handler} = new WebStatistics::HTTPHeaders( {
        SQLStatements => $self->{sql},
        DatabaseCache => $self->{cache},
        IsHTTPEquiv => 1,
    } );
    $self->{http_equiv_parser} = new HTTP::HeadersParser( {
        DocumentHandler => $self->{http_equiv_handler},
    } );


    # HTML parser
    $self->{html_parser} = new WebStatistics::HTMLElements( {
        SQLStatements => $self->{sql},
        DatabaseCache => $self->{cache},
    } );
    $self->{html_parser}->empty_element_tags( 1 ); # recognyze empty XML tags like <br/>
    # HTML Validator
    $self->{html_validator} = new WebStatistics::HTMLValidator( {
        SQLStatements => $self->{sql},
        DatabaseCache => $self->{cache},
    } );


    # CSS handler
    $self->{css_handler} = new WebStatistics::CSSElements( {
        SQLStatements => $self->{sql},
        DatabaseCache => $self->{cache},
    } );
    # CSS parser
    $self->{css_parser} = CSS::SAC->new( {
        DocumentHandler => $self->{css_handler},
        ErrorHandler => new WebStatistics::SACErrorHandler( ),
    } );
    # CSS Validator
    $self->{css_validator} = new WebStatistics::CSSValidator( {
        SQLStatements => $self->{sql},
        DatabaseCache => $self->{cache},
    } );

    # JavaScript parser
    $self->{js_parser} = WebStatistics::JavaScriptParser->new( {
        SQLStatements => $self->{sql},
        DatabaseCache => $self->{cache},
    } );

    # set verbosity on
    $self->{verbose} = 1;

    # names of files where to save downloaded HTML, CSS and JavaScript
    $self->{downloaded_html_filename} = "webstat-html-download.html";
    $self->{downloaded_css_filename} = "webstat-css-download.css";
    $self->{downloaded_javascript_filename} = "webstat-javascript-download.js";
}



=head2 cleanup( )

Should be called before exiting the script.

At the moment does nothing more, then closes the database connection.

=cut

sub cleanup {
    my $self = shift;

    # disconnect from database
    $self->{db}->disconnect();
}




=head2 parse_file( $filename )

Reads URI's from file $filename and passes to parse_address() method.

=cut

sub parse_file {
    my $self = shift;
    my $filename = shift;

    # Read webpage addresses from inputfile
    open ( my $input_file, $filename ) || die "Unable to open '$filename'.";
    while ( my $address = <$input_file> ) {
        $self->parse_address( $address );
    }

}





=head2 parse_address( $URI )

Analyzes a single URI and stores results to database.

=cut

sub parse_address {
    my $self = shift;
    my $address = shift;

    $address = $self->normalize_uri( $address );

    my $redirect_count=0;

    BEGINNING_OF_PARSE_ADDRESS:

    # It might happen, that two sites redirect to one-another,
    # if no redirect_count exists, then the script would just start
    # endlessly jumping back and forward between the sites.
    # An example: www.globaling.org <--> www.tobaccopedia.com
    $redirect_count++;
    if ( $redirect_count > 10 ) {
        print "No more than 10 redirects allowed. Skipping.\n" if ($self->{verbose});
        # Just insert address into database, but nothing more.
        $self->insert_webpage_uri( $address );
	return;
    }

    print "\n\033[32m$address\033[0m\n" if ( $self->{verbose} );
    if ( my $page = wget( $address, $self->{downloaded_html_filename} ) ) {
        # downloading the page succeeded

        # the eventual address downloaded might have been different
        # than the initial address supplied, so we overwrite our
        # initial address with the actually downloaded address.
        $address = $page->{downloaded_address};
        print "Successfully downloaded: $address\n" if ( $self->{verbose} );

        # parse the HTTP headers of the page
        $self->{headers_parser}->parse_header_list( $page->{headers} );

        if ( $self->{headers_handler}->get_http_status_code() == 200 ) {
            # Now, the HTTP status code suggests, that we have reached
            # an normal webpage. This might be the case, but it might
            # also be, that the page does not use a real HTTP redirect,
            # but instead has an http-equiv=refresh meta-element,
            # which directs to another location.

            # First parse our downloaded HTML
            print "Parsing HTML.\n" if ( $self->{verbose} );
            $self->{html_parser}->parse( $page->{content} );

            # Next parse the http-equiv headers found from HTML
            my $http_equiv_list = $self->{html_parser}->get_http_equiv();
            $self->{http_equiv_parser}->parse_header_list( $http_equiv_list );

            # get the refresh-address
            my $refresh_address = $self->{http_equiv_handler}->get_refresh_url();

            if ( !$refresh_address ) {
                # as there is no refresh-address, this means there
                # can be no redirection (well, of course there is a chance
                # of JavaScript based redirection, but this is a way out
                # of the leage of this small program).
                $self->parse_html( $address );
            }
            else {
                # Yes, indeed, we have a http-quiv=refresh redirection.
                # But wait!
                # First we have to ensure it doesn't redirect to the same
                # page we're in - some pages use http-refresh to simply
                # refresh themselves after a while.

                # Ensure, that we are dealing with absolute URI
                $refresh_address = $self->convert_to_absolute_uri( $refresh_address, $address );

                # compare the URIs
                if ( URI::eq( $refresh_address, $address ) ) {
                    # as the page just refreshes himself,
                    # countinue...
                    $self->parse_html( $address );
                }
                else {
                    # well, it's a redirect after all...
                    # So, we just replace our address with the redirect one
                    print "Found redirect from meta-element.\n" if ( $self->{verbose} );
                    $address = $refresh_address;

                    # clean all counters and other statistical attributes,
                    # because we don't need the data gathered from a HTML file,
                    # which simply redirects to another page
                    $self->{html_parser}->init_statistical_attributes;
                    $self->{html_parser}->clean_count_cache;
                    $self->{http_equiv_handler}->empty_cache();

                    # jump into the beginning of this routine with...
                    # emm... goto.
                    goto BEGINNING_OF_PARSE_ADDRESS;
                }
            }
        }
        else {
            # If the HTTP status code is different than "200 OK",
            # then conclude, that we have reached into an error page.
            my $status = $self->{headers_handler}->get_http_status_code();
            print "Failure: HTTP Status code $status\n" if ( $self->{verbose} );

            # Just write headers to database and continue with next address.
            if ( my $webpage_id = $self->insert_webpage_uri( $address ) ) {
                $self->{headers_handler}->set_current_page_id( $webpage_id );
                $self->{headers_handler}->commit();
            }
        }
    }
    else {
        # Download failed. Most likely because of timeout,
        # which is only 10 seconds ( to be compatible with research of Parnas. )
        print "Download failed.\n" if ( $self->{verbose} );
        # Just insert address into database, but nothing more.
        $self->insert_webpage_uri( $address );
    }

}




sub parse_html {
    my $self = shift;
    my $address = shift;

    # insert webpage address into database
    my $webpage_id = $self->insert_webpage_uri( $address );

    # if webpage address already existed in database,
    # exit and continue with next address.
    if ( !$webpage_id ) {
        print "This address is already in database. Skipping.\n" if ( $self->{verbose} );
        $self->{html_parser}->init_statistical_attributes;
        $self->{html_parser}->clean_count_cache;
        $self->{http_equiv_handler}->empty_cache();
        return;
    }

    # add HTTP headers to database
    $self->{headers_handler}->set_current_page_id( $webpage_id );
    $self->{headers_handler}->commit();
    $self->{headers_handler}->empty_cache();

    # add Http-equivs to database
    $self->{http_equiv_handler}->set_current_page_id( $webpage_id );
    $self->{http_equiv_handler}->commit();
    $self->{http_equiv_handler}->empty_cache();

    # add HTML data to database
    $self->{html_parser}->set_current_page_id( $webpage_id );
    $self->{html_parser}->commit();

    # Validate HTML
    $self->validate_html( $webpage_id );

    # save file-, text- and comment length and validation errors of html file
    $self->{sql}->{webpages}->{set_html_sizes}->execute(
        stat( $self->{downloaded_html_filename} )->size,
        $self->{html_parser}->get_text_length,
        $self->{html_parser}->get_comment_length,
        $self->{html_validator}->get_error_count,
        $webpage_id
    );

    # Parse CSS and JavaScript
    $self->parse_css( $address, $webpage_id );
    $self->parse_javascript( $address, $webpage_id );

    # clean statistical attributes of HTML
    $self->{html_parser}->init_statistical_attributes();
    $self->{html_validator}->init_statistical_attributes();

    # remove HTML file
    unlink( $self->{downloaded_html_filename} );
}




# Validates downloaded HTML file.
# Commits results to database and cleans validator up after done.
sub validate_html {
    my $self = shift;
    my $webpage_id = shift;

    $self->{html_validator}->validate( $self->{downloaded_html_filename} );
    $self->{html_validator}->set_current_page_id( $webpage_id );
    $self->{html_validator}->commit();

    if ( $self->{verbose} ) {
        if ( $self->{html_validator}->is_valid ) {
            print "\033[32mVALID\033[0m HTML :)\n";
        }
        else {
            print "\033[31mINVALID\033[0m HTML :( " . $self->{html_validator}->get_error_count . " errors.\n" 
        }
    }

}




# Parses inline, embedded and external CSS.
# commits results to database and cleans all up.
sub parse_css {
    my $self = shift;
    my $html_address = shift;
    my $webpage_id = shift;

    my $parse_error_count = 0;

    # Parse and validate inline CSS
    my $inline_css = $self->{html_parser}->get_inline_css;
    my $inline_css_length = length($inline_css);
    if ( $inline_css_length > 0 ) {
        if ( $self->parse_inline_css( $inline_css ) ) {
            $parse_error_count ++;
        }
        $self->validate_inline_css( $inline_css );
    }

    # Parse and validate embedded CSS
    my $embedded_css = $self->{html_parser}->get_embedded_css;
    my $embedded_css_length = length($embedded_css);
    if ( $embedded_css_length > 0 ) {
        if ( $self->parse_embedded_css( $embedded_css ) ) {
            $parse_error_count ++;
        }
        $self->validate_embedded_css( $embedded_css );
    }

    # get external css URIs,
    # first from <link> elements, and then from @import rules.
    my $external_css_files = $self->{html_parser}->get_external_css;
    push( @$external_css_files, @{ $self->{css_handler}->get_imported_stylesheets } );

    # Parse and validate external CSS
    my $parse_result = $self->parse_external_css( $external_css_files, $html_address );
    my $external_css_count += $parse_result->{count};
    my $external_css_length += $parse_result->{length};
    $parse_error_count += $parse_result->{parse_errors};


    # commit all kind of CSS counts and sizes to database
    $self->{sql}->{webpages}->{set_css_sizes}->execute(
        $inline_css_length,
        $embedded_css_length,
        $external_css_length,
        $external_css_count,
        $self->{css_handler}->get_comment_length,
        $self->{css_handler}->get_important_count,
        $parse_error_count,
        $self->{css_validator}->get_error_count,
        $webpage_id
    );

    # commit css statistics
    $self->{css_handler}->set_current_page_id( $webpage_id );
    $self->{css_handler}->commit();
    $self->commit_css_validation_results( $webpage_id );

    # clean up
    $self->{css_handler}->init_statistical_attributes();
}




sub parse_inline_css {
    my $self = shift;
    my $inline_css = shift;

    print "Parsing inline CSS\n" if ( $self->{verbose} );

    eval {
        $self->{css_parser}->parse_style_declaration( \$inline_css );
    };
    if ($@) {
        # if parsing fails with fatal error,
        print $@ if ( $self->{verbose} );
        return; # false
    }
    else {
        return 1; # true
    }
}

sub validate_inline_css {
    my $self = shift;
    my $inline_css = shift;

    print "Validating inline CSS\n" if ( $self->{verbose} );

    # we close the style declarations inside simple selector "x",
    # as otherwise validator would certainly report it as invalid css.
    $inline_css = "x{$inline_css}";

    # write styles into temporary file
    open( my $file, '>', $self->{downloaded_css_filename} );
    print $file $inline_css;
    close( $file );
    # validate the file
    $self->{css_validator}->validate( $self->{downloaded_css_filename} );
    # after done, delete the file
    unlink( $self->{downloaded_css_filename} );
}



sub parse_embedded_css {
    my $self = shift;
    my $embedded_css = shift;

    print "Parsing embedded CSS\n" if ( $self->{verbose} );
    #print $embedded_css . "\n"; die "stop";
    eval {
        $self->{css_parser}->parse( { string => $embedded_css } );
    };
    if ($@) {
        # if parsing fails with fatal error,
        print $@ if ( $self->{verbose} );
        return; # false
    }
    else {
        return 1; # true
    }
}

sub validate_embedded_css {
    my $self = shift;
    my $embedded_css = shift;

    print "Validating embedded CSS\n" if ( $self->{verbose} );

    # write styles into temporary file
    open( my $file, '>', $self->{downloaded_css_filename} );
    print $file $embedded_css;
    close( $file );
    # validate the file
    $self->{css_validator}->validate( $self->{downloaded_css_filename} );
    # when done, delete the file
    unlink( $self->{downloaded_css_filename} );
}




sub parse_external_css {
    my $self = shift;
    my $external_css_files = shift;
    my $base_address = shift;

    my $external_css_count = 0;
    my $external_css_length = 0;
    my $parse_error_count = 0;

    foreach my $css_address ( @$external_css_files ) {

        # resolve absolute address
        $css_address = $self->convert_to_absolute_uri( $css_address, $base_address );

        # download file with wget
        print "Downloading external CSS file $css_address\n" if ( $self->{verbose} );
        if ( my $external_css = wget($css_address, $self->{downloaded_css_filename}) ) {
            # only accept downloads with 200 OK status code
            if ( $external_css->{headers}->[0] =~ m{^\s*HTTP/.*200}i ) {

                # parse css with CSS::SAC
                print "Parsing external CSS\n" if ( $self->{verbose} );
                eval {
                    $self->{css_parser}->parse( { string => $external_css->{content} } );
                };
                # if parsing fails with fatal error,
                if ($@)
                {
                    print $@ if ( $self->{verbose} );
                    $parse_error_count++;
                }

                # Validate stylesheet
                print "Validating external CSS\n" if ( $self->{verbose} );
                $self->{css_validator}->validate( $self->{downloaded_css_filename} );
                # erase downloaded file
                unlink( $self->{downloaded_css_filename} );

                # parse all imported stylesheets
                my $parse_result = $self->parse_external_css(
                    $self->{css_handler}->get_imported_stylesheets,
                    $external_css->{downloaded_address}
                );

                # increment the count and length of external css files
                $external_css_count += $parse_result->{count};
                $external_css_length += $parse_result->{length};
                $parse_error_count += $parse_result->{parse_errors};
                # add the size of current file too
                $external_css_length += length( $external_css->{content} );
            }
        }
        # the count is incremented even if download failed
        $external_css_count++;
    }

    # return the count of css files
    return {
        count => $external_css_count,
        length => $external_css_length,
        parse_errors => $parse_error_count,
    };
}




# Validates downloaded CSS file.
# Commits results to database and cleans validator up after done.
sub commit_css_validation_results {
    my $self = shift;
    my $webpage_id = shift;

    $self->{css_validator}->set_current_page_id( $webpage_id );
    $self->{css_validator}->commit();

    if ( $self->{verbose} ) {
        if ( $self->{css_validator}->is_valid ) {
            print "\033[32mVALID\033[0m CSS :)\n";
        }
        else {
            print "\033[31mINVALID\033[0m CSS :( " . $self->{css_validator}->get_error_count . " errors.\n" 
        }
    }

    $self->{css_validator}->init_statistical_attributes();
}




# Parses inline, embedded and external JavaScript.
# commits results to database and cleans all up.
sub parse_javascript {
    my $self = shift;
    my $html_address = shift;
    my $webpage_id = shift;

    # Gather all javascript together

    # get inline JS
    my $inline_js = $self->{html_parser}->get_inline_javascript;
    my $inline_js_length = length($inline_js);

    # get embedded JS
    my $embedded_js = $self->{html_parser}->get_embedded_javascript;
    my $embedded_js_length = length($embedded_js);

    # get external JS filenames
    my $external_js_files = $self->{html_parser}->get_external_javascript;

    # Download all external JS
    my $external_js = "";
    my $external_js_count = 0;
    foreach my $js_address ( @$external_js_files ) {
        # resolve absolute address
        $js_address = $self->convert_to_absolute_uri( $js_address, $html_address );

        # download file contents with wget (erase file after download)
        print "Downloading external JavaScript file $js_address\n" if ( $self->{verbose} );
        if ( my $downloaded_js = wget($js_address, undef, 1) ) {
            # only accept downloads with 200 OK status code
            if ( $downloaded_js->{headers}->[0] =~ m{^\s*HTTP/.*200}i ) {
                $external_js .= $downloaded_js->{content};
            }
        }
        $external_js_count++;
    }
    my $external_js_length = length($external_js);

    # Concatenate all JavaScript together
    my $js = $inline_js . $embedded_js . $external_js;

    # search for XMLHttpRequest
    my $xml_http_request = 'N';
    if ( $js =~ /XMLHttpRequest/s ) {
        print "Found XMLHttpRequest.\n" if ( $self->{verbose} );
        $xml_http_request = 'Y';
    }
     
# for some unknown reason we get Segmentation fault
# when parsing javascript. so we just skip the whole thing.
#
#    # Parse JavaScript
#    if ( length($js) > 0 ) {
#        print "Parsing JavaScript\n" if ( $self->{verbose} );
#        $self->{js_parser}->parse( $js );
#    }


    # commit all kind of JS counts and sizes to database
    $self->{sql}->{webpages}->{set_javascript_sizes}->execute(
        $inline_js_length,
        $embedded_js_length,
        $external_js_length,
        $external_js_count,
        $xml_http_request,  # $self->{js_parser}->get_comment_length,
        $webpage_id
    );

#    # commit JS statistics
#    $self->{js_parser}->set_current_page_id( $webpage_id );
#    $self->{js_parser}->commit();
#
#    # clean up
#    $self->{js_parser}->init_statistical_attributes();
}





# insert supplied webpage address into database and return associated ID
# if the address already exists in database, return false
sub insert_webpage_uri {
    my $self = shift;
    my $address = shift;

    if ( $self->{sql}->{webpages}->{insert}->execute( $address ) ) {
        return $self->{db}->{mysql_insertid};
    }
    else {
        return;
    }
}




sub convert_to_absolute_uri {
    my $self = shift;
    my $uri = shift;
    my $base_uri = shift;

    return URI->new_abs( $uri, $base_uri )->canonical->as_string;
}


sub normalize_uri {
    my $self = shift;
    my $uri = shift;

    return URI->new( $uri )->canonical->as_string;
}




=head1 AUTHOR

Rene Saarsoo <nene@triin.net>

This module is licensed under the same terms as Perl itself.

=cut


1;
