package WebStatistics::Wget;

use warnings;
use strict;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(wget);

=head1 NAME

WebStatistics::Wget - simple module to control downloads with wget.

=head1 SYNOPSIS

    use WebStatistics::Wget;
    
    my $site = wget( "www.example.com" );
    
    # print the actual address of the resource
    # e.g. the site might have been redirected to somewhere else.
    print "$site->{downloaded_address}\n";
    
    # print headers:
    print "--------HEADERS-----------------\n";
    foreach my $header ( @{$site->{headers}} ) {
        print $header;
    }
    
    # flush out content
    print "--------CONTENT-----------------\n";
    print $site->{content};

=head1 DESCRIPTION

This module simplifies the usage of wget program.

=head1 METHODS

At the moment this module provides only one method.

=cut






=head2 wget( $address , [ $output_file ] , [ $erase_file_after_download ] )

Retrieves the resource specified by $address.

It returns a hashreference with a similar structure to following:

$wget => {
          downloaded_address => "http://www.example.com/foo/bar.html"
          headers => [
                      "HTTP/1.0 200 OK",
                      "Server: Apache",
                      "X-Powered-By: PHP",
                      "Content-Type: text/html; charset=iso-8859-1",
                      "Content-Length: 14231",
                      ...
                     ]
          content => "<html><head><title>example page</title></he..."
         }

The routine saves the downloaded content into file specified by $output_file.
If the $tmp_file is not specified then the routine uses a filename
"._temporary-wget-file_" by default.
if $erase_file_after_download is true, then
the file is erased after the download (the default is not to erase).

=cut
sub wget {
    my $address = shift;
    my $output_file = shift || "._temporary-wget-file_";
    my $erase_file_after_download = shift || 0; # defaults to NOT erase

    my $wget_command =
        # The wget program itself
        "wget ".
        # Set number of retries to one.
        "--tries=1 ".
        # Set the network timeout to 10 seconds
        "--timeout=10 ".
        # Unfortunately, some HTTP servers send out bogus "Content-Length" headers,
        # which makes Wget go wild, as it thinks not all the document was retrieved.
        "--ignore-length ".
        # Print the headers sent by HTTP servers.
        "--server-response ".
        # save downloaded data into file
        "--output-document=$output_file ".
        # send Accept headers for application/xhtml+xml
        "--header='Accept: ".
            "application/xhtml+xml;q=0.9, ".
            "application/xml;q=0.8, ".
            "text/html;q=0.7, ".
            "text/plain;q=0.6, ".
            "text/sgml;q=0.6, ".
            "text/xml;q=0.6, ".
            "*/*;q=0.5'";

    # Download the $address with wget.
    # Send standard error into standard-output, so we can catch it.
    # the address is placed inside quotes, because it might
    # contain the & character, which tells shell to place process into background
    open(my $wget, "$wget_command '$address' 2>&1 |") || die "Can't execute wget!";


    # Read all lines of wget output into headers array
    my $headers = [];
    my $downloaded_address = $address;
    while ( <$wget> ) {
        if ( m{^--[0-9][0-9]:[0-9][0-9]:[0-9][0-9]--  (.*)$} ) {
            # it might happen, that wget makes several requests to server.
            # in that case we are interested to know,
            # which was the eventual address wget got the resource from.
            $downloaded_address = $1;
        }
        elsif ( m{^ *[0-9]* (HTTP/.*)$} ) {
            # if we meet HTTP status line,
            # then forget about all previously gathered headers,
            # and start grabbing headers that follow to this status-line.
            # This is to ignore the multiple wget requests,
            # and only save the data from the latest.
            $headers = [ $1 ];
        }
        elsif ( m{^ *[0-9]* ([0-9A-Za-z!#$%&'*+-.^_`|~]+:.*)$} ) {
            push( @$headers, $1 );
        }
        elsif ( m{^Resolving .* failed:} ) {
            # if connection has timed out, return false
            return;
        }
    }

    # grab contents of the downloaded resource at output file
    my $content="";
    if ( open( my $content_file, $output_file) ) {
        # read the file into $content
        while ( <$content_file> ) {
            $content .= $_;
        }

        if ( $erase_file_after_download ) {
            # remove the temporary file
            unlink( $output_file );
        }
    }

    # if at least one header exists, consider download successful
    if ( scalar(@$headers) > 0 ) {
        return {
            downloaded_address => $downloaded_address,
            headers => $headers,
            content => $content,
        };
    }
    else {
        # when no headers are found, download has failed
        return;
    }
}






=head1 AUTHOR

Rene Saarsoo <nene@triin.net>

This module is licensed under the same terms as Perl itself.

=cut


1;
