package WebStatistics::DBGeneral;

use warnings;
use strict;



=head2 get_id( $options )

Get the ID associated with supplied values.
This method uses database cache, to reduce
number of times required to access database

=cut
sub get_id {
    my $options = shift;

    # load parameters
    my $values = $options->{values}; # arrayref of values
    my $cache = $options->{cache};   # cache object
    my $db = $options->{db};         # database object
    my $sql = $options->{sql};       # SQL statements

    my $insert = $options->{sql}->{insert_element}; # insert statement
    my $select = $options->{sql}->{select_id}; # select statement
    my $select_null = $options->{sql}->{select_id_with_null} || undef; # select null statement

    # if value or combination of values exists in the cache,
    # return ID directly from cache
    if ( my $id = $cache->get_id( @{$values} ) ) {
        return $id;
    }
    else {
        # when values are not in the cache
        # get them from database
        my $id = get_id_from_database( $values, $db, $sql );

        # add values and id into cache
        $cache->add( @{$values}, $id );

        return $id;
    }
}




=head2 get_id_from_linking_table( $options )

The same as get_id() function, but this time the values
themselves are only used to access cache - database
access is performed using ID-s of values (supplied
through $options->{value_ids}.

=cut
sub get_id_from_linking_table {
    my $options = shift;

    # load parameters
    my $values = $options->{values};       # arrayref of values
    my $value_ids = $options->{value_ids}; # arrayref of value ID-s
    my $cache = $options->{cache};         # cache object
    my $db = $options->{db};               # database object
    my $sql = $options->{sql};             # SQL statements

    # if value or combination of values exists in the cache,
    # return ID directly from cache
    if ( my $id = $cache->get_id( @$values ) ) {
        return $id;
    }
    else {
        # when values are not in the cache
        # get them from database
        my $id = get_id_from_database( $value_ids, $db, $sql );

        # add values and id into cache
        $cache->add( @$values, $id );

        return $id;
    }
}



# Get the ID-s directly from database
sub get_id_from_database {
    my $values = shift;
    my $db = shift;
    my $sql = shift;

    my $insert = $sql->{insert_element};                    # insert statement
    my $select = $sql->{select_id};                         # select statement
    my $select_null = $sql->{select_id_with_null} || undef; # select null statement

    # try to INSERT values into the database
    if ( $insert->execute( @$values ) ) {
        # return the id of previously inserted row
        return $db->{mysql_insertid};
    }
    else {
        # when insert fails, then this means the values
        # already exist in the database

        # we use $select_null statement when the second value is NULL,
        # otherwise we use normal $select
        if ( !defined($values->[1]) && defined($select_null) ) {
            $select = $select_null;
        }

        # so we just query the database for those values
        $select->execute( @{$values} );
        my $row = $select->fetchrow_arrayref;
        $select->finish;

        # get the ID from the first field of first row
        return $row->[0];
    }
}



1;
