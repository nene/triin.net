package WebStatistics::Util;

use warnings;
use strict;



# Perl trim function to remove whitespace from the start and end of the string
sub trim {
    my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}

# Left trim function to remove leading whitespace
sub ltrim {
    my $string = shift;
    $string =~ s/^\s+//;
    return $string;
}

# Right trim function to remove trailing whitespace
sub rtrim {
    my $string = shift;
    $string =~ s/\s+$//;
    return $string;
}

# remove single or double quote from the beginning and end of the string
sub strip_quotes {
    my $text = shift;

    $text =~ s/ ^ ["']  (.*)  ["'] $ /$1/xs;

    return $text;
}

# remove begin-end quotes from values of hash
sub hash_strip_quotes {
    my %hash = @_;

    while ( my ($key, $value) = each( %hash ) ) {
        $hash{$key} = strip_quotes($value);
    }

    return %hash;
}


1;
