package WebStatistics::CSSElements;

use warnings;
use strict;
use WebStatistics::DBGeneral;
use WebStatistics::Util;
use Data::Dumper;
use CSS::SAC::Selector qw(:constants);
use CSS::SAC::Condition qw(:constants);
use CSS::SAC::LexicalUnit qw(:constants);

use vars qw(
    $RE_URL_WITH_FILE_EXTENSION
    $RE_QUOTED_STRING
    $RE_IDENT

    %STANDARD_COLORS
    %FONT_PROPERTY_KEYWORDS

);


$RE_URL_WITH_FILE_EXTENSION = qr{
    ^(?:(?:https?|s?ftp)://[^/]+/|/)?    # domain or root dir
    (?:[^/]+/)*                          # directories "....../" "..../"
    [^/]+                                # filename    "......."
    \.(\w{3,4})$                         # extension   ".0_Az"
}xsi;

$RE_QUOTED_STRING = qr{
    "[^"]*"         # text between double-quotes
    |               # or
    '[^']*'         # text between single-quotes
}xsi;

$RE_IDENT = qr{[A-Za-z0-9:_-]+};



%STANDARD_COLORS = (
    "800000" => 1,
    "ff0000" => 1,
    "ffA500" => 1,
    "ffff00" => 1,
    "808000" => 1,
    "800080" => 1,
    "ff00ff" => 1,
    "ffffff" => 1,
    "00ff00" => 1,
    "008000" => 1,
    "000080" => 1,
    "0000ff" => 1,
    "00ffff" => 1,
    "008080" => 1,
    "000000" => 1,
    "c0c0c0" => 1,
    "808080" => 1,

    "f00" => 1,
    "ff0" => 1,
    "f0f" => 1,
    "fff" => 1,
    "0f0" => 1,
    "00f" => 1,
    "0ff" => 1,
    "000" => 1,

    "255,0,0" => 1,
    "255,255,0" => 1,
    "255,0,255" => 1,
    "255,255,255" => 1,
    "0,255,0" => 1,
    "0,0,255" => 1,
    "0,255,255" => 1,
    "0,0,0" => 1,

    "100%,0,0" => 1,
    "100%,100%,0" => 1,
    "100%,0,100%" => 1,
    "100%,100%,100%" => 1,
    "0,100%,0" => 1,
    "0,0,100%" => 1,
    "0,100%,100%" => 1,
    "0,0,0" => 1,
);


%FONT_PROPERTY_KEYWORDS = (
    "caption" => 1,
    "icon" => 1,
    "menu" => 1,
    "message-box" => 1,
    "small-caption" => 1,
    "status-bar" => 1,

    "serif" => 1,
    "sans-serif" => 1,
    "cursive" => 1,
    "fantasy" => 1,
    "monospace" => 1,


    "normal" => 1,
    "italic" => 1,
    "oblique" => 1,
    "small-caps" => 1,
    "bold" => 1,
    "bolder" => 1,
    "lighter" => 1,
    "xx-small" => 1,
    "x-small" => 1,
    "small" => 1,
    "medium" => 1,
    "large" => 1,
    "x-large" => 1,
    "xx-large" => 1,
    "larger" => 1,
    "smaller" => 1,
);




# constructor
sub new {
    my $type = shift;
    my $options = shift;

    my $self = bless {}, $type;

    # manage options
    $self->{cache} = $options->{DatabaseCache} || die("No database cache specified");
    $self->{sql} = $options->{SQLStatements} || die("No SQL statements manager specified");
    $self->{current_page_id} = $options->{CurrentPageId} || 0;

    # Init statistical attributes
    $self->init_statistical_attributes();

    # Init caches
    #$self->load_all_caches();

    return $self;
}





=head2 GET and SET methods

=head3 set_current_page_id( $id )

Set the ID of current webpage in the database.

=cut
sub set_current_page_id {
    my $self = shift;
    my $current_page_id = shift;

    $self->{current_page_id} = $current_page_id || die("No current page ID specified.");
}


=head3 get_comment_length

=cut
sub get_comment_length {
    my $self = shift;

    return $self->{comment_length};
}


=head3 get_imported_stylesheets

returns reference to list of imported stylesheets.

NB! At the same time, the internal list of stylesheets is truncated.

=cut
sub get_imported_stylesheets {
    my $self = shift;

    my $imported_stylesheets = $self->{imported_stylesheets};

    $self->{imported_stylesheets} = [];

    return $imported_stylesheets;
}


=head3 get_important_count

returns the number of !important keywords.

=cut
sub get_important_count {
    my $self = shift;

    return $self->{important_count};
}




################################################################################
#
#  Initialization
#
################################################################################


=head2 init_statistical_attributes

Initialize the values of statistical attributes,
like setting comment-length to zero.

=cut
sub init_statistical_attributes {
    my $self = shift;

    $self->{comment_length} = 0;
    $self->{important_count} = 0;
    $self->{imported_stylesheets} = [];
}





################################################################################
#
# Event handlers: General
#
################################################################################


sub start_selector {
    my $self = shift;
    my $selector_list = shift;

    # save all selector types
    foreach my $selector (@$selector_list) {
        $self->parse_selector( $selector );
    }
}




sub property {
    my $self = shift;
    my $name = shift;
    my $value = shift;
    my $important = shift;
    
    # the case of CSS properties doesn't matter,
    # so convert to lowercase
    $name = lc($name);

    # if name is missing
    if ($name eq "") {
        $name = "~MISSING~";
    }

    # increment count
    $self->{cache}->{css_properties}->increment_count( $name );

    # Save property values based on some rules
    foreach my $property_value ( @{$value} ) {
        $self->parse_property_value( $name, $property_value );
    }

    # Count all appearances of !important
    if ( $important ) {
        $self->{important_count}++;
    }

}




sub comment {
    my $self = shift;
    my $text = shift;

    # Measure the size of all comments
    $self->{comment_length} += length($text);
}





################################################################################
#
# Event handlers: at-rules
#
################################################################################

# @media
sub start_media {
    my $self = shift;
    my $media_list = shift;

    my $at_rule = '@media';
    my $parameters = lc(join(", ", @$media_list)) || "";
    $self->get_at_rule_id( $at_rule, $parameters );
    $self->{cache}->{css_at_rules}->increment_count( $at_rule, $parameters );
}


# @font-face
sub start_font_face {
    my $self = shift;

    my $at_rule = '@font-face';
    my $parameters = "";
    $self->get_at_rule_id( $at_rule, $parameters );
    $self->{cache}->{css_at_rules}->increment_count( $at_rule, $parameters );
}


# @page
sub start_page {
    my $self = shift;
    my $name = shift;
    my $pseudo = shift;

    my $at_rule = '@page';
    my $parameters = lc($pseudo) || "";
    $self->get_at_rule_id( $at_rule, $parameters );
    $self->{cache}->{css_at_rules}->increment_count( $at_rule, $parameters );
}


# @import
sub import_style {
    my $self = shift;
    my $uri = shift;
    my $media_list = shift;

    # Store URI-s for later
    push( @{$self->{imported_stylesheets}} , $uri );

    my $at_rule = '@import';
    my $parameters = lc(join(", ", @$media_list)) || "";
    $self->get_at_rule_id( $at_rule, $parameters );
    $self->{cache}->{css_at_rules}->increment_count( $at_rule, $parameters );
}


# @charset
sub charset {
    my $self = shift;
    my $charset = shift;

    my $at_rule = '@charset';
    my $parameters = lc($charset);
    $self->get_at_rule_id( $at_rule, $parameters );
    $self->{cache}->{css_at_rules}->increment_count( $at_rule, $parameters );
}


# @?unknown?
sub ignorable_at_rule {
    my $self = shift;
    my $at_rule = shift;

    # @import
    if ( $at_rule =~ s{^\@import}{}xsi ) {

        # parse out URI
        my $uri;
        if ( $at_rule =~ s{^\s+ ($RE_QUOTED_STRING) }{}xsi ) {
            # uri is simple string: "style.css"
            $uri = WebStatistics::Util::strip_quotes( $1 );
        }
        elsif ( $at_rule =~ s{^\s+ url\( \s* ($RE_QUOTED_STRING) \s* \) }{}xsi ) {
            # uri is string inside url() function: url("style.css")
            $uri = WebStatistics::Util::strip_quotes( $1 );
        }
        elsif ( $at_rule =~ s{^\s+  url\( \s* ([^)]+?) \s* \)  }{}xsi ) {
            # uri is inside url() function: url(style.css)
            $uri = $1;
        }
        else {
            # error
            return;
        }

        # parse out media-list
        my @media_list;
        while ( $at_rule =~ s{^\s+  ([a-z]+) \s* [,;]  }{}xsi ) {
            push( @media_list, $1 );
        }

        $self->import_style( $uri, \@media_list );
    }

    # @charset
    elsif ( $at_rule =~ s{^\@charset}{}xsi ) {
        # get the character-set
        if ( $at_rule =~ s{^\s+ ($RE_QUOTED_STRING) }{}xsi ) {
            # uri is simple string: "style.css"
            my $charset = WebStatistics::Util::strip_quotes( $1 );
            $self->charset( $charset );
        }
        else {
            # error
            return;
        }
    }

    # all other at-rules
    elsif ( $at_rule =~ s{^ \@ ($RE_IDENT) }{}xsi ) {
        my $at_rule = '@'. lc($1);
        my $parameters = "";
        $self->get_at_rule_id( $at_rule, $parameters );
        $self->{cache}->{css_at_rules}->increment_count( $at_rule, $parameters );
    }
}




=head2 commit

Commit counts of CSS properties and selectors.

=cut
sub commit {
    my $self = shift;

    $self->commit_properties();
    $self->commit_property_values();
    $self->commit_selector_types();
    $self->commit_selector_parameters();
    $self->commit_element_selectors();
    $self->commit_class_selectors();
    $self->commit_id_selectors();
    $self->commit_at_rules();
}



=head2 commit_properties

Add cached property counts to database.

NB! This method also resets the counts of properties.

=cut
sub commit_properties {
    my $self = shift;

    $self->generic_commit( "css_properties" );
}




=head2 commit_property_values

Add cached property value counts to database.

NB! This method also resets the counts of property values.

=cut
sub commit_property_values {
    my $self = shift;

    $self->generic_commit( "css_property_values" );
}




=head2 commit_selector_types

Add cached selector type counts to database.

NB! This method also resets the counts of selector types.

=cut
sub commit_selector_types {
    my $self = shift;

    $self->generic_commit( "css_selector_types" );
}




=head2 commit_selector_parameters

Add cached selector parameter counts to database.

NB! This method also resets the counts of selector parameters.

=cut
sub commit_selector_parameters {
    my $self = shift;

    $self->generic_commit( "css_selector_parameters" );
}




=head2 commit_element_selectors

Add cached html element selector counts to database.

NB! This method also resets the counts of element selectors.

=cut
sub commit_element_selectors {
    my $self = shift;

    $self->generic_commit( "html_element_selectors" );
}




=head2 commit_class_selectors

Add cached class selectors to database.

=cut
sub commit_class_selectors {
    my $self = shift;

    $self->{cache}->{css_class_selectors}->commit_pagecounts(
        $self->{sql}->{css_class_selectors}->{insert_webpage_element}
    );
}




=head2 commit_id_selectors

Add cached id selectors to database.

=cut
sub commit_id_selectors {
    my $self = shift;

    $self->{cache}->{css_id_selectors}->commit_pagecounts(
        $self->{sql}->{css_id_selectors}->{insert_webpage_element}
    );
}




=head2 commit_at_rules

Add cached at rule counts to database.

NB! This method also resets the counts of element selectors.

=cut
sub commit_at_rules {
    my $self = shift;

    $self->generic_commit( "css_at_rules" );
}





sub generic_commit {
    my $self = shift;
    my $item_name = shift;

    $self->{cache}->{$item_name}->commit(
        $self->{current_page_id},
        $self->{sql}->{$item_name}->{insert_webpage_element}
    );
}



################################################################################
#
#  Cache Initialization
#
################################################################################


# Initsializes all caches, using the routines listed below
sub load_all_caches {
    my $self = shift;

    $self->load_properties();
    $self->load_values();
    $self->load_property_values();

    $self->load_selector_types();
    $self->load_selector_parameters();
    $self->load_element_selectors();
}


# Read the CSS properties from database and store into cache
sub load_properties {
    my $self = shift;

    $self->generic_load( "css_properties" );
}


# Read the CSS property values from database and store into cache
sub load_property_values {
    my $self = shift;

    $self->{sql}->{css_property_values}->{select_all}->execute;

    while ( my $property_value = $self->{sql}->{css_property_values}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{css_property_values}->add(
            $property_value->{name},
            $property_value->{value},
            $property_value->{id}
        );
    }
}


# Read the CSS values from database and store into cache
sub load_values {
    my $self = shift;

    $self->generic_load( "css_values" );
}


# Read the CSS selector types from database and store into cache
sub load_selector_types {
    my $self = shift;

    $self->generic_load( "css_selector_types" );
}


# Read the CSS selector parameters from database and store into cache
sub load_selector_parameters {
    my $self = shift;

    $self->generic_load( "css_selector_parameters" );
}


# Read the HTML element selectors from database and store into cache
sub load_element_selectors {
    my $self = shift;

    $self->generic_load( "html_element_selectors" );
}


sub generic_load {
    my $self = shift;
    my $item_name = shift;

    $self->{sql}->{$item_name}->{select_all}->execute;

    while ( my $selector_type = $self->{sql}->{$item_name}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{$item_name}->add(
            $selector_type->{name},
            $selector_type->{id}
        );
    }
}



################################################################################
#
# Selectors parsing
#
################################################################################


# Identify different selector types within one selector
# and feed them to save_selector() for saving.
sub parse_selector {
    my $self = shift;
    my $selector = shift;

    if ( $selector->is_type(ANY_NODE_SELECTOR) ) {
        # *
        $self->save_selector("ANY_NODE_SELECTOR");
    }
    elsif ( $selector->is_type(ELEMENT_NODE_SELECTOR) ) {
        if ( defined( $selector->LocalName ) ) {
            $self->save_selector(
                "ELEMENT_NODE_SELECTOR",
                lc($selector->LocalName)
            );
        }
    }
    elsif ( $selector->is_type(DESCENDANT_SELECTOR) ) {
        $self->parse_selector( $selector->SimpleSelector );
        $self->save_selector("DESCENDANT_SELECTOR");
        $self->parse_selector( $selector->AncestorSelector );
    }
    elsif ( $selector->is_type(CHILD_SELECTOR) ) {
        # >
        $self->parse_selector( $selector->SimpleSelector );
        $self->save_selector("CHILD_SELECTOR");
        $self->parse_selector( $selector->AncestorSelector );
    }
    elsif ( $selector->is_type(DIRECT_ADJACENT_SELECTOR) ) {
        # +
        $self->parse_selector( $selector->Selector );
        $self->save_selector("DIRECT_ADJACENT_SELECTOR");
        $self->parse_selector( $selector->SiblingSelector );
    }
    elsif ( $selector->is_type(INDIRECT_ADJACENT_SELECTOR) ) {
        # ~
        $self->parse_selector( $selector->Selector );
        $self->save_selector("INDIRECT_ADJACENT_SELECTOR");
        $self->parse_selector( $selector->SiblingSelector );
    }
    elsif ( $selector->is_type(CONDITIONAL_SELECTOR) ) {
        $self->parse_selector( $selector->SimpleSelector );
        $self->parse_condition( $selector->Condition );
    }
    elsif ( $selector->is_type(PSEUDO_ELEMENT_SELECTOR) ) {
        $self->parse_pseudo_class_selector( $selector->LocalName );
    }
}


# subsection of parse_selector, for parsing conditions
sub parse_condition {
    my $self = shift;
    my $condition = shift;

    if ( $condition->is_type(CLASS_CONDITION) ) {
        $self->save_selector(
            "CLASS_SELECTOR",
            lc($condition->Value)  # classnames are case-sensitive, but our research doesn't care
        );
    }
    elsif ( $condition->is_type(ID_CONDITION) ) {
        $self->save_selector(
            "ID_SELECTOR",
            lc($condition->Value)  # ID-s are case-sensitive, but our research doesn't care
        );
    }
    elsif ( $condition->is_type(ATTRIBUTE_CONDITION) ) {
        if ( $condition->Specified ) {
            $self->save_selector(
                "EQUALS_ATTRIBUTE_SELECTOR",
                '['. lc($condition->LocalName) .'="' . $condition->Value . '"]'
            );
        }
        else {
            $self->save_selector(
                "ATTRIBUTE_SELECTOR",
                '['. lc($condition->LocalName) .']'
            );
        }
    }
    elsif ( $condition->is_type(BEGIN_HYPHEN_ATTRIBUTE_CONDITION) ) {
        $self->save_selector(
            "BEGIN_HYPHEN_ATTRIBUTE_SELECTOR",
            '['. lc($condition->LocalName) .'|="?"]'
        );
    }
    elsif ( $condition->is_type(ONE_OF_ATTRIBUTE_CONDITION) ) {
        $self->save_selector(
            "ONE_OF_ATTRIBUTE_SELECTOR",
            '['. lc($condition->LocalName) .'~="?"]'
        );
    }
    elsif ( $condition->is_type(STARTS_WITH_ATTRIBUTE_CONDITION) ) {
        $self->save_selector(
            "STARTS_WITH_ATTRIBUTE_SELECTOR",
            '['. lc($condition->LocalName) .'^="?"]'
        );
    }
    elsif ( $condition->is_type(ENDS_WITH_ATTRIBUTE_CONDITION) ) {
        $self->save_selector(
            "ENDS_WITH_ATTRIBUTE_SELECTOR",
            '['. lc($condition->LocalName) .'$="?"]'
        );
    }
    elsif ( $condition->is_type(CONTAINS_ATTRIBUTE_CONDITION) ) {
        $self->save_selector(
            "CONTAINS_ATTRIBUTE_SELECTOR",
            '['. lc($condition->LocalName) .'*="?"]'
        );
    }

    elsif ( $condition->is_type(PSEUDO_CLASS_CONDITION) ) {
        $self->parse_pseudo_class_selector( $condition->Value );
    }
    elsif ( $condition->is_type(LANG_CONDITION) ) {
        $self->save_selector(
            "LANGUAGE_PSEUDO_CLASS",
            ":lang(" . lc($condition->Lang) . ")"
        );
    }
    elsif ( $condition->is_type(CONTENT_CONDITION) ) {
        # :contains()
        $self->save_selector( "CONTENT_PSEUDO_CLASS" );
    }
    elsif ( $condition->is_type(NEGATIVE_CONDITION) ) {
        # :not()
        $self->save_selector( "NEGATION_PSEUDO_CLASS" );
        $self->parse_selector( $condition->Condition );
    }
    elsif ( $condition->is_type(IS_ROOT_CONDITION) ) {
        # :root
        $self->save_selector( "ROOT_PSEUDO_CLASS" );
    }
    elsif ( $condition->is_type(IS_EMPTY_CONDITION) ) {
        # :empty
        $self->save_selector( "EMPTY_PSEUDO_CLASS" );
    }

    elsif ( $condition->is_type(AND_CONDITION) ) {
        if (
            $condition->FirstCondition->is_type(POSITIONAL_CONDITION) &&
            $condition->FirstCondition->Position == 1 &&
            $condition->SecondCondition->is_type(POSITIONAL_CONDITION) &&
            $condition->SecondCondition->Position == -1
        ) {
            if ( $condition->FirstCondition->Type ) {
                $self->save_selector( "ONLY_OF_TYPE_PSEUDO_CLASS" );
            }
            else {
                $self->save_selector( "ONLY_CHILD_PSEUDO_CLASS" );
            }
        }
        else {
            $self->parse_condition( $condition->FirstCondition );
            $self->parse_condition( $condition->SecondCondition );
        }

    }
    elsif ( $condition->is_type(POSITIONAL_CONDITION) ) {
        if ($condition->Position == 1 ) {
            if ( $condition->Type ) {
                $self->save_selector( "FIRST_OF_TYPE_PSEUDO_CLASS" );
            }
            else {
                $self->save_selector( "FIRST_CHILD_PSEUDO_CLASS" );
            }
        }
        elsif ($condition->Position == -1 ) {
            if ( $condition->Type ) {
                $self->save_selector( "LAST_OF_TYPE_PSEUDO_CLASS" );
            }
            else {
                $self->save_selector( "LAST_CHILD_PSEUDO_CLASS" );
            }
        }
        elsif ($condition->Position >= 0 ) {
            if ( $condition->Type ) {
                $self->save_selector(
                    "NTH_OF_TYPE_PSEUDO_CLASS",
                    ":nth-of-type(" . $condition->Position . ")"
                );
            }
            else {
                $self->save_selector(
                    "NTH_CHILD_PSEUDO_CLASS",
                    ":nth-child(" . $condition->Position . ")" );
            }
        }
        elsif ($condition->Position < 0 ) {
            if ( $condition->Type ) {
                $self->save_selector(
                    "NTH_LAST_OF_TYPE_PSEUDO_CLASS",
                    ":nth-last-of-type(" . (- $condition->Position) . ")"
                );
            }
            else {
                $self->save_selector(
                    "NTH_LAST_CHILD_PSEUDO_CLASS",
                    ":nth-last-of-type(" . (- $condition->Position) . ")"
                );
            }
        }
    }

    else {
        # Ignore all others
        $self->save_selector( "UNKNOWN_SELECTOR" );
    }

}


# another subsection of parse_selector for parsing pseudo-classes
# (and also pseudo-elements, as we don't really differentiate between them)
sub parse_pseudo_class_selector {
    my $self = shift;
    my $text = shift;

    $text = lc($text);

    if ( $text eq "link" ) {
        $self->save_selector("UNVISITED_LINK_PSEUDO_CLASS");
    }
    elsif ( $text eq "visited" ) {
        $self->save_selector("VISITED_LINK_PSEUDO_CLASS");
    }
    elsif ( $text eq "active" ) {
        $self->save_selector("ACTIVE_PSEUDO_CLASS");
    }
    elsif ( $text eq "hover" ) {
        $self->save_selector("HOVER_PSEUDO_CLASS");
    }
    elsif ( $text eq "focus" ) {
        $self->save_selector("FOCUS_PSEUDO_CLASS");
    }
    elsif ( $text eq "target" ) {
        $self->save_selector("TARGET_PSEUDO_CLASS");
    }
    elsif ( $text eq "enabled" ) {
        $self->save_selector("ENABLED_PSEUDO_CLASS");
    }
    elsif ( $text eq "disabled" ) {
        $self->save_selector("DISABLED_PSEUDO_CLASS");
    }
    elsif ( $text eq "checked" ) {
        $self->save_selector("CHECKED_PSEUDO_CLASS");
    }
    elsif ( $text eq "indeterminate" ) {
        $self->save_selector("INDETERMINATE_PSEUDO_CLASS");
    }
    elsif ( $text eq "first-line" ) {
        $self->save_selector("FIRST_LINE_PSEUDO_ELEMENT");
    }
    elsif ( $text eq "first-letter" ) {
        $self->save_selector("FIRST_LETTER_PSEUDO_ELEMENT");
    }
    elsif ( $text eq "selection" ) {
        $self->save_selector("SELECTION_PSEUDO_ELEMENT");
    }
    elsif ( $text eq "before" ) {
        $self->save_selector("BEFORE_PSEUDO_ELEMENT");
    }
    elsif ( $text eq "after" ) {
        $self->save_selector("AFTER_PSEUDO_ELEMENT");
    }
    else {
        $self->save_selector("UNKNOWN_PSEUDO_CLASS", ":" . $text);
    }
}


# Saves the selector type and value (if provided) into cache
sub save_selector {
    my $self = shift;
    my $selector_type = shift;
    my $selector_parameter = shift;

    # Save selector type
    $self->get_selector_type_id($selector_type);
    $self->{cache}->{css_selector_types}->increment_count($selector_type);

    if ( $selector_type eq "ELEMENT_NODE_SELECTOR" ) {
        # Save element name
        $self->get_element_selector_id($selector_parameter);
        $self->{cache}->{html_element_selectors}->increment_count($selector_parameter);
    }
    elsif ( $selector_type eq "CLASS_SELECTOR" ) {
        # Save class name
        $self->get_class_selector_id($selector_parameter);
        $self->{cache}->{css_class_selectors}->add($selector_parameter, 1);
    }
    elsif ( $selector_type eq "ID_SELECTOR" ) {
        # Save ID name
        $self->get_id_selector_id($selector_parameter);
        $self->{cache}->{css_id_selectors}->add($selector_parameter, 1);
    }
    elsif ( defined($selector_parameter) ) {
        # Save selector parameter value
        $self->get_selector_parameter_id($selector_parameter);
        $self->{cache}->{css_selector_parameters}->increment_count($selector_parameter);
    }
}





################################################################################
#
# Property parsing
#
################################################################################


# Parses a single CSS property value.
# It extracts information needed for our investigation and
# calls save_property_value() to save this data.
sub parse_property_value {
    my $self = shift;
    my $name = shift; # property name
    my $value = shift; # propery value

    # Dimensions
    if (
        $value->is_type(CENTIMETER) ||
        $value->is_type(DEGREE) ||
        $value->is_type(DIMENSION) ||
        $value->is_type(EM) ||
        $value->is_type(EX) ||
        $value->is_type(GRADIAN) ||
        $value->is_type(HERTZ) ||
        $value->is_type(INCH) ||
        $value->is_type(KILOHERTZ) ||
        $value->is_type(MILLIMETER) ||
        $value->is_type(MILLISECOND) ||
        $value->is_type(PERCENTAGE) ||
        $value->is_type(PICA) ||
        $value->is_type(PIXEL) ||
        $value->is_type(POINT) ||
        $value->is_type(RADIAN) ||
        $value->is_type(SECOND)
    ) {
        $self->save_property_value( $name, lc($value->DimensionUnitText) );
    }

    # Functions
    elsif (
        $value->is_type(ATTR) ||
        $value->is_type(COUNTER_FUNCTION) ||
        $value->is_type(COUNTERS_FUNCTION) ||
        $value->is_type(FUNCTION) ||
        $value->is_type(RECT_FUNCTION)
    ) {
        $self->save_property_value( $name, lc($value->FunctionName) . "()" );
    }
    elsif ( $value->is_type(URI) ) {
        # Extract file extension
        if ( $value->Value->[0]->Value =~ $RE_URL_WITH_FILE_EXTENSION ) {
            $self->save_property_value( $name, "url(" . lc($1) . ")" );
        }
        else {
            $self->save_property_value( $name, "url()" );
        }
    }
    elsif ( $value->is_type(RGBCOLOR) ) {
        # Extract common colors
        if ( ref($value->Value) eq "ARRAY" ) {
            # if rgb function contains three numbers and two commas
            if ( scalar( @{$value->Value} ) == 5 ) {
                my $rgb = "";
                $rgb.= $value->Value->[0]->Value;
                $rgb.= $value->Value->[0]->DimensionUnitText if $value->Value->[0]->is_type(PERCENTAGE) && $value->Value->[0]->Value > 0;
                $rgb.= ",";
                $rgb.= $value->Value->[2]->Value;
                $rgb.= $value->Value->[2]->DimensionUnitText if $value->Value->[0]->is_type(PERCENTAGE) && $value->Value->[0]->Value > 0;
                $rgb.= ",";
                $rgb.= $value->Value->[4]->Value;
                $rgb.= $value->Value->[4]->DimensionUnitText if $value->Value->[0]->is_type(PERCENTAGE) && $value->Value->[0]->Value > 0;

                if ( exists($STANDARD_COLORS{$rgb}) ) {
                    $self->save_property_value( $name, "rgb(" . $rgb . ")" );
                }
                else {
                    $self->save_property_value( $name, "rgb()" );
                }
            }
        }
        else {
            my $hex_color = lc($value->Value);
            if ( length($hex_color) == 3 ) {
                if ( exists($STANDARD_COLORS{$hex_color}) ) {
                    $self->save_property_value( $name, "#" . $hex_color );
                }
                else {
                    $self->save_property_value( $name, "#rgb" );
                }
            }
            else {
                if ( exists($STANDARD_COLORS{$hex_color}) ) {
                    $self->save_property_value( $name, "#" . $hex_color );
                }
                else {
                    $self->save_property_value( $name, "#rrggbb" );
                }
            }
        }
    }

    # Identifiers
    elsif ( $value->is_type(IDENT) ) {
        # We treat values font-family and font properties differently
        if ( $name eq "font-family" || $name eq "font" ) {
            # if the value is one of known keywords, save the value in an ordinary way.
            # Otherwise the value probably(!) designates a font family name,
            # and we surround it with quotes
            if ( exists( $FONT_PROPERTY_KEYWORDS{$value->Value} ) ) {
                $self->save_property_value( $name, lc($value->Value) );
            }
            else {
                $self->save_property_value( $name, '"' . lc($value->Value) . '"' );
            }
        }
        else {
            $self->save_property_value( $name, lc($value->Value) );
        }
    }
    elsif ( $value->is_type(INHERIT) ) {
        $self->save_property_value( $name, "INHERIT" );
    }

    # Strings
    # Here we will only count string values, that aren't inside url() function if CSS
    elsif ( $value->is_type(STRING_VALUE) ) {
        # because string values in stylesheets (apart from URI-s and font names)
        # are used wery little, we capture all of these... might find something
        # interesting. For example this gives us opportunity to count "\"}\"" - hacks :)
        # And just in case, we convert calues to lowercase.
        $self->save_property_value( $name, '"'.lc($value->Value).'"' );

        # if the above turns out unappropriate, we might just use statement below instead
        # $self->save_property_value( "STRING_VALUE" );
    }

    # Numbers
    elsif ( $value->is_type(INTEGER) ) {
        $self->save_property_value( $name, "INTEGER" );
    }
    elsif ( $value->is_type(REAL) ) {
        $self->save_property_value( $name, "REAL" );
    }
}


sub save_property_value {
    my $self = shift;
    my $name = shift;
    my $value = shift;

    #print "$name: $value\n";


    # grab all the ID-s from database and increment all counts

    my $name_id = $self->get_property_id($name);
    $self->{cache}->{css_properties}->increment_count($name);

    my $value_id = $self->get_value_id($value);
    $self->{cache}->{css_values}->increment_count($value);

    my $property_value_id = $self->get_property_value_id($name, $value, $name_id, $value_id);
    $self->{cache}->{css_property_values}->increment_count($name, $value);
}




################################################################################
#
# GET ID methods
#
################################################################################


sub get_property_id {
    my $self = shift;
    my $property = shift;

    return $self->generic_get_id( "css_properties", [ $property ] );
}

sub get_value_id {
    my $self = shift;
    my $value = shift;

    return $self->generic_get_id( "css_values", [ $value ] );
}

sub get_selector_type_id {
    my $self = shift;
    my $selector_type = shift;

    return $self->generic_get_id( "css_selector_types", [ $selector_type ] );
}

sub get_selector_parameter_id {
    my $self = shift;
    my $selector_parameter = shift;

    return $self->generic_get_id( "css_selector_parameters", [ $selector_parameter ] );
}

sub get_element_selector_id {
    my $self = shift;
    my $html_element = shift;

    return $self->generic_get_id( "html_element_selectors", [ $html_element ] );
}

sub get_class_selector_id {
    my $self = shift;
    my $class_name = shift;

    return $self->generic_get_id( "css_class_selectors", [ $class_name ] );
}

sub get_id_selector_id {
    my $self = shift;
    my $id_name = shift;

    return $self->generic_get_id( "css_id_selectors", [ $id_name ] );
}

sub get_at_rule_id {
    my $self = shift;
    my $at_rule = shift;
    my $parameters = shift;

    return $self->generic_get_id( "css_at_rules", [ $at_rule, $parameters ] );
}

sub generic_get_id {
    my $self = shift;
    my $item_name = shift;
    my $values = shift;

    return WebStatistics::DBGeneral::get_id( {
        values => $values,
        cache => $self->{cache}->{$item_name},
        db => $self->{sql}->{db},
        sql => $self->{sql}->{$item_name},
    } );
}



sub get_property_value_id {
    my $self = shift;
    my $element = shift;
    my $value = shift;
    my $element_id = shift;
    my $value_id = shift;

    return WebStatistics::DBGeneral::get_id_from_linking_table( {
        values => [$element, $value],
        value_ids => [$element_id, $value_id],
        cache => $self->{cache}->{css_property_values},
        db => $self->{sql}->{db},
        sql => $self->{sql}->{css_property_values},
    } );
}























1;
