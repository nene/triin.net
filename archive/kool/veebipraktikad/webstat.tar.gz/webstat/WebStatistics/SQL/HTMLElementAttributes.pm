package WebStatistics::SQL::HTMLElementAttributes;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);
# SQL for handling HTML Element Attributes

$SQL_SELECT_ALL = "
    SELECT
        html_element_attribute_id,
        html_element_name,
        html_attribute_name
    FROM
        html_elements
    NATURAL JOIN
        html_element_attributes
    NATURAL JOIN
        html_attributes
";

$SQL_SELECT_ID = "
    SELECT
        html_element_attribute_id
    FROM
        html_element_attributes
    WHERE
        html_element_id = ? AND
        html_attribute_id = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO html_element_attributes (
        html_element_attribute_id,
        html_element_id,
        html_attribute_id
    )
    VALUES (
        '',
        ?,
        ?
    )
";

$SQL_INSERT_WEBPAGE_ELEMENT = "
    INSERT INTO webpage_html_element_attributes (
        webpage_id,
        html_element_attribute_id,
        webpage_html_element_attribute_count
    )
    VALUES (
        ?,
        ?,
        ?
    )
";





# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

