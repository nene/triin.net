package WebStatistics::SQL::Encodings;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

# SQL for handling Encodings

$SQL_SELECT_ALL = "
    SELECT
        encoding_id,
        encoding_name
    FROM
        encodings
";

$SQL_SELECT_ID = "
    SELECT
        encoding_id
    FROM
        encodings
    WHERE
        encoding_name = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO encodings (
        encoding_id,
        encoding_name
    )
    VALUES (
        '',
        ?
    )
";

# although it's actually an UNPDATE statement, we call it INSERT for consistency
$SQL_INSERT_WEBPAGE_ELEMENT = "
    UPDATE webpages
    SET
        encoding_id = ?
    WHERE
        webpage_id = ? AND
        encoding_id is NULL
";






# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

