package WebStatistics::SQL::CSSAtRules;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

$SQL_SELECT_ALL = "
    SELECT
        css_at_rule_id,
        css_at_rule_name,
        css_at_rule_parameters
    FROM
        css_at_rules
";

$SQL_SELECT_ID = "
    SELECT
        css_at_rule_id
    FROM
        css_at_rules
    WHERE
        css_at_rule_name = ? AND
        css_at_rule_parameters = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO css_at_rules (
        css_at_rule_id,
        css_at_rule_name,
        css_at_rule_parameters
    )
    VALUES (
        '',
        ?,
        ?
    )
";

$SQL_INSERT_WEBPAGE_ELEMENT = "
    INSERT INTO webpage_css_at_rules (
        webpage_id,
        css_at_rule_id,
        webpage_css_at_rule_count
    )
    VALUES (
        ?,
        ?,
        ?
    )
";



# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

