package WebStatistics::SQL::Webpages;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_INSERT
    $SQL_SET_HTML_SIZES
    $SQL_SET_CSS_SIZES
    $SQL_SET_JAVASCRIPT_SIZES
);

# SQL for managing the webpages table

$SQL_INSERT = "
    INSERT INTO webpages (
        webpage_uri
    )
    VALUES (
        ?
    )
";

$SQL_SET_HTML_SIZES = "
    UPDATE webpages SET
        webpage_filesize = ?,
        webpage_textsize = ?,
        webpage_commentsize = ?,
        webpage_html_error_count = ?
    WHERE
        webpage_id = ?
";

$SQL_SET_CSS_SIZES = "
    UPDATE webpages SET
        webpage_css_inline_size = ?,
        webpage_css_embedded_size = ?,
        webpage_css_external_size = ?,
        webpage_css_external_count = ?,
        webpage_css_comment_size = ?,
        webpage_css_important_count = ?,
        webpage_css_parse_error_count = ?,
        webpage_css_error_count = ?
    WHERE
        webpage_id = ?
";

$SQL_SET_JAVASCRIPT_SIZES = "
    UPDATE webpages SET
        webpage_javascript_inline_size = ?,
        webpage_javascript_embedded_size = ?,
        webpage_javascript_external_size = ?,
        webpage_javascript_external_count = ?,
        webpage_javascript_xml_http_request = ?
    WHERE
        webpage_id = ?
";




# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{insert} =
        $db->prepare( $SQL_INSERT );
    $self->{set_html_sizes} =
        $db->prepare( $SQL_SET_HTML_SIZES );
    $self->{set_css_sizes} =
        $db->prepare( $SQL_SET_CSS_SIZES );
    $self->{set_javascript_sizes} =
        $db->prepare( $SQL_SET_JAVASCRIPT_SIZES );

    return $self;
}

