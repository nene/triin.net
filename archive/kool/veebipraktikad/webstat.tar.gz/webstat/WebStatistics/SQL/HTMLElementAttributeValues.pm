package WebStatistics::SQL::HTMLElementAttributeValues;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

# SQL for handling HTML Element Attribute Values

$SQL_SELECT_ALL = "
    SELECT
        html_element_attribute_value_id,
        html_element_name,
        html_attribute_name,
        html_attribute_value_value
    FROM
        html_elements
    NATURAL JOIN
        html_element_attributes
    NATURAL JOIN
        html_attributes
    JOIN
        html_element_attribute_values ON
            html_element_attributes.html_element_attribute_id =
            html_element_attribute_values.html_element_attribute_id
    JOIN
        html_attribute_values ON
            html_element_attribute_values.html_attribute_value_id =
            html_attribute_values.html_attribute_value_id
";

$SQL_SELECT_ID = "
    SELECT
        html_element_attribute_value_id
    FROM
        html_element_attribute_values
    WHERE
        html_element_attribute_id = ? AND
        html_attribute_value_id = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO html_element_attribute_values (
        html_element_attribute_value_id,
        html_element_attribute_id,
        html_attribute_value_id
    )
    VALUES (
        '',
        ?,
        ?
    )
";

$SQL_INSERT_WEBPAGE_ELEMENT = "
    INSERT INTO webpage_html_element_attribute_values (
        webpage_id,
        html_element_attribute_value_id,
        webpage_html_element_attribute_value_count
    )
    VALUES (
        ?,
        ?,
        ?
    )
";





# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

