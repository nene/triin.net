package WebStatistics::SQL::Doctypes;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

# SQL for handling DOCTYPEs

$SQL_SELECT_ALL = "
    SELECT
        doctype_id,
        root_element,
        doctype_fpi,
        doctype_si
    FROM
        doctypes
";

$SQL_SELECT_ID = "
    SELECT
        doctype_id
    FROM
        doctypes
    WHERE
        root_element = ? AND
        doctype_fpi = ? AND
        doctype_si = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO doctypes (
        doctype_id,
        root_element,
        doctype_fpi,
        doctype_si
    )
    VALUES (
        '',
        ?,
        ?,
        ?
    )
";

# although it's actually an UNPDATE statement, we call it INSERT for consistency
$SQL_INSERT_WEBPAGE_ELEMENT = "
    UPDATE webpages
    SET
        doctype_id = ?
    WHERE
        webpage_id = ?
";





# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

