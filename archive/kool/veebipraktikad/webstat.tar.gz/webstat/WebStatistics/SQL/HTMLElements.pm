package WebStatistics::SQL::HTMLElements;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

$SQL_SELECT_ALL = "
    SELECT
        html_element_id,
        html_element_name
    FROM
        html_elements
";

$SQL_SELECT_ID = "
    SELECT
        html_element_id
    FROM
        html_elements
    WHERE
        html_element_name = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO html_elements (
        html_element_id,
        html_element_name
    )
    VALUES (
        '',
        ?
    )
";

$SQL_INSERT_WEBPAGE_ELEMENT = "
    INSERT INTO webpage_html_elements (
        webpage_id,
        html_element_id,
        webpage_html_element_count
    )
    VALUES (
        ?,
        ?,
        ?
    )
";




# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

