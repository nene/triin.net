package WebStatistics::SQL::General;

use warnings;
use strict;

use WebStatistics::SQL::Webpages;

use WebStatistics::SQL::CSSProperties;
use WebStatistics::SQL::CSSPropertyValues;
use WebStatistics::SQL::CSSValues;
use WebStatistics::SQL::CSSSelectorTypes;
use WebStatistics::SQL::CSSSelectorParameters;
use WebStatistics::SQL::HTMLElementSelectors;
use WebStatistics::SQL::CSSClassSelectors;
use WebStatistics::SQL::CSSIdSelectors;
use WebStatistics::SQL::CSSAtRules;

use WebStatistics::SQL::Doctypes;
use WebStatistics::SQL::Encodings;
use WebStatistics::SQL::XMLPrologs;
use WebStatistics::SQL::HTMLAttributes;
use WebStatistics::SQL::HTMLAttributeValues;
use WebStatistics::SQL::HTMLElements;
use WebStatistics::SQL::HTMLElementAttributes;
use WebStatistics::SQL::HTMLElementAttributeValues;

use WebStatistics::SQL::JavaScriptElements;

use WebStatistics::SQL::HTMLErrors;
use WebStatistics::SQL::CSSErrors;


sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # set db attribute
    $self->{db} = $db;

    # generate SQL statements

    # webpage
    $self->{webpages} = new WebStatistics::SQL::Webpages( $db );

    # CSS:
    $self->{css_properties} = new WebStatistics::SQL::CSSProperties( $db );
    $self->{css_property_values} = new WebStatistics::SQL::CSSPropertyValues( $db );
    $self->{css_values} = new WebStatistics::SQL::CSSValues( $db );
    $self->{css_selector_types} = new WebStatistics::SQL::CSSSelectorTypes( $db );
    $self->{css_selector_parameters} = new WebStatistics::SQL::CSSSelectorParameters( $db );
    $self->{html_element_selectors} = new WebStatistics::SQL::HTMLElementSelectors( $db );
    $self->{css_class_selectors} = new WebStatistics::SQL::CSSClassSelectors( $db );
    $self->{css_id_selectors} = new WebStatistics::SQL::CSSIdSelectors( $db );
    $self->{css_at_rules} = new WebStatistics::SQL::CSSAtRules( $db );

    # HTML:
    $self->{doctypes} = new WebStatistics::SQL::Doctypes( $db );
    $self->{encodings} = new WebStatistics::SQL::Encodings( $db );
    $self->{xml_prologs} = new WebStatistics::SQL::XMLPrologs( $db );
    $self->{html_attributes} = new WebStatistics::SQL::HTMLAttributes( $db );
    $self->{html_attribute_values} = new WebStatistics::SQL::HTMLAttributeValues( $db );
    $self->{html_elements} = new WebStatistics::SQL::HTMLElements( $db );
    $self->{html_element_attributes} = new WebStatistics::SQL::HTMLElementAttributes( $db );
    $self->{html_element_attribute_values} = new WebStatistics::SQL::HTMLElementAttributeValues( $db );

    # JavaScript
    $self->{javascript_elements} = new WebStatistics::SQL::JavaScriptElements( $db );

    # Validator errors
    $self->{html_errors} = new WebStatistics::SQL::HTMLErrors( $db );
    $self->{css_errors} = new WebStatistics::SQL::CSSErrors( $db );

    return $self;
}




1;


