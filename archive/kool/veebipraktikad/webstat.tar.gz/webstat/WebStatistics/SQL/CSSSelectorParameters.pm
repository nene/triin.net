package WebStatistics::SQL::CSSSelectorParameters;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

$SQL_SELECT_ALL = "
    SELECT
        css_selector_parameter_id AS id, 
        css_selector_parameter_name AS name
    FROM
        css_selector_parameters
";

$SQL_SELECT_ID = "
    SELECT
        css_selector_parameter_id
    FROM
        css_selector_parameters
    WHERE
        css_selector_parameter_name = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO css_selector_parameters (
        css_selector_parameter_id,
        css_selector_parameter_name
    )
    VALUES (
        '',
        ?
    )
";

$SQL_INSERT_WEBPAGE_ELEMENT = "
    INSERT INTO webpage_css_selector_parameters (
        webpage_id,
        css_selector_parameter_id,
        webpage_css_selector_parameter_count
    )
    VALUES (
        ?,
        ?,
        ?
    )
";



# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

