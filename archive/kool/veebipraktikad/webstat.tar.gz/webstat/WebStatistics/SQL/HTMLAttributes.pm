package WebStatistics::SQL::HTMLAttributes;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
);

# SQL for handling HTML Attributes

$SQL_SELECT_ALL = "
    SELECT
        html_attribute_id,
        html_attribute_name
    FROM
        html_attributes
";

$SQL_SELECT_ID = "
    SELECT
        html_attribute_id
    FROM
        html_attributes
    WHERE
        html_attribute_name = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO html_attributes (
        html_attribute_id,
        html_attribute_name
    )
    VALUES (
        '',
        ?
    )
";




# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );

    return $self;
}

