package WebStatistics::SQL::XMLPrologs;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_SELECT_ID_WITH_NULL
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

# SQL for handling XML prologs

$SQL_SELECT_ALL = "
    SELECT
        xml_prolog_id,
        xml_version,
        encoding_id
    FROM
        xml_prologs
";

$SQL_SELECT_ID = "
    SELECT
        xml_prolog_id
    FROM
        xml_prologs
    WHERE
        xml_version = ? AND
        encoding_id = ?
";

$SQL_SELECT_ID_WITH_NULL = "
    SELECT
        xml_prolog_id
    FROM
        xml_prologs
    WHERE
        xml_version = ? AND
        encoding_id is NULL
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO xml_prologs (
        xml_prolog_id,
        xml_version,
        encoding_id
    )
    VALUES (
        '',
        ?,
        ?
    )
";

# although it's actually an UNPDATE statement, we call it INSERT for consistency
$SQL_INSERT_WEBPAGE_ELEMENT = "
    UPDATE webpages
    SET
        xml_prolog_id = ?
    WHERE
        webpage_id = ?
";





# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{select_id_with_null}    = $db->prepare( $SQL_SELECT_ID_WITH_NULL );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

