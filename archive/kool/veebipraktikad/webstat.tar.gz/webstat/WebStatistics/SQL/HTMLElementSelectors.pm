package WebStatistics::SQL::HTMLElementSelectors;

# This package is kind if duplicate of HTMLElements,
# bute meant to be used with element selectors found from CSS.
# Hopefully, it won't be too bad...

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

$SQL_SELECT_ALL = "
    SELECT
        html_element_id AS id,
        html_element_name AS name
    FROM
        html_elements
";

$SQL_SELECT_ID = "
    SELECT
        html_element_id
    FROM
        html_elements
    WHERE
        html_element_name = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO html_elements (
        html_element_id,
        html_element_name
    )
    VALUES (
        '',
        ?
    )
";

# This SQL query is the only different one from SQL::HTMLElements
# Maybe we should remove all the other statemants from this package,
# but at the moment I leave them alone...
$SQL_INSERT_WEBPAGE_ELEMENT = "
    INSERT INTO webpage_html_element_selectors (
        webpage_id,
        html_element_id,
        webpage_html_element_selector_count
    )
    VALUES (
        ?,
        ?,
        ?
    )
";




# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

