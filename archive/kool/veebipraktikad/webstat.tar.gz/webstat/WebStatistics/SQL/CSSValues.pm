package WebStatistics::SQL::CSSValues;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
);

$SQL_SELECT_ALL = "
    SELECT
        css_value_id AS id,
        css_value_value AS name
    FROM
        css_values
";

$SQL_SELECT_ID = "
    SELECT
        css_value_id
    FROM
        css_values
    WHERE
        css_value_value = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO css_values (
        css_value_id,
        css_value_value
    )
    VALUES (
        '',
        ?
    )
";

# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );

    return $self;
}

