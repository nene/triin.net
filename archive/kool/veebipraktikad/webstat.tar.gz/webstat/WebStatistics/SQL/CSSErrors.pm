package WebStatistics::SQL::CSSErrors;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

$SQL_SELECT_ALL = "
    SELECT
        css_error_id,
        css_error_name
    FROM
        css_errors
";

$SQL_SELECT_ID = "
    SELECT
        css_error_id
    FROM
        css_errors
    WHERE
        css_error_name = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO css_errors (
        css_error_id,
        css_error_name
    )
    VALUES (
        '',
        ?
    )
";

$SQL_INSERT_WEBPAGE_ELEMENT = "
    INSERT INTO webpage_css_errors (
        webpage_id,
        css_error_id,
        webpage_css_error_count
    )
    VALUES (
        ?,
        ?,
        ?
    )
";




# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

