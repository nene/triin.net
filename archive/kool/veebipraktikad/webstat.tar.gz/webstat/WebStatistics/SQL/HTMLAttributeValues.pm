package WebStatistics::SQL::HTMLAttributeValues;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
);

# SQL for handling HTML Attribute Values

$SQL_SELECT_ALL = "
    SELECT
        html_attribute_value_id,
        html_attribute_value_value
    FROM
        html_attribute_values
";

$SQL_SELECT_ID = "
    SELECT
        html_attribute_value_id
    FROM
        html_attribute_values
    WHERE
        html_attribute_value_value = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO html_attribute_values (
        html_attribute_value_id,
        html_attribute_value_value
    )
    VALUES (
        '',
        ?
    )
";




# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );

    return $self;
}

