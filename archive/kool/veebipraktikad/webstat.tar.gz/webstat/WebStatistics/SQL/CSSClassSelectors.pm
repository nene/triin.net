package WebStatistics::SQL::CSSClassSelectors;

use warnings;
use strict;
use Data::Dumper;

use vars qw(
    $SQL_SELECT_ALL
    $SQL_SELECT_ID
    $SQL_INSERT_ELEMENT
    $SQL_INSERT_WEBPAGE_ELEMENT
);

$SQL_SELECT_ALL = "
    SELECT
        1 AS id,
        css_class_selector_name AS name
    FROM
        css_class_selectors
";

$SQL_SELECT_ID = "
    SELECT
        1 AS id
    FROM
        css_class_selectors
    WHERE
        css_class_selector_name = ?
";

$SQL_INSERT_ELEMENT = "
    INSERT INTO css_class_selectors (
        css_class_selector_name,
        css_class_selector_pagecount
    )
    VALUES (
        ?,
        '0'
    )
";

# defenetly not an insert statement,
# but we call it so for consistency
$SQL_INSERT_WEBPAGE_ELEMENT = "
    UPDATE css_class_selectors
    SET
        css_class_selector_pagecount = css_class_selector_pagecount + 1
    WHERE
        css_class_selector_name = ?
";



# constructor
sub new {
    my $type = shift;
    my $db = shift;

    my $self = bless {}, $type;

    # generate SQL statements
    $self->{select_all}             = $db->prepare( $SQL_SELECT_ALL );
    $self->{select_id}              = $db->prepare( $SQL_SELECT_ID );
    $self->{insert_element}         = $db->prepare( $SQL_INSERT_ELEMENT );
    $self->{insert_webpage_element} = $db->prepare( $SQL_INSERT_WEBPAGE_ELEMENT );

    return $self;
}

