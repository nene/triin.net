package WebStatistics::SACErrorHandler;

use warnings;
use strict;

# constructor
sub new {
    my $type = shift;
    return bless {}, $type;
}


sub warning {
    # disabled for production
    # warn "\033[33m[warning] $_[1] (line " . (caller)[2] . ")\033[0m";
}


sub error {
    # disabled for production
    # warn "\033[33m[error] $_[1] (line " . (caller)[2] . ")\033[0m";
}

sub fatal_error {
    die "\033[31m[fatal error] $_[1]\033[0m";
}

1;
