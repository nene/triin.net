package WebStatistics::Cache::General;

use warnings;
use strict;
use WebStatistics::Cache::ElementIdAndCountCache;
use WebStatistics::Cache::ValueIdAndCountCache;

use WebStatistics::Cache::HTTPHeaders;
use WebStatistics::Cache::Encodings;
use WebStatistics::Cache::Doctypes;
use WebStatistics::Cache::XMLPrologs;
use WebStatistics::Cache::HTMLElements;
use WebStatistics::Cache::HTMLAttributes;
use WebStatistics::Cache::HTMLAttributeValues;
use Data::Dumper;


sub new {
    my $type = shift;

    my $self = bless {}, $type;

    # Caches for CSS properties and values
    my $css_property_values_cache = {};
    $self->{css_properties} =
        new WebStatistics::Cache::ElementIdAndCountCache( $css_property_values_cache );
    $self->{css_property_values} =
        new WebStatistics::Cache::ValueIdAndCountCache( $css_property_values_cache );

    $self->{css_values} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    # Caches for CSS selectors
    $self->{css_selector_types} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    $self->{css_selector_parameters} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    $self->{html_element_selectors} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    $self->{css_class_selectors} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );
    $self->{css_id_selectors} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    # cache for @rules
    $self->{css_at_rules} =
        new WebStatistics::Cache::ValueIdAndCountCache( {} );


    $self->{doctypes}              = new WebStatistics::Cache::Doctypes;
    $self->{encodings}             = new WebStatistics::Cache::Encodings;
    $self->{html_attributes}       = new WebStatistics::Cache::HTMLAttributes;
    $self->{html_attribute_values} = new WebStatistics::Cache::HTMLAttributeValues;
    $self->{html_elements}         = new WebStatistics::Cache::HTMLElements;
    $self->{http_headers}          = new WebStatistics::Cache::HTTPHeaders;
    $self->{xml_prologs}           = new WebStatistics::Cache::XMLPrologs;


    $self->{html_errors} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    $self->{css_errors} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    $self->{javascript_elements} =
        new WebStatistics::Cache::ElementIdAndCountCache( {} );

    return $self;
}




1;


