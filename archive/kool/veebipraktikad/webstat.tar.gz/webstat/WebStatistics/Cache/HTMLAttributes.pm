package WebStatistics::Cache::HTMLAttributes;

use warnings;
use strict;
use Data::Dumper;


sub new {
    my $type = shift;
    my $self = bless {}, $type;
    return $self;
}


=head2 HTML Attributes cache structure

    $html_attributes =>
    {
        <attribute_name_1> => <attribute_id_1>,
        <attribute_name_2> => <attribute_id_2>,
        <attribute_name_3> => <attribute_id_3>,
        ...
    }

=cut

=head3 add( $attribute, $id )

Add new attribute into cache, with the following data:

=over 4

=item * $attribute - attribute name

=item * $id - attribute ID

=back

=cut
sub add {
    my $self = shift;
    my $attribute = shift;
    my $id = shift;

    $self->{html_attributes}->{$attribute} = $id;
}




=head2 get_id( $attribute )

Get the attribute_id value from cache,
corresponding to attribute name.

=cut
sub get_id {
    my $self = shift;
    my $attribute = shift;

    if ( exists( $self->{html_attributes} ) &&
         exists( $self->{html_attributes}->{$attribute} )
    ) {
        return $self->{html_attributes}->{$attribute};
    }
    else {
        return; #false
    }
}
















1;

