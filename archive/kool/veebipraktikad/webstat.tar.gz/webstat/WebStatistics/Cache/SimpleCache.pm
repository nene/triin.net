package WebStatistics::Cache::SimpleCache;

use warnings;
use strict;
use Data::Dumper;


=head1 NAME

WebStatistics::Cache::SimpleCache - a base class for all caches.



=head1 SYNOPSIS

    use WebStatistics::Cache::SimpleCache;

    # create our storage space
    my $storage = {};

    # create two SimpleCache objects, which use the same storagespace
    my $cache_1 = new WebStatistics::Cache::SimpleCache( $storage );
    my $cache_2 = new WebStatistics::Cache::SimpleCache( $storage );



=head1 METHODS

=head2 new( $cache )

Constructs new instance of SimpleCache.
Takes one parameter $cache, which should contain an hash-reference.

=cut
sub new {
    my $type = shift;
    my $cache = shift;

    # bless with type
    my $self = bless {}, $type;

    # set the cache
    $self->{cache} = $cache;

    return $self;
}




=head2 set_cache( $cache )

Set the cache to be stored in supplied hashreference $cache.

=cut
sub set_cache {
    my $self = shift;
    my $cache = shift;

    $self->{cache} = $cache;
}




=head1 AUTHOR

Rene Saarsoo <nene@triin.net>

This module is licensed under the same terms as Perl itself.

=cut

1;

