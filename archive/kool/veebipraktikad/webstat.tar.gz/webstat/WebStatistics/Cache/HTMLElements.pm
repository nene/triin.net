package WebStatistics::Cache::HTMLElements;
use base qw( WebStatistics::Cache::ElementIdAndCountCache );


use warnings;
use strict;
use Data::Dumper;



=head2 HTML Elements cache structure

    $html_elements =>
    {
        <element_name_1> =>
        {
            id => <element_id>,
            count => <nr_of_elements>,

            attributes =>
            {
                <attribute_name_1> =>
                {
                    id => <attribute_id>,
                    count => <nr_of_attributes>,

                    values =>
                    {
                        <value_1> =>
                        {
                            id => <value_id>,
                            count => <nr_of_values>
                        }
                        <value_2> =>,
                        ...
                    }
                }
                <attribute_name_2> =>
                <attribute_name_3> =>
                ...
            }
        }
    }

=cut






=head2 add_element_attribute( $element, $attribute, $id )

Add new HTML element attribute into cache, with the following data:

=over 4

=item * $element - HTML element name

=item * $attribute - HTML attribute name

=item * $id - attribute ID

=back

=cut
sub add_element_attribute {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;
    my $id = shift;

    $self->{cache}->{$element}->{attributes}->{$attribute}->{id} = $id;
}




=head2 get_element_attribute_id( $element, $attribute )

Get the html_element_attribute_id value from cache,
corresponding to element name and attribute name.

=cut
sub get_element_attribute_id {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;

    return $self->{cache}->{$element}->{attributes}->{$attribute}->{id};
}




=head2 increment_element_attribute_count( $element, $attribute )

Increment the count of $attribute in the document.

=cut
sub increment_element_attribute_count {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;

    $self->{cache}->{$element}->{attributes}->{$attribute}->{count}++;
}




=head2 add_element_attribute_value( $element, $attribute, $value, $id )

Add new HTML element attribute value into cache, with the following data:

=over 4

=item * $element - HTML element name

=item * $attribute - HTML attribute name

=item * $value - HTML attribute name

=item * $id - attribute ID

=back

=cut
sub add_element_attribute_value {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;
    my $value = shift;
    my $id = shift;

    $self->{cache}->{$element}->{attributes}->{$attribute}->{values}->{$value}->{id} = $id;
}




=head2 get_element_attribute_value_id( $element, $attribute )

Get the html_element_attribute_value_id value from cache,
corresponding to element name, attribute name and value.

=cut
sub get_element_attribute_value_id {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;
    my $value = shift;

    return $self->{cache}->{$element}->{attributes}->{$attribute}->{values}->{$value}->{id};
}




=head2 increment_element_attribute_value_count( $element, $attribute, $value )

Increment the count of $value in the document.

=cut
sub increment_element_attribute_value_count {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;
    my $value = shift;

    $self->{cache}->{$element}->{attributes}->{$attribute}->{values}->{$value}->{count}++;
}








1;

