package WebStatistics::Cache::ElementIdAndCountCache;
use base qw( WebStatistics::Cache::SimpleCache );

use warnings;
use strict;
use Data::Dumper;


=head1 NAME

WebStatistics::Cache::ElementIdAndCountCache - general cache for storing ID-s and counts

=head1 SYNOPSIS

    use Data::Dumper;
    use WebStatistics::Cache::IDAndCountCache;

    my $cache = new WebStatistics::Cache::IDAndCountCache( {} );

    # add elements into cache
    $cache->add( "foo", 1 );
    $cache->add( "bar", 8 );
    $cache->add( "baz", 3 );

    # increment element counts
    $cache->increment_count( "foo" );
    $cache->increment_count( "bar" );
    $cache->increment_count( "bar" );

    # print out the cached ID-s
    print Dumper $cache->get_id( "foo" ); # outputs: 1
    print Dumper $cache->get_id( "bar" ); # outputs: 8
    print Dumper $cache->get_id( "hop" ); # outputs: undef

    # print out the cached elementcounts
    print Dumper $cache->get_count( "foo" ); # outputs: 1
    print Dumper $cache->get_count( "bar" ); # outputs: 2
    print Dumper $cache->get_count( "baz" ); # outputs: undef

=head1 DESCRIPTION

This cache lets you store element name and it's corresponding ID and count.

=head2 Internal structure of the cache

    $cache =>
    {
        <element_1> =>
        {
            id => <element_id_1>,
            count => <nr_of_elements>,
        }
        <element_2> => {},
        <element_3> => {},
        ...
    }

=cut





=head1 METHODS

=head2 add( $element_name, $id )

Add new element into cache, with the following data:

=over 4

=item * $element_name - name of the element

=item * $id - associated ID

=back

=cut
sub add {
    my $self = shift;
    my $element_name = shift;
    my $id = shift;

    $self->{cache}->{$element_name}->{id} = $id;
}




=head2 get_id( $element_name )

Get the ID value from cache, corresponding to element name.

=cut
sub get_id {
    my $self = shift;
    my $element_name = shift;

    return $self->{cache}->{$element_name}->{id};
}




=head2 increment_count( $element_name )

Increment the count of $element_name.

=cut
sub increment_count {
    my $self = shift;
    my $element_name = shift;

    $self->{cache}->{$element_name}->{count}++;
}




=head2 get_count( $element_name )

Get the count of $element_name.

=cut
sub get_count {
    my $self = shift;
    my $element_name = shift;

    return $self->{cache}->{$element_name}->{count};
}




=head2 commit ( $page_id, $insert_statement )

Add cached element counts to database.
Records are added using $insert_statement and associated
with webpage through provided $page_id.

NB! This method also resets the counts.

=cut
sub commit {
    my $self = shift;
    my $page_id = shift;
    my $insert_statement = shift;

    # vars used in loop
    my $element_id;
    my $element_count;

    # loop through elements
    while ( my ( $element_name, $attributes ) = each( %{$self->{cache}} ) ) {

        $element_id = $attributes->{id};
        $element_count = $attributes->{count} || 0;

        # if at least one element exists, add record to database
        if ( $element_count > 0 ) {
            $insert_statement->execute(
                $page_id,
                $element_id,
                $element_count
            );
        }

        # reset element count
        $attributes->{count} = 0;
    }
}




=head2 commit_pagecounts ( $insert_statement )

Increment the number of pages having this element.

NB! This method also resets the entire cache

=cut
sub commit_pagecounts {
    my $self = shift;
    my $icrement_statement = shift;

    # vars used in loop
    my $element_id;
    my $element_count;

    # loop through elements
    while ( my ( $element_name, $attributes ) = each( %{$self->{cache}} ) ) {
        # increment pagecount
        $icrement_statement->execute( $element_name );
    }

    # reset entire cache
    $self->{cache} = {};
}




=head1 AUTHOR

Rene Saarsoo <nene@triin.net>

This module is licensed under the same terms as Perl itself.

=cut




1;

