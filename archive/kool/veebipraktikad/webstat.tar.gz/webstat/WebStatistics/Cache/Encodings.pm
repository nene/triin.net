package WebStatistics::Cache::Encodings;

use warnings;
use strict;
use Data::Dumper;


sub new {
    my $type = shift;
    my $self = bless {}, $type;
    return $self;
}


=head2 Encodings cache structure

    $encodings =>
    {
        <encoding_name_1> => <encoding_id_1>,
        <encoding_name_2> => <encoding_id_2>,
        <encoding_name_3> => <encoding_id_3>,
        ...
    }

=cut

=head2 add( $encoding, $id )

Add new Encoding into cache, with the following data:

=over 4

=item * $encoding - name of character encoding

=item * $id - encoding ID

=back

=cut
sub add {
    my $self = shift;
    my $encoding = shift;
    my $id = shift;

    $self->{encodings}->{$encoding} = $id;
}




=head2 get_id( $encoding )

Get the encoding_id value from cache,
corresponding to encoding name.

=cut
sub get_id {
    my $self = shift;
    my $encoding = shift;

    if ( exists( $self->{encodings} ) &&
         exists( $self->{encodings}->{$encoding} )
    ) {
        return $self->{encodings}->{$encoding};
    }
    else {
        return; #false
    }
}
















1;

