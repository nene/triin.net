package WebStatistics::Cache::HTMLAttributeValues;

use warnings;
use strict;
use Data::Dumper;


sub new {
    my $type = shift;
    my $self = bless {}, $type;
    return $self;
}


=head2 HTML Attribute values cache structure

    $html_attribute_values =>
    {
        <attribute_value_1> => <attribute_id_1>,
        <attribute_value_2> => <attribute_id_2>,
        <attribute_value_3> => <attribute_id_3>,
        ...
    }

=cut

=head3 add( $value, $id )

Add new attribute into cache, with the following data:

=over 4

=item * $value - attribute value

=item * $id - attribute value ID

=back

=cut
sub add {
    my $self = shift;
    my $value = shift;
    my $id = shift;

    $self->{html_attribute_values}->{$value} = $id;
}




=head2 get_id( $value )

Get the attribute_value_id value from cache,
corresponding to attribute value.

=cut
sub get_id {
    my $self = shift;
    my $value = shift;

    if ( exists( $self->{html_attribute_values} ) &&
         exists( $self->{html_attribute_values}->{$value} )
    ) {
        return $self->{html_attribute_values}->{$value};
    }
    else {
        return; #false
    }
}
















1;

