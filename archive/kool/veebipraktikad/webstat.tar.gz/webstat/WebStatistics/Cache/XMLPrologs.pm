package WebStatistics::Cache::XMLPrologs;

use warnings;
use strict;
use Data::Dumper;


sub new {
    my $type = shift;
    my $self = bless {}, $type;
    return $self;
}


=head2 XML Prologs cache structure

    $xml_prologs =>
    {
        <version_1> =>
        {
            <encoding_1> => <xml_prolog_id_1>,
            <encoding_2> => <xml_prolog_id_2>,
            ...
        }
        <version_2> =>
        <version_3> =>
        ...
    }

If encoding is not defined, then string "NULL" is used to store
it into the cache.

=cut


=head2 add( $version, $encoding, $id )

Add new XML prolog into cache, with the following data:

=over 4

=item * $version - value of version parameter

=item * $encoding - value of encoding parameter

=item * $id - XML Prolog ID

=back

=cut
sub add {
    my $self = shift;
    my $version = shift;
    my $encoding = shift || "NULL";
    my $id = shift;

    $self->{xml_prologs}->{$version}->{$encoding} = $id;
}




=head2 get_id( $root, $fpi, $si )

Get the xml_prolog_id value from cache,
corresponding to XML version and encoding.

=cut
sub get_id {
    my $self = shift;
    my $version = shift;
    my $encoding = shift || "NULL";

    if ( exists( $self->{xml_prologs} ) &&
         exists( $self->{xml_prologs}->{$version} ) &&
         exists( $self->{xml_prologs}->{$version}->{$encoding} )
    ) {
        return $self->{xml_prologs}->{$version}->{$encoding};
    }
    else {
        return; #false
    }
}
















1;

