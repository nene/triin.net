package WebStatistics::Cache::ValueIdAndCountCache;
use base qw( WebStatistics::Cache::SimpleCache );

use warnings;
use strict;
use Data::Dumper;


=head2 Cache structure

    $cache =>
    {
        <element_name_1> =>
        {
            id => <property_id_1>,
            count => <nr_of_properties>,
            values =>
            {
                <value_1> =>
                {
                    id => <value_id_1>,
                    count => <nr_of_properties>
                }
                <value_2> => {}
                <value_3> => {}
                ...
            }
        }
        <element_name_2> => {},
        <element_name_3> => {},
        ...
    }

=cut


=head2 add( $element_name, $value, $id )

Add new value into cache, with the following data:

=over 4

=item * $element_name - name of element

=item * $value - property value

=item * $id - property value ID

=back

=cut
sub add {
    my $self = shift;
    my $element_name = shift;
    my $value = shift;
    my $id = shift;

    $self->{cache}->{$element_name}->{values}->{$value}->{id} = $id;
}




=head2 get_id( $element_name, $value )

Get the element_value_id value from cache,
corresponding to property name and value.

=cut
sub get_id {
    my $self = shift;
    my $element_name = shift;
    my $value = shift;

    return $self->{cache}->{$element_name}->{values}->{$value}->{id};
}




=head2 increment_count( $element_name, $value )

Increment the count of element value in the document.

=cut
sub increment_count {
    my $self = shift;
    my $element_name = shift;
    my $value = shift;

    $self->{cache}->{$element_name}->{values}->{$value}->{count}++;
}




=head2 get_count( $element_name, $value )

Get the count of element value in the document.

=cut
sub get_count {
    my $self = shift;
    my $element_name = shift;
    my $value = shift;

    return $self->{cache}->{$element_name}->{values}->{$value}->{count};
}




=head2 commit ( $page_id, $insert_statement )

Add cached value counts to database.
Records are added using $insert_statement and associated
with webpage through provided $page_id.

NB! This method also resets the counts.

=cut
sub commit {
    my $self = shift;
    my $page_id = shift;
    my $insert_statement = shift;

    # vars used in loop
    my $value_id;
    my $value_count;

    # loop through elements
    while ( my ( $element_name, $attributes ) = each( %{$self->{cache}} ) ) {

        # loop through values
        while ( my ( $value_name, $value_attributes ) = each( %{$attributes->{values}} ) ) {

            $value_id = $value_attributes->{id};
            $value_count = $value_attributes->{count} || 0;

            # if at least one value exists, add record to database
            if ( $value_count > 0 ) {
                $insert_statement->execute(
                    $page_id,
                    $value_id,
                    $value_count
                );
            }

            # reset value count
            $value_attributes->{count} = 0;
        }
    }
}







1;

