package WebStatistics::Cache::HTTPHeaders;

use warnings;
use strict;
use Data::Dumper;


sub new {
    my $type = shift;
    my $self = bless {}, $type;
    return $self;
}


=head2 HTTP Headers cache structure

    $http_headers =>
    {
        <header_name_1> =>
        {
            header_id => <header_id_1>,

            header_values =>
            {
                <header_value_1> => <header_content_id_1>,
                <header_value_2> => <header_content_id_2>,
                ...
            },
        },

        <header_name_2> =>

        <header_name_3> =>
        ...
    }
    
    http_status_codes =>
    {
        <status_code_1> = 1,
        <status_code_2> = 1,
        <status_code_3> = 1,
        ...
    }

=cut




=head2 get_header_id( $header_name )

If $header_name exists in cache, then returns the corresponding ID.
Otherwise returns false.

=cut
sub get_header_id {
    my $self = shift;
    my $header_name = shift;

    if ( exists($self->{http_headers}->{$header_name}) )
    {
        return $self->{http_headers}->{$header_name}->{header_id};
    }
    else
    {
        return; # false
    }
}




=head2 add_header( $header_name, $header_id )

Adds new $header_name <-> $header_id pair to cache.

=cut
sub add_header {
    my $self = shift;
    my $header_name = shift;
    my $header_id = shift;

    return $self->{http_headers}->{$header_name}->{header_id} = $header_id;
}




=head2 get_header_content_id( $header_name, $header_content )

If $header_name and $header_content exist in cache, then returns the corresponding ID.
Otherwise returns false.

=cut
sub get_header_content_id {
    my $self = shift;
    my $header_name = shift;
    my $header_content = shift;

    if ( exists($self->{http_headers}->{$header_name}->{header_contents}->{$header_content}) )
    {
        return $self->{http_headers}->{$header_name}->{header_contents}->{$header_content};
    }
    else
    {
        return; # false
    }
}




=head2 add_header_content( $header_name, $header_content, $header_content_id )

Adds new $header_content <-> $header_content_id pair to cache
and associates with $header_name.

=cut
sub add_header_content {
    my $self = shift;
    my $header_name = shift;
    my $header_content = shift;
    my $header_content_id = shift;

    $self->{http_headers}->{$header_name}->{header_contents}->{$header_content} = $header_content_id;
}




=head2 http_status_code_exists( $http_status_code )

Checks if $http_status_code is stored in the cache.

=cut
sub http_status_code_exists {
    my $self = shift;
    my $http_status_code = shift;

    return exists( $self->{http_status_codes}->{$http_status_code} );
}




=head2 add_http_status_code( $http_status_code )

Adds $http_status_code to cache.

=cut
sub add_http_status_code {
    my $self = shift;
    my $http_status_code = shift;

    $self->{http_status_codes}->{$http_status_code} = 1;
}
















1;

