package WebStatistics::Cache::Doctypes;

use warnings;
use strict;
use Data::Dumper;


sub new {
    my $type = shift;
    my $self = bless {}, $type;
    return $self;
}


=head2 DOCTYPEs cache structure

    $doctypes =>
    {
        <root_element_name_1> =>
        {
            <FPI_1> =>
            {
                <SI_1> => <doctype_id_1>,
                <SI_2> => <doctype_id_2>,
                ...
            }
            <FPI_2> =>
            <FPI_3> =>
            ...
        }
        <root_element_name_2> =>
        <root_element_name_3> =>
        ...
    }

=cut

=head3 add( $root, $fpi, $si, $id )

Add new doctype into cache, with the following data:

=over 4

=item * $root - Root element name

=item * $fpi - Formal Public Identifier

=item * $si - System identifier

=item * $id - Doctype ID

=back

=cut
sub add {
    my $self = shift;
    my $root = shift;
    my $fpi = shift;
    my $si = shift;
    my $id = shift;

    $self->{doctypes}->{$root}->{$fpi}->{$si} = $id;
}




=head2 get_id( $root, $fpi, $si )

Get the doctype_id value from cache,
corresponding to root element name, FPI and SI.

=cut
sub get_id {
    my $self = shift;
    my $root = shift;
    my $fpi = shift;
    my $si = shift;

    if ( exists( $self->{doctypes} ) &&
         exists( $self->{doctypes}->{$root} ) &&
         exists( $self->{doctypes}->{$root}->{$fpi} ) &&
         exists( $self->{doctypes}->{$root}->{$fpi}->{$si} )
    ) {
        return $self->{doctypes}->{$root}->{$fpi}->{$si};
    }
    else {
        return; #false
    }
}
















1;

