package WebStatistics::HTTPHeaders;

use warnings;
use strict;
use Data::Dumper;
use WebStatistics::DBGeneral;
use DBI;

use vars qw(
    $SQL_SELECT_HEADER_ID
    $SQL_SELECT_HEADER_NAMES
    $SQL_SELECT_STATUS_CODES
    $SQL_SELECT_HEADER_NAMES_AND_VALUES
    $SQL_SELECT_HEADER_CONTENT_ID

    $SQL_INSERT_HEADER_NAME
    $SQL_INSERT_HEADER_VALUE
    $SQL_INSERT_WEBPAGE_HEADER_CONTENT
    $SQL_INSERT_WEBPAGE_HTTP_EQUIV

    $SQL_UPDATE_VERSION_AND_STATUS_CODE

    $STORABLE_HEADER_NAMES
);


$SQL_SELECT_HEADER_ID = "
    SELECT
        header_id
    FROM
        headers
    WHERE
        header_name = ?
    ";

$SQL_SELECT_HEADER_NAMES = "
    SELECT
        header_id,
        header_name
    FROM
        headers
    ";

$SQL_SELECT_HEADER_NAMES_AND_VALUES = "
    SELECT
        headers.header_id AS header_id,
        header_name,
        header_content_id,
        header_content_value
    FROM
        header_contents NATURAL JOIN headers
    ";

$SQL_SELECT_HEADER_CONTENT_ID = "
    SELECT
        header_content_id
    FROM
        header_contents
    WHERE
        header_id = ?
        AND
        header_content_value = ?
    ";


$SQL_SELECT_STATUS_CODES = "
    SELECT
        http_status_code,
        http_status_phrase
    FROM
        http_statuses
    ";

$SQL_INSERT_HEADER_NAME = "
    INSERT INTO headers
        (header_id, header_name)
    VALUES
        ('', ?)
    ";

$SQL_INSERT_HEADER_VALUE = "
    INSERT INTO header_contents
        (header_content_id, header_id, header_content_value)
    VALUES
        ('', ?, ?)
    ";

$SQL_INSERT_WEBPAGE_HEADER_CONTENT = "
    INSERT INTO webpage_header_contents
        (webpage_id, header_content_id)
    VALUES
        (?, ?)
    ";

$SQL_INSERT_WEBPAGE_HTTP_EQUIV = "
    INSERT INTO webpage_http_equivs
        (webpage_id, header_content_id)
    VALUES
        (?, ?)
    ";

$SQL_UPDATE_VERSION_AND_STATUS_CODE = "
    UPDATE webpages
    SET
        http_version = ?,
        http_status_code = ?
    WHERE
        webpage_id = ?
    ";


$STORABLE_HEADER_NAMES = {
    "accept-ranges" => 1,
    "cache-control" => 1,
    "connection" => 1,
    "content-language" => 1,
    "content-type" => 1,
    "keep-alive" => 1,
    "pragma" => 1,
    "server" => 1,
    "vary" => 1,
    "x-powered-by" => 1,
    };



# Constructs new instance of HeadersStatisticsDB
#
# Takes one parameter (required!) which contains the
# reference to hash of options. The options are:
# 
# * DatabaseHandler
#
#   Database handler is expected to be already connected to the database.
#
# * CurrentPageId
#
#   The database ID of the current page.
#
# * IsHTTPEquiv
#
#   0 - store as ordinary HTTP headers (default).
#   1 - store as http-equivalents from HTML.
#
sub new {
    my $type = shift;
    my $options = shift;

    my $self = bless {}, $type;

    # manage options
    $self->{sql} = $options->{SQLStatements} || die("No SQL statements specified");
    $self->{db} = $self->{sql}->{db};
    $self->{cache} = $options->{DatabaseCache} || die("No database cache specified");
    $self->{current_page_id} = $options->{CurrentPageId} || 0;
    $self->{is_http_equiv} = $options->{IsHTTPEquiv} || 0;

    # prepare SQL statements
    $self->{select_header_id} =
        $self->{db}->prepare($SQL_SELECT_HEADER_ID);

    $self->{select_header_names} =
        $self->{db}->prepare($SQL_SELECT_HEADER_NAMES);

    $self->{select_header_names_and_values} =
        $self->{db}->prepare($SQL_SELECT_HEADER_NAMES_AND_VALUES);

    $self->{select_header_content_id} =
        $self->{db}->prepare($SQL_SELECT_HEADER_CONTENT_ID);

    $self->{select_status_codes} =
        $self->{db}->prepare($SQL_SELECT_STATUS_CODES);


    $self->{insert_header_name} =
        $self->{db}->prepare($SQL_INSERT_HEADER_NAME);

    $self->{insert_header_value} =
        $self->{db}->prepare($SQL_INSERT_HEADER_VALUE);

    $self->{insert_webpage_header_content} =
        $self->{db}->prepare($SQL_INSERT_WEBPAGE_HEADER_CONTENT);

    $self->{insert_webpage_http_equiv} =
        $self->{db}->prepare($SQL_INSERT_WEBPAGE_HTTP_EQUIV);


    $self->{update_version_and_status_code} =
        $self->{db}->prepare($SQL_UPDATE_VERSION_AND_STATUS_CODE);


    # init cache
    #$self->load_header_names_and_values();
    $self->load_http_status_codes();


    return $self;
}


# Set the ID of current webpage in the database
sub set_current_page_id {
    my $self = shift;
    my $current_page_id = shift;

    $self->{current_page_id} = $current_page_id || die("No current page ID specified.");
}


# HTTP Equiv mode specifies whether to store headers into database
# as ordinary HTTP headers or as values extracted from HTML <meta>
# elements like:
#
#   <meta http-quiv="Content-type" content="text/html; charset=utf-8">
#
# The default (value 0) is to store them as normal headers.
# The alternate (value 1) forces storing as http-equivalents.
sub set_is_http_equiv {
    my $self = shift;
    my $http_equiv_mode = shift;

    if ( $http_equiv_mode ) {
        $self->{is_http_equiv} = 1;
    }
    else {
        $self->{is_http_equiv} = 0;
    }
}


# catch the event of regular HTTP header found
sub header_line {
    my $self = shift;
    my $header_name = shift;
    my $header_value = shift;

    # Because HTTP header names are NOT case sensitive,
    # we convert header name to lower case.
    $header_name = lc($header_name);

    # Although HTTP header values are case sensitive,
    # our research does not care about this,
    # because browsers really don't differentiate between say
    # 'text/html; ISO-8859-1' and 'text-html; iso-8859-1'.
    # So we convert the values also to lowercase.
    $header_value = lc($header_value);

    # if header defines content-type and throughout it
    # defines the encoding of the document, then save the encoding to cache
    if (
        $header_name eq 'content-type' &&
        $header_value =~ m{charset\s*=\s*([a-z0-9_-]+)}si
    ) {
        my $encoding = lc( $1 );
        my $encoding_id = $self->get_encoding_id( $encoding );
        $self->{encoding_id} = $encoding_id;
    }

    # If we meet a refresh header from http-equiv, then remember the URL
    if ( $header_name eq 'refresh' ) {
        if ( $header_value =~ m{url=(\S+)}i ) {
            $self->{refresh} = $1;
        }
    }

    # get the ID that corresponds to our header-name and -value.
    my $header_content_id = $self->get_header_content_id( $header_name, $header_value);

    # save headers into local cache
    push( @{$self->{local_cache}}, $header_content_id );
}


# Add corresponding records to the database.
# if headers come from HTML <meta http-equiv...> elements
# insert into webpage_http_equivs table.
# With ordinary HTTP headers: insert into webpage_header_contents table.
sub commit {
    my $self = shift;

    # get the ID of current page
    my $current_page_id = $self->{current_page_id} || die("No current page ID specified.");

    foreach my $header_content_id ( @{$self->{local_cache}} ) {
        if ( $self->{is_http_equiv} ) {
            $self->{insert_webpage_http_equiv}->execute(
                $current_page_id,
                $header_content_id
            );
        }
        else {
            $self->{insert_webpage_header_content}->execute(
                $current_page_id,
                $header_content_id
            );
        }
    }

    # Set the HTTP version and status code
    # but only do this, when we are dealing with true HTTP headers,
    # because Http-Equiv fields of meta element do not specify status code
    if ( !($self->{is_http_equiv}) ) {
        $self->{update_version_and_status_code}->execute(
            $self->{http_version},
            $self->{http_status_code},
            $current_page_id
        );
    }

    # Try to set encoding of the page
    if ( $self->{encoding_id} ) {
        # try setting the Encoding of current webpage
        # if this object is dealing with http-equiv headers, instead of real ones, then
        # this will fail, when encoding was specified already in HTTP header.
        $self->{sql}->{encodings}->{insert_webpage_element}->execute(
            $self->{encoding_id},
            $current_page_id
        );
    }
}


# clean the local cache
sub empty_cache {
    my $self = shift;

    $self->{local_cache} = [];
    $self->{http_status_code} = undef;
    $self->{refresh} = undef;
    $self->{encoding_id} = undef;
}


# return http status code like "200" for OK
sub get_http_status_code {
    my $self = shift;

    return $self->{http_status_code};
}


# return URI from HTTP-EQUIV refresh
sub get_refresh_url {
    my $self = shift;

    return $self->{refresh};
}



# returns ID from header_contents table,
# which corresponds to given header_name and header_value
sub get_header_content_id {
    my $self = shift;
    my $header_name = shift;
    my $header_value = shift;

    # get the ID of header_name
    my $header_id = $self->get_header_id($header_name);

    # Transform the header_value according to the rules specified for header_name
    $header_value = $self->format_header_value($header_name, $header_value);


    # if header value is in cache, return the cached value
    if ( my $content_id = $self->{cache}->{http_headers}->get_header_content_id( $header_name, $header_value ) ) {
        return $content_id;
    }
    else {
        # in case the value does not exist, we must insert it
        if ( $self->{insert_header_value}->execute($header_id, $header_value) ) {
            # on success we now have inserted a new header_value to database.
            # get header_content_id from the database last-insert-id
            my $header_content_id = $self->{db}->{mysql_insertid};

            # add header_content_id into the cache
            $self->{cache}->{http_headers}->add_header_content(
                $header_name,
                $header_value,
                $header_content_id
            );

            # and return the header_content_id
            return $header_content_id;
        }
        else {
            # when insert fails, then this means the header_value
            # already exists in the database
            # so we just query the database for this header_value
            $self->{select_header_content_id}->execute($header_id, $header_value);

            # get the only row as hashreference and finish, because no more rows are needed
            my $row = $self->{select_header_content_id}->fetchrow_hashref;
            $self->{select_header_content_id}->finish;

            # add header_content_id into the cache
            $self->{cache}->{http_headers}->add_header_content(
                $header_name,
                $header_value,
                $row->{header_content_id}
            );

            # and return the header_content_id
            return $row->{header_content_id};
        }
    }
}


# Modify the header value according to rules set on specific header_name
# e.g. some values are irrelevant and are replaced with empty string
sub format_header_value {
    my $self = shift;
    my $header_name = shift;
    my $header_value = shift;


    # if the value of this HTTP header needs to be stored
    if ( exists( $STORABLE_HEADER_NAMES->{$header_name} ) ) {
        # if the header value is application_name
        if ( $header_name eq 'server' || $header_name eq 'x-powered-by' ) {
            # the values of these headers are often in form:
            #
            #   Application-name/version-number-and-other-info
            #
            # As far as this survey is concerned, version numbers aren't relevant,
            # so, we just remove anything that follows the slash (including the slash itself).
            $header_value =~ s{^([^/]+)/.*$}{$1};
        }
    }
    else {
        # when the value is irrelevant,
        # truncate the value to NULL (in databases' sense)
        $header_value = "";
    }

    # If we meet content-type header
    if ( $header_name eq 'content-type' ) {
        # format this value so, that:

        # place one space always after semicolon and no duplicate semicolons
        $header_value =~ s{\s*;+\s*}{; }sig;

        # remove trailing semicolons
        $header_value =~ s{\s*;+\s*$}{}si;
    }

    return $header_value;
}






# returns ID from the headers table,
# corresponding to the given header_name
sub get_header_id {
    my $self = shift;
    my $header_name = shift;

    # if header name exists in the cache, return ID directly from there
    if ( my $header_id = $self->{cache}->{http_headers}->get_header_id( $header_name ) ) {
        return $header_id;
    }
    else {
        # when header name is not in the hash,
        # then try to INSERT it into the database
        if ( $self->{insert_header_name}->execute($header_name) ) {
            # on success we now have inserted a new header_name to database.
            # get header_id from the database last-insert-id
            my $header_id = $self->{db}->{mysql_insertid};

            # add header_id into the hash
            $self->{cache}->{http_headers}->add_header( $header_name, $header_id );

            # and return the header_id
            return $header_id;
        }
        else {
            # when insert fails, then this means the header_name
            # already exists in the database
            # so we just query the database for this header_name
            $self->{select_header_id}->execute($header_name);

            # get the only row as hashreference and finish, because no more rows are needed
            my $row = $self->{select_header_id}->fetchrow_hashref;
            $self->{select_header_id}->finish;

            # add header_id into the cache
            $self->{cache}->{http_headers}->add_header( $header_name, $row->{header_id} );

            # and return the header_id
            return $row->{header_id};
        }
    }
}


# Get the ID of specified encoding
sub get_encoding_id {
    my $self = shift;
    my $encoding = shift;

    return $self->generic_get_id( "encodings", [$encoding] );
}


sub generic_get_id {
    my $self = shift;
    my $item_name = shift;
    my $values = shift;

    return WebStatistics::DBGeneral::get_id( {
        values => $values,
        cache => $self->{cache}->{$item_name},
        db => $self->{sql}->{db},
        sql => $self->{sql}->{$item_name},
    } );
}



# Aquires the listing of HTTP header values from the database
sub load_header_names_and_values {
    my $self = shift;

    # query the database for names and values
    $self->{select_header_names_and_values}->execute();

    # fill the cache with header names, values and ID-s
    while ( my $row = $self->{select_header_names_and_values}->fetchrow_hashref() ) {
        $self->{cache}->{http_headers}->add_header(
            $row->{header_name},
            $row->{header_id}
        );

        $self->{cache}->{http_headers}->add_header_content(
            $row->{header_name},
            $row->{header_content_value},
            $row->{header_content_id}
        );
    }
}





# catch the event of HTTP status line found
sub status_line {
    my $self = shift;
    my $http_version = shift;
    my $http_status_code = shift;
    my $http_reason_phrase = shift; # at the moment we do nothing with this value

    # Ensure, that status line contains correct HTTP version and status code
    $self->is_correct_http_version( $http_version ) || die("Wrong HTTP version.");
    # we don't want to shut down our program, simply because
    # of an unknown http status code
    $self->{cache}->{http_headers}->http_status_code_exists( $http_status_code ) || warn("Unknown HTTP status code $http_status_code.");

    # save version and status code
    $self->{http_version} = $http_version;
    $self->{http_status_code} = $http_status_code,
}


# Returns true if HTTP version is either 1.0 or 1.1
# These are the only allowed HTTP versions today.
# HTTP/0.9 is deprecated and HTTP/1.1 is the newest.
sub is_correct_http_version {
    my $self = shift;
    my $http_version = shift;

    return ( $http_version eq '1.0' || $http_version eq '1.1' );
}




# Aquires the listing of HTTP status codes from the database,
# and stores them in the cache.
sub load_http_status_codes {
    my $self = shift;

    # SELECT status_code and status_phrase from database
    $self->{select_status_codes}->execute();

    # fill cache with values from database
    while ( my $row = $self->{select_status_codes}->fetchrow_hashref() )
    {
        $self->{cache}->{http_headers}->add_http_status_code( $row->{http_status_code} );
    }
}
















1;


