package WebStatistics::HTMLElements;
use base HTML::Parser;

use warnings;
use strict;
use Data::Dumper;
use DBI;
use WebStatistics::Util;
use WebStatistics::DBGeneral;

=head1 NAME

WebStatistics::HTMLElements - Extended HTML::Parser.

=head1 SYNOPSIS

    # Create database and cache objects
    my $db = DBI->connect( "DBI:mysql:DatabaseName", "user", "pass");
    my $sql = new WebStatistics::SQL::General( $db );
    my $cache = new WebStatistics::Cache::General();

    # Document handler
    my $parser = new WebStatistics::HTMLElements( {
        SQLStatements => $sql,
        DatabaseCache => $cache,
        CurrentPageId => 1, # or whatever it currently is
    } );

    # parse HTML file
    $parser->parse_file( "file.html" );

    # commit results to database (this is where CurrentPageId counts)
    $parser->commit_element_counts();

    # clean up
    $parser->init_statistical_attributes();

=head1 DESCRIPTION

A crucial component of WebStatistics package.

=head1 METHODS

=cut

use vars qw(
    $RE_QUOTED_STRING
    $RE_IDENT
    $RE_DOCTYPE
    $RE_XML_PARAMETER
    $RE_XML_PROCESSING_INSTRUCTION
    $RE_URL_WITH_FILE_EXTENSION

    $STORABLE_ATTRIBUTE_NAMES
);

$RE_QUOTED_STRING = qr{
    "[^"]*"         # text between double-quotes
    |               # or
    '[^']*'         # text between single-quotes
}xsi;

$RE_IDENT = qr{[A-Za-z0-9:_-]+};

$RE_DOCTYPE = qr{
    ^<!
    (DOCTYPE)                           # 1 literal "DOCTYPE"
    \s+
    ($RE_IDENT)                         # 2 root element name
    \s+
    (?:
        (PUBLIC)                        # 3 literal "PUBLIC"
        (?:\s+
            ($RE_QUOTED_STRING)         # 4 Formal Pubic Identifier (FPI)
            (?:\s+
                ($RE_QUOTED_STRING)     # 5 system identifier
            )?
        )?
    |
        (SYSTEM)                        # 3 literal "SYSTEM"
        (?:\s+
            ($RE_QUOTED_STRING)         # 4 system identifier
        )?
    )
    \s*
    >$
}xsi;


$RE_XML_PARAMETER = qr{
    \s+
    ($RE_IDENT)                         # 1 parameter
    =
    ($RE_QUOTED_STRING)                 # 2 value
}xs;

$RE_XML_PROCESSING_INSTRUCTION = qr{
    ^<\?
    xml
    (?:$RE_XML_PARAMETER)*
    \s*
    \?>$
}xs;


$RE_URL_WITH_FILE_EXTENSION = qr{
    ^(?:(?:https?|s?ftp)://[^/]+/|/)?    # domain or root dir
    (?:[^/]+/)*                          # directories "....../" "..../"
    [^/]+                                # filename    "......."
    \.(\w{3,4})$                         # extension   ".0_Az"
}xsi;







$STORABLE_ATTRIBUTE_NAMES = {
    # id and class names are taken
    # from stylesheets instead, see WebStatistics::CSSElements
    # id => 1,
    # class => 1,

    name => 1,

    # language related
    dir => 1,
    lang => 1,
    hreflang => 1,

    # events (store contents for JavaScript analysis)
    onclick => 1,
    ondblclick => 1,
    onmousedown => 1,
    onmouseup => 1,
    onmouseover => 1,
    onmousemove => 1,
    onmouseout => 1,
    onkeypress => 1,
    onkeydown => 1,
    onkeyup => 1,
    onload => 1,
    onreset => 1,
    onselect => 1,
    onsubmit => 1,
    onunload => 1,

    # parse for:
    # - file format
    # - protocol
    # - links to W3C validators etc
    # if REL="stylesheet", then save link for CSS parsing
    href => 1,

    # links related attributes
    rel => 1,
    rev => 1,
    accesskey => 1,
    target => 1, # values like _blank, _self, _parent, _top

    # type attributes
    type => 1,
    enctype => 1,
    language => 1,
    valuetype => 1,
    version => 1,

    # presentational
    style => 1, # strip contents for later CSS parsing
    media => 1,
    align => 1,
    valign => 1,
    clear => 1,
    face => 1, # Separate font names???
    frame => 1,
    frameborder => 1,
    rules => 1,
    scope => 1,
    scrolling => 1,
    shape => 1,

    # attributes with content
    # check for emptyness
    alt => 1,
    summary => 1,
    title => 1, # check, if equals ALT

    # for IMG and INPUT, extract fileformat
    # for SCRIPT, save link for later JavaScript parsing
    src => 1,

    # for FONT and BASEFONT
    size => 1,

    # for META, save header-like info
    content => 1,
};




=head2 new

Constructs new instance of HeadersStatisticsDB

Takes one parameter (required!) which contains the
reference to hash of options. The options are:

=over 4

=item * SQLStatements

SQLStatements object, containing prepared SQL statements.

=item * DatabaseCache

Cache handler, that manages the caching of often-used database records.

=item * CurrentPageId

The database ID of the current page.

=back

=cut
sub new {
    my $type = shift;
    my $options = shift;

    my $self = bless {}, $type;

    # manage options
    $self->{sql} = $options->{SQLStatements} || die("No SQL Statements handler specified");
    $self->{cache} = $options->{DatabaseCache} || die("No database cache specified");
    $self->{current_page_id} = $options->{CurrentPageId} || 0;

    # Init statistical attributes
    $self->init_statistical_attributes();


    # init parent class
    $self->SUPER::init( @_ );

    $self->SUPER::handler( start => "start", "self, tagname, attr" );
    $self->SUPER::handler( comment => "comment", "self, text" );
    $self->SUPER::handler( text => "text", "self, text" );
    $self->SUPER::handler( declaration => "declaration", "self, text" );
    $self->SUPER::handler( process => "process", "self, text" );


    # Init cache
    #$self->load_elements;
    #$self->load_element_attributes;
    #$self->load_element_attribute_values;
    #$self->load_attributes;
    #$self->load_attribute_values;

    #$self->load_doctypes;
    #$self->load_xml_prologs;
    #$self->load_encodings;


    return $self;
}




################################################################################
#
#  GET and SET methods
#
################################################################################


=head2 GET and SET methods

=head3 set_current_page_id( $id )

Set the ID of current webpage in the database.

=cut
sub set_current_page_id {
    my $self = shift;
    my $current_page_id = shift;

    $self->{current_page_id} = $current_page_id || die("No current page ID specified.");
}




=head3 get_inline_javascript

=cut
sub get_inline_javascript {
    my $self = shift;

    return $self->{inline_javascript};
}


=head3 get_embedded_javascript

=cut
sub get_embedded_javascript {
    my $self = shift;

    return $self->{embedded_javascript};
}


=head3 get_external_javascript

returns reference to list of javascript URLs.

=cut
sub get_external_javascript {
    my $self = shift;

    return $self->{external_javascript};
}


=head3 get_inline_css

=cut
sub get_inline_css {
    my $self = shift;

    return $self->{inline_css};
}


=head3 get_embedded_css

=cut
sub get_embedded_css {
    my $self = shift;

    return $self->{embedded_css};
}


=head3 get_external_css

returns reference to list of CSS URLs.

=cut
sub get_external_css {
    my $self = shift;

    return $self->{external_css};
}


=head3 get_comment_length

=cut
sub get_comment_length {
    my $self = shift;

    return $self->{comment_length};
}


=head3 get_text_length

=cut
sub get_text_length {
    my $self = shift;

    return $self->{text_length};
}




=head3 get_http_equiv

Returns a reference to array, containing name-value pairs
of HTTP headers. These headers are cached from the attributes
of meta elements like the following:

    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />

=cut
sub get_http_equiv {
    my $self = shift;

    return $self->{http_equiv};
}




################################################################################
#
#  Initialization
#
################################################################################


=head2 init_statistical_attributes

Initialize the values of statistical attributes,
like setting text-length and comment-length to zero,
and truncating the css and javascript strings.

=cut
sub init_statistical_attributes {
    my $self = shift;

    $self->{inline_javascript} = "";
    $self->{embedded_javascript} = "";
    $self->{external_javascript} = [];
    $self->{inline_css} = "";
    $self->{embedded_css} = "";
    $self->{external_css} = [];
    $self->{active_element} = "";
    $self->{comment_length} = 0;
    $self->{text_length} = 0;
    $self->{http_equiv} = [];
    $self->{doctype_id} = 0;
    $self->{xml_encoding_id} = 0;
    $self->{xml_prolog_id} = 0;
}


=head2 init_count_cache

Sets the count of every element in the cache to zero.

=cut
sub clean_count_cache {
    my $self = shift;

    # use the following cache for HTML elements
    my $elements = $self->{cache}->{html_elements}->{cache};

    # vars used in loops
    my $element_attributes;
    my $attribute_values;

    # loop through elements
    while ( my ( $element, $properties ) = each( %{$elements} ) ) {

        # reset element count
        $properties->{count} = 0;

        # loop through attributes
        $element_attributes = $properties->{attributes} || {};
        while ( my ( $attribute, $properties ) = each( %{$element_attributes} ) ) {

            # reset attribute count
            $properties->{count} = 0;

            # loop through values
            $attribute_values = $properties->{values} || {};
            while ( my ( $value, $properties ) = each( %{$attribute_values} ) ) {
                # reset value count
                $properties->{count} = 0;
            }
        }
    }
}



################################################################################
#
#  Event handlers
#
################################################################################


=head2 start

This method deals with element start tags. They come in form:

    <element-name attribute="value" ... >

We count the number of each element-, attribute- and attribute value type.
e.g. How many <P> elements, how many of those have ALIGN attribute, and
how many of the ALIGN attributes have value "LEFT".

Not all the values of attributes are counted. The values of attributes,
which specify an URI (like HREF) or human language text (like ALT) are
not counted.

=cut
sub start {
    my $self = shift;
    my $element = shift;
    my $all_attributes = shift;

    # if <script> or <style> element starts, then remember it,
    # because we want to capture the contents of those elements
    if ( $element eq "script" || $element eq "style" ) {
        $self->{active_element} = $element;
    }

    # ensure, that element is in DB
    my $element_id = $self->get_element_id( $element );

    # go through each attribute and its value
    my $attribute_id;
    my $element_attribute_id;
    my $attribute_value_id;
    while ( my ($attribute, $value) = each( %{$all_attributes} ) ) {

        #-----------------------------------------------------------------------
        # Attribute names
        #-----------------------------------------------------------------------

        # if attribute name contains strange characters (like quotes),
        # then we replace the attribute name with "~ERROR~"
        # This is done to prevent databes from overcrowding from
        # attribute names like:
        #   href"http://example.com/foo/bar"
        #   "); return false;"
        #   ...
        if ( !( $attribute =~ m{^$RE_IDENT$} ) ) {
            $attribute = "~ERROR~";
        }

        # ensure, that attribute is in DB
        $attribute_id = $self->get_attribute_id( $attribute );

        # ensure, that element attribute is in DB
        $element_attribute_id = $self->get_element_attribute_id(
            $element,
            $attribute,
            $element_id,
            $attribute_id
        );

        # increment element attribute count
        $self->{cache}->{html_elements}->increment_element_attribute_count(
            $element,
            $attribute
        );


        #-----------------------------------------------------------------------
        # Attribute Values
        #-----------------------------------------------------------------------

        # format the value according to specific rules,
        # considering also the context of element and other attributes.
        $value = $self->format_attribute_value(
            $value,
            $attribute,
            $element,
            $all_attributes
        );

        # if attribute value should be stored
        if ( $value ) {

            # ensure, that attribute value is in DB
            $attribute_value_id = $self->get_attribute_value_id( $value );

            # ensure, that element attribute is in DB
            $element_attribute_id = $self->get_element_attribute_value_id(
                $element,
                $attribute,
                $value,
                $element_attribute_id,
                $attribute_value_id
            );

            # increment element attribute value count
            $self->{cache}->{html_elements}->increment_element_attribute_value_count(
                $element,
                $attribute,
                $value
            );
        }
    }

    # increment element count
    $self->{cache}->{html_elements}->increment_count( $element );
}




=head2 end

This method deals with element start tags.

It automatically sets the current active_element
to undefined no matter which element ends.
This is because we need to know when <script> or
<style> element ends, to stop capturing of those
contents.

=cut
sub end {
    my $self = shift;
    my $element = shift;

    $self->{active_element} = "";
}




=head2 comment

This method deals with comment nodes. They come in form:

    <!-- ... -->

We sum the length of all comments.

=cut
sub comment {
    my $self = shift;
    my $text = shift;

    $self->{comment_length} += length($text);
}





=head2 text

This method deals with text nodes.

If the text is inside <script> or <style> element,
we store it for later parsing.

When dealing with normal text,
we just sum the length of all text nodes.

=cut
sub text {
    my $self = shift;
    my $text = shift;

    if ( $self->{active_element} eq "script" ) {
        # remove <!-- and //--> from embedded JavaScript
        $text =~ s{^\s*<!--}{}s;
        $text =~ s{//\s*-->\s*$}{}s;
        $text =~ s{-->\s*$}{}s;

        $self->{embedded_javascript} .= $text;
    }
    elsif ( $self->{active_element} eq "style" ) {
        # remove <!-- and --> from embedded CSS
        $text =~ s{^\s*<!--}{}s;
        $text =~ s{-->\s*$}{}s;

        $self->{embedded_css} .= $text;
    }
    else {
        $self->{text_length} += length($text);
    }
}




=head2 declaration

This method deals with declarations.
Of all declarations we only consider
Document Type Declarations (DOCTYPEs).
They come in 4 main forms:

    <!DOCTYPE root PUBLIC "FPI" "SI">
    <!DOCTYPE root PUBLIC "FPI">
    <!DOCTYPE root SYSTEM "SI">
    <!DOCTYPE root SYSTEM>

e.g.

    <!DOCYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

From DOCTYPEs, we extract:

=over 4

=item * Root node name

=item * Formal Public Identifier (FPI)

=item * System Identifier (SI)

=back

=cut
sub declaration {
    my $self = shift;
    my $text = shift;

    # Only DOCTYPE declarations are considered.
    # All others are completely ignored.

    if ($text =~ $RE_DOCTYPE) {
        my $declaration = $1;
        my $root = $2;
        my $keyword = $3;
        my $fpi = $4 || "NULL";
        my $si = $5 || "NULL";

        # remove quotes
        $fpi = WebStatistics::Util::strip_quotes( $fpi );
        $si = WebStatistics::Util::strip_quotes( $si );

        # get doctype id
        my $doctype_id = $self->get_doctype_id($root, $fpi, $si);

        # save doctype id into cache
        $self->{doctype_id} = $doctype_id
    }
}




=head2 process

This method deals with processing instructions.
We only consider XML processing instructions.
They come in form:

    <?xml parameter="value" ... ?>

e.g.

    <?xml version="1.0" encoding="iso-8859-15"?>

From those, we extract the values of the following parameters:

=over 4

=item * version

=item * encoding

=back

=cut
sub process {
    my $self = shift;
    my $text = shift;

    # Only do something, when it is XML processing instruction.
    # All others are completely ignored

    if ($text =~ $RE_XML_PROCESSING_INSTRUCTION) {
        # capture all the parameters as key-value pairs
        # NOTE! This means that if one parameter is specified twice,
        # then only the last one will be remembered.
        # I guess this should be quite a rare case, and so we can
        # quite safely ignore it.
        my %parameters = ( $text =~ m{$RE_XML_PARAMETER}xsg );

        # quotes will remain surrounding the values, so we'll remove them
        %parameters = WebStatistics::Util::hash_strip_quotes( %parameters );

        # only accept XML prologs with version parameter specified
        if ( exists($parameters{version}) ) {

            # if encoding is specified, get the corresponding ID.
            # otherwise leave it undefined
            my $encoding_id = undef;
            if ( exists($parameters{encoding}) ) {
                $encoding_id = $self->get_encoding_id( $parameters{encoding} );

                # save xml_encoding_id
                $self->{xml_encoding_id} = $encoding_id;
            }

            # get the XML Prolog ID
            my $xml_prolog_id = $self->get_xml_prolog_id( $parameters{version} , $encoding_id);

            # save xml_prolog_id
            $self->{xml_prolog_id} = $xml_prolog_id;
        }
    }
}




=head2 start_document, end_document, default

These methods do nothing at all.
They are only provided, to provide full interface for the HTML::Parser class.

=cut
sub start_document {}
sub end_document {}
sub default {}




=head2 commit

Add cached element, element_attribute and element_attribute_value counts
to database.

NB! This method also resets the counts of elements, attributes and values.

=cut
sub commit {
    my $self = shift;

    # use the following cache for HTML elements
    my $elements = $self->{cache}->{html_elements}->{cache};

    # get current page
    my $page_id = $self->{current_page_id} || die("No current page ID specified.");

    # vars used in loops
    my $element_id;
    my $element_count;
    my $element_attributes;
    my $attribute_id;
    my $attribute_count;
    my $attribute_values;
    my $value_id;
    my $value_count;


    # loop through elements
    while ( my ( $element, $properties ) = each( %{$elements} ) ) {

        $element_id = $properties->{id};
        $element_count = $properties->{count} || 0;
        $element_attributes = $properties->{attributes} || {};

        # if at least one element exists, add record to database
        if ( $element_count > 0 ) {
            $self->{sql}->{html_elements}->{insert_webpage_element}->execute(
                $page_id,
                $element_id,
                $element_count
            );
        }

        # loop through attributes
        while ( my ( $attribute, $properties ) = each( %{$element_attributes} ) ) {

            $attribute_id = $properties->{id};
            $attribute_count = $properties->{count} || 0;
            $attribute_values = $properties->{values} || {};

            # if at least one attribute exists, add record to database
            if ( $attribute_count > 0 ) {
                $self->{sql}->{html_element_attributes}->{insert_webpage_element}->execute(
                    $page_id,
                    $attribute_id,
                    $attribute_count
                );
            }

            # loop through values
            while ( my ( $value, $properties ) = each( %{$attribute_values} ) ) {

                $value_id = $properties->{id};
                $value_count = $properties->{count} || 0;

                # if at least one value exists, add record to database
                if ( $value_count > 0 ) {
                    $self->{sql}->{html_element_attribute_values}->{insert_webpage_element}->execute(
                        $page_id,
                        $value_id,
                        $value_count
                    );
                }

                # reset value count
                $properties->{count} = 0;
            }

            # reset attribute count
            $properties->{count} = 0;
        }

        # reset element count
        $properties->{count} = 0;
    }


    if ( $self->{doctype_id} ) {
        # set the doctype of current page
        $self->{sql}->{doctypes}->{insert_webpage_element}->execute(
            $self->{doctype_id},
            $page_id
        );
    }

    if ( $self->{xml_prolog_id} ) {
        # Set the XML Prolog ID of current webpage
        $self->{sql}->{xml_prologs}->{insert_webpage_element}->execute(
            $self->{xml_prolog_id},
            $page_id
        );
    }

    # secondly try to add encoding from XML prolog
    if ( $self->{xml_encoding_id} ) {
        # try setting the Encoding of current webpage
        # this will fail, when encoding was specified already in HTTP headers.
        $self->{sql}->{encodings}->{insert_webpage_element}->execute(
            $self->{xml_encoding_id},
            $page_id
        );
    }

}




# Format attribute value based on the rules
# specified for the element and attribute name.
#
# If the value of variable is not meant to be stored,
# returns false.
#
# Otherwise returns the value itself.
#
# Also, the capturing of javascript and css
# inline data and links to external files, takes place here.
#
sub format_attribute_value {
    my $self = shift;
    my $value = shift;
    my $attribute = shift;
    my $element = shift;
    my $all_attributes = shift;

    if ( exists( $STORABLE_ATTRIBUTE_NAMES->{$attribute} ) ) {

        # Trim spaces from beginning and end of the value
        $value = WebStatistics::Util::trim( $value );

        if ( $attribute eq "name" ) {
            # filter those out
            # For our survey we're not interested of these values,
            # but maybe in the future someday
            return; #false
        }


        elsif ( $attribute =~ m{^on[a-z]+$}i ) {

            # if inline script ends with identifier
            # append a space
            if ( !( $value =~ m![a-zA-Z0-9_]$!s ) ) {
                $value .= " ";
            }

            # Save as inline JavaScript
            $self->{inline_javascript} .= $value;

            return; #false
        }


        elsif ( $attribute eq "style" ) {

            # if style declaration does not end with a semicolon, append it.
            if ( !( $value =~ m{;\s*$}s ) ) {
                $value .= ";";
            }

            # Save as inline CSS
            $self->{inline_css} .= $value;

            return; #false
        }


        elsif ( $attribute eq "href" ) {
            # strip parameters from the end of URI
            $value =~ s{\?.*$}{};

            # if REL="stylesheet", then save link for CSS parsing
            # we only collect normal stylesheets - alternates aren't considered.
            if (
                exists( $all_attributes->{rel} ) &&
                $all_attributes->{rel} =~ m{^\s*stylesheet\s*$}i
            ) {
                push( @{$self->{external_css}}, $value );
                return; # false
            }

            # if not HTTP or FTP protocol
            elsif (
                !( $value =~ m{^(?:https?|s?ftp)://}i ) &&
                ( $value =~ m{^([a-z]+:)}i )
            ) {
                # save protocol name
                return lc($1);
            }

            # if file extension exists
            elsif ( $value =~ $RE_URL_WITH_FILE_EXTENSION ) {
                # extract file extension
                $value = $1;

                return lc($value);
            }

            # if links to validators
            elsif  ( $value =~ m{^http://validator.w3.org}i ) {
                return "http://validator.w3.org";
            }
            elsif ( $value =~ m{^http://jigsaw.w3.org/css-validator}i ) {
                return "http://jigsaw.w3.org/css-validator";
            }

            else {
                # by default return false:
                return;
            }

        }


        elsif ( $attribute eq "src" ) {
            # for IMG and INPUT
            if ( $element eq "img" || $element eq "input" ) {
                # if file extension exists
                if ( $value =~ m{^.*\.(\w{3,4})$} ) {
                    # extract file extension
                    $value =~s{^.*\.(\w{3,4})$}{$1}i;

                    return lc($value);
                }
            }
            elsif ( $element eq "script" ) {
                # for SCRIPT, save link for later JavaScript parsing
                push( @{$self->{external_javascript}}, $value );
                return; # false
            }
            else {
                return; # false
            }
        }


        elsif ( $attribute eq "target" ) {
            # only allow values like _blank, _self, _parent, _top
            if ( $value =~ m{^_[a-z]+$}i ) {
                return lc($value);
            }
            else {
                # consider all others as user-defined
                return "~USER~DEFINED~";
            }
        }


        elsif ( $attribute eq "face" || $attribute eq "media") {
            # make all separators to use the same format:
            # only one space after a comma and no less.
            $value =~ s{,\s*}{, }g;

            return lc($value);
        }


        elsif ( $attribute eq "alt" ||
                $attribute eq "summary" ||
                $attribute eq "title"
        ) {
            # check for emptyness
            if ( $value =~ m{^\s*$} ) {
                return "~EMPTY~"
            }
            else {
                # check, if TITLE equals ALT
                if ( exists( $all_attributes->{title} ) &&
                     exists( $all_attributes->{alt} ) &&
                     $all_attributes->{title} eq $all_attributes->{alt}
                ) {
                    return "~ALT=TITLE~";
                }

                return "~FILLED~";
            }
        }


        elsif ( $attribute eq "size" ) {
            # for FONT and BASEFONT
            if ( $element eq "font" || $element eq "basefont" ) {
                return lc($value);
            }
            else {
                return; # false
            }
        }


        elsif ( $attribute eq "content" ) {
            # We save the http-equivalents as list of headers,
            # and then parse those as headers, with specific option on,
            # that tells these come from HTML
            if ( exists( $all_attributes->{'http-equiv'} ) ) {
                push( @{$self->{http_equiv}}, $all_attributes->{'http-equiv'} . ": " . $value );
            }
            return; # false
        }


        else {
            # convert to lowercase
            return lc($value);
        }


    }
    else {
        # when the attribute is not inside storable attributes list
        return; #false
    }
}






################################################################################
#
#  Cache Initialization
#
################################################################################


# Read the HTML elements from database and store into cache
sub load_elements {
    my $self = shift;

    $self->{sql}->{html_elements}->{select_all}->execute;

    while ( my $element = $self->{sql}->{html_elements}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{html_elements}->add(
            $element->{html_element_name},
            $element->{html_element_id}
        );
    }
}


# Read the HTML element attributes from database and store into cache
sub load_element_attributes {
    my $self = shift;

    $self->{sql}->{html_element_attributes}->{select_all}->execute;
    while ( my $attribute = $self->{sql}->{html_element_attributes}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{html_elements}->add_element_attribute(
            $attribute->{html_element_name},
            $attribute->{html_attribute_name},
            $attribute->{html_element_attribute_id}
        );
    }
}


# Read the HTML element attribute values from database and store into cache
sub load_element_attribute_values {
    my $self = shift;

    $self->{sql}->{html_element_attribute_values}->{select_all}->execute;

    while ( my $value = $self->{sql}->{html_element_attribute_values}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{html_elements}->add_element_attribute_value(
            $value->{html_element_name},
            $value->{html_attribute_name},
            $value->{html_attribute_value_value},
            $value->{html_element_attribute_value_id}
        );
    }
}


# Read the HTML attributes from database and store into cache
sub load_attributes {
    my $self = shift;

    $self->{sql}->{html_attributes}->{select_all}->execute;

    while ( my $attribute = $self->{sql}->{html_attributes}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{html_attributes}->add(
            $attribute->{html_attribute_name},
            $attribute->{html_attribute_id}
        );
    }
}


# Read the HTML attribute values from database and store into cache
sub load_attribute_values {
    my $self = shift;

    $self->{sql}->{html_attribute_values}->{select_all}->execute;

    while ( my $value = $self->{sql}->{html_attribute_values}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{html_attribute_values}->add(
            $value->{html_attribute_value_value},
            $value->{html_attribute_value_id}
        );
    }
}


# Read the doctypes from database and store into cache
sub load_doctypes {
    my $self = shift;

    $self->{sql}->{doctypes}->{select_all}->execute;

    while ( my $doctype = $self->{sql}->{doctypes}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{doctypes}->add(
            $doctype->{root_element},
            $doctype->{doctype_fpi},
            $doctype->{doctype_si},
            $doctype->{doctype_id}
        );
    }
}


# Read the XML prologs from database and store into cache
sub load_xml_prologs {
    my $self = shift;

    $self->{sql}->{xml_prologs}->{select_all}->execute;

    while ( my $prolog = $self->{sql}->{xml_prologs}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{xml_prologs}->add(
            $prolog->{xml_version},
            $prolog->{encoding_id},
            $prolog->{xml_prolog_id}
        );
    }
}


# Read the encodings from database and store into cache
sub load_encodings {
    my $self = shift;

    $self->{sql}->{encodings}->{select_all}->execute;

    while ( my $encoding = $self->{sql}->{encodings}->{select_all}->fetchrow_hashref ) {
        $self->{cache}->{encodings}->add(
            $encoding->{encoding_name},
            $encoding->{encoding_id}
        );
    }
}








################################################################################
#
#  Specific get_id methods
#
################################################################################


# Get the ID of specified HTML element
sub get_element_id {
    my $self = shift;
    my $element = shift;

    return $self->generic_get_id( "html_elements", [ $element ] );
}

# Get the ID of specified HTML attribute
sub get_attribute_id {
    my $self = shift;
    my $attribute = shift;

    return $self->generic_get_id( "html_attributes", [ $attribute ] );
}


# Get the ID of specified HTML attribute value
sub get_attribute_value_id {
    my $self = shift;
    my $value = shift;

    return $self->generic_get_id( "html_attribute_values", [ $value ] );
}


# Get the ID of specified doctype
sub get_doctype_id {
    my $self = shift;
    my $root = shift;
    my $fpi = shift;
    my $si = shift;

    return $self->generic_get_id( "doctypes", [ $root, $fpi, $si ] );
}


# Get the ID of specified XML Prolog
sub get_xml_prolog_id {
    my $self = shift;
    my $version = shift;
    my $encoding = shift;

    return $self->generic_get_id( "xml_prologs", [$version, $encoding] );
}


# Get the ID of specified encoding
sub get_encoding_id {
    my $self = shift;
    my $encoding = shift;

    return $self->generic_get_id( "encodings", [$encoding] );
}


sub generic_get_id {
    my $self = shift;
    my $item_name = shift;
    my $values = shift;

    return WebStatistics::DBGeneral::get_id( {
        values => $values,
        cache => $self->{cache}->{$item_name},
        db => $self->{sql}->{db},
        sql => $self->{sql}->{$item_name},
    } );
}


################################################################################
#
#  Other get_id method
#
################################################################################


sub get_element_attribute_id {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;
    my $element_id = shift;
    my $attribute_id = shift;

    my $cache = $self->{cache}->{html_elements}; # cache object
    my $insert = $self->{sql}->{html_element_attributes}->{insert_element}; # insert statement
    my $select = $self->{sql}->{html_element_attributes}->{select_id}; # select statement

    my $id;

    # if value or combination of values exists in the cache,
    # return ID directly from cache
    if ( $id = $cache->get_element_attribute_id( $element, $attribute ) ) {
        return $id;
    }
    else {
        # when values are not in the cache
        # then try to INSERT them into the database

        if ( $insert->execute( $element_id, $attribute_id ) ) {
            # get ID from the database last-insert-id
            $id = $self->{sql}->{db}->{mysql_insertid};
        }
        else {
            # when insert fails, then this means the values
            # already exist in the database
            # so we just query the database for those values

            $select->execute( $element_id, $attribute_id );
            my $row = $select->fetchrow_arrayref;
            $id = $row->[0];
            $select->finish;
        }
        # add values and id into cache
        $cache->add_element_attribute( $element, $attribute, $id );

        return $id;
    }
}




sub get_element_attribute_value_id {
    my $self = shift;
    my $element = shift;
    my $attribute = shift;
    my $value = shift;
    my $element_attribute_id = shift;
    my $value_id = shift;

    my $cache = $self->{cache}->{html_elements}; # cache object
    my $insert = $self->{sql}->{html_element_attribute_values}->{insert_element}; # insert statement
    my $select = $self->{sql}->{html_element_attribute_values}->{select_id}; # select statement

    my $id;

    # if value or combination of values exists in the cache,
    # return ID directly from cache
    if ( $id = $cache->get_element_attribute_value_id( $element, $attribute, $value ) ) {
        return $id;
    }
    else {
        # when values are not in the cache
        # then try to INSERT them into the database

        if ( $insert->execute( $element_attribute_id, $value_id ) ) {
            # get ID from the database last-insert-id
            $id = $self->{sql}->{db}->{mysql_insertid};
        }
        else {
            # when insert fails, then this means the values
            # already exist in the database
            # so we just query the database for those values

            $select->execute( $element_attribute_id, $value_id );
            my $row = $select->fetchrow_arrayref;
            $id = $row->[0];
            $select->finish;
        }
        # add values and id into cache
        $cache->add_element_attribute_value( $element, $attribute, $value, $id );

        return $id;
    }
}





=head1 AUTHOR

Rene Saarsoo <nene@triin.net>

This module is licensed under the same terms as Perl itself.

=cut


1;
























