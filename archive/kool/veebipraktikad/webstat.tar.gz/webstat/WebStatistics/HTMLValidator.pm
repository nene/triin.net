package WebStatistics::HTMLValidator;

use warnings;
use strict;
use WebStatistics::DBGeneral;
use Data::Dumper;

use WebStatistics::HTMLValidatorPatterns;

use vars qw(
    $RE_ERROR_MESSAGE
);


$RE_ERROR_MESSAGE = qr{
    ^
    [^:]+       # filename
    :
    [0-9]+      # line nr
    :
    [0-9]+      # character nr
    :
    ([WE])      # W - Warning; E - Error
    :
    \s*(.*)     # Message
    $
}xi;


=head1 NAME

WebStatistics::HTMLValidator - interface for offline WDG HTML Validator.

=head1 SYNOPSIS

    use WebStatistics::HTMLValidator;

    # Create database and cache objects
    my $db = DBI->connect( "DBI:mysql:DatabaseName", "user", "pass");
    my $sql = new WebStatistics::SQL::General( $db );
    my $cache = new WebStatistics::Cache::General();

    my $validator = new WebStatistics::HTMLValidator( {
        DatabaseCache => $cache,
        SQLStatements => $sql,
    } );

    $validator->validate( "/home/john/www/index.html" );

    if ( $validator->is_valid ) {
        print "VALID HTML :)\n";
    }
    else {
        print "INVALID HTML :(\n";
        print $validator->get_error_count . " errors.\n";
    }

=head1 DESCRIPTION


=head1 METHODS


=cut




# constructor
sub new {
    my $type = shift;
    my $options = shift;

    my $self = bless {}, $type;

    # manage options
    $self->{cache} = $options->{DatabaseCache} || die("No database cache specified");
    $self->{sql} = $options->{SQLStatements} || die("No SQL statements manager specified");
    $self->{current_page_id} = $options->{CurrentPageId} || 0;

    # Init statistical attributes
    $self->init_statistical_attributes();

    return $self;
}





=head2 GET and SET methods

=head3 set_current_page_id( $id )

Set the ID of current webpage in the database.

=cut
sub set_current_page_id {
    my $self = shift;
    my $current_page_id = shift;

    $self->{current_page_id} = $current_page_id || die("No current page ID specified.");
}


=head3 get_error_count

Returns the number of validation errors.

=cut
sub get_error_count {
    my $self = shift;

    return $self->{error_count};
}




=head3 is_valid

Returns true, if HTML file was valid.

=cut
sub is_valid {
    my $self = shift;

    if ( $self->{error_count} == 0 ) {
        return 1;
    }
    else {
        return 0;
    }
}




=head2 validate( $filename )

Validate HTML file.

=cut
sub validate {
    my $self = shift;
    my $filename = shift;

    # execute WDG validator
    # use emacs-style output - fields are separated by colons.
    open(my $validator, "validate --emacs '$filename' |") || die "Can't execute validate!";

    # read validator output
    while ( my $line = <$validator> ) {

        if ($line =~ $RE_ERROR_MESSAGE ) {
            if ( $1 eq 'E' ) {
                # Error
                $self->{cache}->{html_errors}->increment_count( get_error_message_id( $2 ) );
                $self->{error_count}++;
            }
            else {
                # Warnings are ignored
            }
        }
        else {
            # Ignorable validator output
        }


    }
}




################################################################################
#
#  Initialization
#
################################################################################


=head2 init_statistical_attributes

Initialize the values of statistical attributes,
like setting comment-length to zero.

=cut
sub init_statistical_attributes {
    my $self = shift;

    $self->{error_count} = 0;
}




=head2 commit

Commit results of HTML validation to database.

=cut
sub commit {
    my $self = shift;

    my $cache = $self->{cache}->{html_errors}->{cache};
    my $page_id = $self->{current_page_id} || die("No current page ID specified.");

    while ( my ($error_id, $attributes) = each( %$cache ) ) {
        # add error message count to database
        if ($attributes->{count} > 0) {
            $self->{sql}->{html_errors}->{insert_webpage_element}->execute(
                $page_id,
                $error_id,
                $attributes->{count}
            );
        }

        # reset count
        $attributes->{count} = 0;
        if ( $attributes->{count} != $cache->{$error_id}->{count} ) {die "ASSERT: cache not reset"; }
    }
}







1;
