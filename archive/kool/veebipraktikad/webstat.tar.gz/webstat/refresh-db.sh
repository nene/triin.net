mysql webstat < sql/main.sql
mysql webstat < sql/http_statuses.sql
mysql webstat < sql/html_validator_messages.sql
mysql webstat < sql/css_validator_messages.sql
mysql webstat < sql/javascript_elements.sql

