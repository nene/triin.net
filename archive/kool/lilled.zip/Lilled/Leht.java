import java.awt.*;

public class Leht
{
    int h=0;
    int dir=0;
    int maxh=0;

    public Leht(int ndir)
    {
    	dir=ndir;
    	maxh=(int)(Math.random()*20);
    }
    public void grow()
    {
    	if (h<maxh)
    	{
    		h++;
    	}
    }

    public int draw(Graphics g, int x, int y)
    {
        if (dir==0)
        {
        	g.drawLine(x,y,x-h,y-h);
        }
        else
        {
        	g.drawLine(x,y,x+h,y-h);
        }
        return 0;
    }
}
