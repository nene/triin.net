import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Aas extends Frame implements MouseListener, Runnable
{
    Vector lilled=new Vector();
    TextField tfLehtedeArv=new TextField("9");
    Choice chKiirus=new Choice();

    public Aas()
    {
        setLayout(new BorderLayout());
        Panel paneel = new Panel();
        add(paneel, BorderLayout.NORTH);
        paneel.setLayout(new GridLayout(0,4));

        paneel.add(new Label("Lehtede arv:", Label.RIGHT));
        paneel.add(tfLehtedeArv);
        paneel.add(new Label("Kiirus:", Label.RIGHT));
        paneel.add(chKiirus);
        chKiirus.add("aeglane");
        chKiirus.add("keskmine");
        chKiirus.add("kiire");
        chKiirus.add("kohutav");
        chKiirus.add("�le m�istuse");
        chKiirus.select(1);

        addMouseListener(this);
    	new Thread(this).start();
    }

    public void paint(Graphics g)
    {
    	Lill f=null;
        for (int i=0;i<lilled.size();i++)
    	{
    		f=(Lill)lilled.get(i);
    		int xxx=f.draw(g);
    	}
    }

    public void mouseClicked(MouseEvent e)
    {
        Lill f=new Lill(e.getX(),e.getY(),Integer.valueOf(tfLehtedeArv.getText()).intValue());
        lilled.add(f);
        repaint();
    }
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}

    public void run()
    {
    	Lill f=null;
        while (true)
        {
            for (int i=0;i<lilled.size();i++)
        	{
        		f=(Lill)lilled.get(i);
        		f.grow();
        	}
        	repaint();
        	try
        	{
                Thread.sleep((int)(200/(chKiirus.getSelectedIndex()+1)));
            }catch(Exception e){}
        }
    }

}
