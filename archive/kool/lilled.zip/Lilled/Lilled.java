import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class Lilled
{
    public static void main( String argumendid[] )
    {
    	Aas f=new Aas();
    	f.setSize(300,300);
    	f.setVisible(true);
    	f.addWindowListener(new WindowAdapter()
        {
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
		});
    }

}
