import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Lill
{
    int x=0;
    int y=0;
    int h=0;
    int idu=0;
    int pung=0;
    int ois=0;
    int state=0;
    int maxh=0;
    int maxois=0;
    Vector lehed=new Vector();

    public Lill(int nx, int ny, int count)
    {
    	x=nx;
    	y=ny;

    	Leht leht=null;
        for (int i=0;i<count;i++)
    	{
            leht=new Leht(i%2);
            lehed.add(leht);
        }
    	maxh=50+(int)(Math.random()*100);
    	maxois=10+(int)(Math.random()*30);
    }

    public int draw(Graphics g)
    {
    	g.drawLine(x,y,x-idu,y-idu);
    	g.drawLine(x,y,x+idu,y-idu);
        g.drawLine(x,y,x,y-h);

        int pdiv2=(int)(pung/2);
        g.drawOval(x-pdiv2,y-h-pung,pung,pung);

        double step=(double)pung/14;
        double alphastep=Math.PI/14*((double)ois/maxois);
        double alpha=0;
        double prefix=(Math.PI/2*(1-(double)ois/maxois));
        int dx=0;
        int dy=0;
        for (int i=0;i<15;i++)
        {
            alpha=alphastep*i;
            dx=(int)(Math.cos(prefix+alpha)*ois);
            dy=(int)(Math.sin(prefix+alpha)*ois);
            g.drawLine(
              x-pdiv2+(int)(i*step),
              y-h-pdiv2,
              x-pdiv2+(int)(i*step)-dx,
              y-h-pdiv2-dy
            );
        }

    	Leht leht=null;
    	int xxx=0;
    	step=(double)h/lehed.size();
        for(int i=0;i<lehed.size();i++)
    	{
    		leht=(Leht)lehed.get(i);
    		xxx=leht.draw(g,x,(int)(y-step*i));
    	}
        return 0;
    }

    public void grow()
    {
    	switch (state)
    	{
        	case 0:
        	{
        		if (idu<10)
        		{
                    idu++;
                }
                else
                {
                    state++;
                }
            }
            break;
            case 1:
            {
                if (h<80 && h<maxh)
            	{
                    h++;
                }
                else
                {
                	state++;
                }
                if (idu>0)
                {
                	idu--;
                }
            }
            break;
            case 2:
            {
            	if (pung<10)
            	{
                    pung++;
                }
            	if (h<maxh)
            	{
                    h++;
                }
                if (pung==10 && h==maxh)
                {
                	state++;
                }
            }
            break;
            case 3:
            {
            	if (ois<maxois)
            	{
                    ois++;
            	}
            }
        }
        
        if (h>20)
        {
        	Leht leht=null;
            for(int i=0;i<lehed.size();i++)
        	{
        		if (Math.random()*6<1)
        		{
                    leht=(Leht)lehed.get(i);
                    leht.grow();
                }
        	}
        }
    }

}
