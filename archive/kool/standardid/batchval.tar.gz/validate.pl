#!/usr/bin/perl

$method="";
$outfile="results.csv";

foreach $arg (@ARGV)
{
    if ($arg=~/^--?/)
    {
        if ($arg eq "-b" or $arg eq "--before")
        {
            $method="b";
        }
        elsif ($arg eq "-a" or $arg eq "--after")
        {
            $method="a";
        }
        elsif ($arg eq "-o" or $arg eq "--output")
        {
            $method="o";
        }
        elsif ($arg eq "-h" or $arg eq "--help")
        {
            print "Usage: ./validate.pl [options]\n\n";
            print "Options:\n--------\n";
            print "-a --after <data1> <data2> ...  Data to add at the beginning of\n";
            print "                                comma-separated-list.\n\n";
            print "-b --before <data1> <data2> ... Data to add at the end of\n";
            print "                                comma-separated-list.\n\n";
            print "-h --help                       Print this message and exit.\n\n";
            print "-o --output <filename>          File to output comma-separated-list.\n";
            print "                                Default is 'results.csv'.\n\n";
            print "-t --titles <filename>          Output column headers to specified file.\n";
            exit(0);
        }
        elsif ($arg eq "-t" or $arg eq "--titles")
        {
            $method="t";
        }
        else
        {
            print "Invalid argument: '$arg'\n";
            exit(99);
        }
    }
    else
    {
        if ($method eq "b")
        {
            push(@before, $arg);
        }
        elsif ($method eq "a")
        {
            push(@after, $arg);
        }
        elsif ($method eq "t")
        {
            open(OUT, ">$arg");
            foreach $entry (@before)
            {
                print OUT "$entry,";
            }
            print OUT "valid,doctype,";
            print OUT '"FOO" declaration not allowed in instance,';
            print OUT '"FOO" is not a member of a group specified for any attribute,';
            print OUT '"FOO" is not a member of the group specified in the declared value of this attribute,';
            print OUT '"FOO" is not a reserved name,';
            print OUT '"FOO" not finished but containing element ended,';
            print OUT '"FOO" not finished but document ended,';
            print OUT 'DTD did not contain element declaration for document type name,';
            print OUT 'ID "FOO" already defined,';
            print OUT 'ID "FOO" first defined here,';
            print OUT 'NET-enabling start-tag not immediately followed by null end-tag,';
            print OUT 'an attribute specification must start with a name or name token,';
            print OUT 'an attribute value literal can occur in an attribute specification list only after a ... delimiter,';
            print OUT 'an attribute value must be a literal unless it contains only name characters,';
            print OUT 'an attribute value specification must be an attribute value literal unless SHORTTAG YES is specified,';
            print OUT 'an attribute value specification must start with a literal or a name character,';
            print OUT 'cannot generate system identifier for entity "FOO",';
            print OUT 'cannot generate system identifier for general entity "FOO",';
            print OUT 'character "FOO" invalid...,';
            print OUT 'character "FOO" is not allowed in the value of attribute "BAR",';
            print OUT 'character "FOO" is the first character of a delimiter but occurred as data,';
            print OUT 'character "FOO" not allowed in attribute specification list,';
            print OUT 'character "FOO" not allowed in end tag,';
            print OUT 'character "FOO" not allowed in prolog,';
            print OUT 'character data is not allowed here,';
            print OUT 'comment [declaration] started here,';
            print OUT 'delimiter "FOO" invalid...,';
            print OUT 'document type does not allow element "FOO" here...,';
            print OUT 'duplicate specification of attribute "FOO",';
            print OUT 'element "FOO" not allowed here...,';
            print OUT 'element "FOO" undefined,';
            print OUT 'end of document in prolog,';
            print OUT 'end tag for "FOO" omitted...,';
            print OUT 'end tag for "FOO" which is not finished,';
            print OUT 'end tag for element "FOO" which is not open,';
            print OUT 'entity end not allowed in comment,';
            print OUT 'entity end not allowed in processing instruction,';
            print OUT 'entity was defined here,';
            print OUT 'general entity "FOO" not defined and no default entity,';
            print OUT 'invalid attribute value,';
            print OUT 'invalid comment declaration...,';
            print OUT 'invalid formal public identifier "FOO"...,';
            print OUT 'length of attribute value must not exceed LITLEN less NORMSEP (1022),';
            print OUT 'literal is missing closing delimiter,';
            print OUT 'missing a required sub-element of "FOO",';
            print OUT 'multiple comments in comment declaration,';
            print OUT 'name start character invalid...,';
            print OUT 'no document element,';
            print OUT 'no document type declaration...,';
            print OUT 'no system id specified,';
            print OUT 'non SGML character number FOO,';
            print OUT 'reference not terminated by REFC delimiter,';
            print OUT 'reference to entity "FOO" for which no system identifier could be generated,';
            print OUT 'reference to external entity in attribute value,';
            print OUT 'reference to non-SGML character,';
            print OUT 'required attribute "FOO" not specified,';
            print OUT 'start tag for "FOO" omitted but its declaration does not permit this,';
            print OUT 'start tag was here,';
            print OUT 'syntax of attribute value does not conform to declared value,';
            print OUT 'text is not allowed here...,';
            print OUT 'the name and VI delimiter can be omitted from an attribute specification only if SHORTTAG YES is specified,';
            print OUT 'there is no attribute "FOO"...,';
            print OUT 'unknown declaration type "FOO",';
            print OUT 'unknown entity "FOO",';
            print OUT 'unterminated comment...,';
            print OUT 'value of attribute "FOO" cannot be "BAR"...,';
            print OUT 'value of attribute "FOO" invalid,';
            print OUT 'value of attribute "FOO" must be a single token,';
            print OUT 'entity reference illegal after document element,';
            print OUT 'cannot generate system identifier for public text "FOO",';
            print OUT 'named character reference,';
            print OUT '"FOO" is not a function name,';
            print OUT 'number of open elements exceeds TAGLVL (100),';
            print OUT 'unclosed end-tag requires SHORTTAG YES,';
            print OUT 'could not get "FOO" from "BAR"... ,';
            print OUT 'DTDs other than base allowed only if CONCUR YES or EXPLICIT YES,';
            print OUT 'document type "FOO" already defined,';
            print OUT 'S separator in comment declaration,';
            print OUT 'value of fixed attribute "FOO" not equal to default,';
            print OUT 'reference to non-existent ID "FOO",';
            print OUT 'an entity end in a literal must terminate an entity referenced in the same literal,';
            print OUT 'count';
            print OUT 'unclosed start-tag requires SHORTTAG YES,';
            print OUT 'entity end not allowed in end tag,';
            print OUT 'name character invalid...,';
            print OUT 'no start tag specified for implied empty element "FOO",';
            print OUT 'entity end not allowed in attribute specification list except in attribute value literal,';
            print OUT 'digit invalid...,';
            print OUT '"FOO" is not a character number in the document character set,';
            print OUT 'processing instruction does not start with name,';
            
            foreach $entry (@after)
            {
                print OUT ",$entry";
            }
            print OUT "\n";
            close(OUT);
            exit (0);
        }
        elsif ($method eq "o")
        {
            $outfile=$arg;
        }
    }
}


open(IN, '-');
@lines=<IN>;

$doctype="";
$err_cnt=0;

foreach $_ (@lines)
{
    if ( /<h2[^>]*>This Page Is (<strong>not<\/strong> )?Valid( (<a [^>]*>)?([^<>]*)(<\/a>)?(.*))?!<\/h2>/i )
    {
        if ($1 eq "<strong>not<\/strong> ")
        {
            $valid="false";
        }else{
            $valid="true";
        }
        
        $doctype="$4$6";
        
        if ($valid eq "true")
        {
            # Valid HTML
            # No further processing necessary
            print "Valid $doctype!\n";
            break; 
        }else{
            # Invalid HTML
            # Further processing necessary
            print "Not Valid $doctype\n";
            if ($doctype eq "")
            {
                print "Not a doctype based validation! Questionable HTML.\n";
                $doctype="none";
            }
            print "Listing errors found:\n";
        }
    }
    elsif(/<h2[^>]*>This Page <em>Tentatively<\/em> Validates As( (<a [^>]*>)?([^<>]*)(<\/a>)?(.*))? \(Tentatively Valid\)!<\/h2>/)
    {
        $valid="tentatively";
        $doctype="$3$5";
        print "Tentatively Valid $doctype!\n";
        break;
    }
    elsif( /<h3>No DOCTYPE Found! Falling Back to HTML 4.01 Transitional<\/h3>/i )
    {
        $doctype_exists="false";
        $doctype="HTML 4.01 Transitional";
    }
    elsif( /<h3>No Character Encoding Found! Falling back to UTF-8\.<\/h3>/i )
    {
        print "No Character Encoding Found! Falling back to UTF-8.\n";
    }
    elsif( /Sorry, I am unable to validate this document because on line/i )
    {
        print "Wrong Encoding! Exiting script.\n";
        exit(1); # Wrong character encoding I got the following unexpected response
    }
    elsif( /I got the following unexpected response/i )
    {
        print "Page unavailable or access denied for W3C validator!\n";
        exit(4); # Access denied
    }
    elsif( /Fatal error/i )
    {
        print "Fatal Error!\n";
        exit(5); # Fatal error with encoding or DTD
    }
    elsif( /<span class="msg">([^>]+)<\/span>/i )
    {
        # error message fond
        $err_cnt=$err_cnt+1;
        $message = $1;
        $message =~ s/&#34;/"/g;
        $message =~ s/&#60;/</g;
        $message =~ s/&#62;/>/g;
        
        
        $_ = $message;
        $err_code=0;
        $extra="";
        
        if( /"(.*)" declaration not allowed in instance/i )
        {
            $err_code=1;
            $extra=$1;
        }
        elsif( /"(.*)" is not a member of a group specified for any attribute/i )
        {
            $err_code=2;
            $extra=$1;
        }
        elsif( /"(.*)" is not a member of the group specified in the declared value of this attribute/i )
        {
            $err_code=3;
            $extra=$1;
        }
        elsif( /"(.*)" is not a reserved name/i )
        {
            $err_code=4;
            $extra=$1;
        }
        elsif( /"(.*)" not finished but containing element ended/i )
        {
            $err_code=5;
            $extra=$1;
        }
        elsif( /"(.*)" not finished but document ended/i )
        {
            $err_code=6;
            $extra=$1;
        }
        elsif( /DTD did not contain element declaration for document type name/i )
        {
            $err_code=7;
        }
        elsif( /ID "(.*)" already defined/i )
        {
            $err_code=8;
            $extra=$1;
        }
        elsif( /ID "(.*)" first defined here/i )
        {
            $err_code=9;
            $extra=$1;
        }
        elsif( /NET-enabling start-tag not immediately followed by null end-tag/i )
        {
            $err_code=10;
        }
        elsif( /an attribute specification must start with a name or name token/i )
        {
            $err_code=11;
        }
        elsif( /an attribute value literal can occur in an attribute specification list only after a .* delimiter/i )
        {
            $err_code=12;
        }
        elsif( /an attribute value must be a literal unless it contains only name characters/i )
        {
            $err_code=13;
        }
        elsif( /an attribute value specification must be an attribute value literal unless SHORTTAG YES is specified/i )
        {
            $err_code=14;
        }
        elsif( /an attribute value specification must start with a literal or a name character/i )
        {
            $err_code=15;
        }
        elsif( /cannot generate system identifier for entity `HTML'/i )
        {
            $err_code=16;
        }
        elsif( /cannot generate system identifier for general entity "(.*)"/i )
        {
            $err_code=17;
            $extra=$1;
        }
        elsif( /character "(.*)" invalid.*/i )
        {
            $err_code=18;
            $extra=$1;
        }
        elsif( /character "(.*)" is not allowed in the value of attribute "(.*)"/i )
        {
            $err_code=19;
            $extra="$1 $2";
        }
        elsif( /character "(.*)" is the first character of a delimiter but occurred as data/i )
        {
            $err_code=20;
            $extra=$1;
        }
        elsif( /character "(.*)" not allowed in attribute specification list/i )
        {
            $err_code=21;
            $extra=$1;
        }
        elsif( /character "(.*)" not allowed in end tag/i )
        {
            $err_code=22;
            $extra=$1;
        }
        elsif( /character "(.*)" not allowed in prolog/i )
        {
            $err_code=23;
            $extra=$1;
        }
        elsif( /character data is not allowed here/i )
        {
            $err_code=24;
        }
        elsif( /comment (declaration )?started here/i )
        {
            $err_code=25;
        }
        elsif( /delimiter "(.*)" invalid.*/i )
        {
            $err_code=26;
            $extra=$1;
        }
        elsif( /document type does not allow element "(.*)" here.*/i )
        {
            $err_code=27;
            $extra=$1;
        }
        elsif( /duplicate specification of attribute "(.*)"/i )
        {
            $err_code=28;
            $extra=$1;
        }
        elsif( /element "(.*)" not allowed here.*/i )
        {
            $err_code=29;
            $extra=$1;
        }
        elsif( /element "(.*)" undefined/i )
        {
            $err_code=30;
            $extra=$1;
        }
        elsif( /end of document in prolog/i )
        {
            $err_code=31;
        }
        elsif( /end tag for "(.*)" omitted.*/i )
        {
            $err_code=32;
            $extra=$1;
        }
        elsif( /end tag for "(.*)" which is not finished/i )
        {
            $err_code=33;
            $extra=$1;
        }
        elsif( /end tag for element "(.*)" which is not open/i )
        {
            $err_code=34;
            $extra=$1;
        }
        elsif( /entity end not allowed in comment/i )
        {
            $err_code=35;
        }
        elsif( /entity end not allowed in processing instruction/i )
        {
            $err_code=36;
        }
        elsif( /entity was defined here/i )
        {
            $err_code=37;
        }
        elsif( /general entity "(.*)" not defined and no default entity/i )
        {
            $err_code=38;
            $extra=$1;
        }
        elsif( /invalid attribute value/i )
        {
            $err_code=39;
        }
        elsif( /invalid comment declaration.*/i )
        {
            $err_code=40;
        }
        elsif( /invalid formal public identifier "(.*)".*/i )
        {
            $err_code=41;
            $extra=$1;
        }
        elsif( /length of attribute value must not exceed LITLEN less NORMSEP \(1022\)/i )
        {
            $err_code=42;
        }
        elsif( /literal is missing closing delimiter/i )
        {
            $err_code=43;
        }
        elsif( /missing a required sub-element of "(.*)"/i )
        {
            $err_code=44;
            $extra=$1;
        }
        elsif( /multiple comments in comment declaration/i )
        {
            $err_code=45;
        }
        elsif( /name start character invalid.*/i )
        {
            $err_code=46;
        }
        elsif( /no document element/i )
        {
            $err_code=47;
        }
        elsif( /no document type declaration.*/i )
        {
            $err_code=48;
        }
        elsif( /no system id specified/i )
        {
            $err_code=49;
        }
        elsif( /non SGML character number (.*)/i )
        {
            $err_code=50;
            $extra=$1;
        }
        elsif( /reference not terminated by REFC delimiter/i )
        {
            $err_code=51;
        }
        elsif( /reference to entity "(.*)" for which no system identifier could be generated/i )
        {
            $err_code=52;
            $extra=$1;
        }
        elsif( /reference to external entity in attribute value/i )
        {
            $err_code=53;
        }
        elsif( /reference to non-SGML character/i )
        {
            $err_code=54;
        }
        elsif( /required attribute "(.*)" not specified/i )
        {
            $err_code=55;
            $extra=$1;
        }
        elsif( /start tag for "(.*)" omitted, but its declaration does not permit this/i )
        {
            $err_code=56;
            $extra=$1;
        }
        elsif( /start tag was here/i )
        {
            $err_code=57;
        }
        elsif( /syntax of attribute value does not conform to declared value/i )
        {
            $err_code=58;
        }
        elsif( /text is not allowed here.*/i )
        {
            $err_code=59;
        }
        elsif( /the name and VI delimiter can be omitted from an attribute specification only if SHORTTAG YES is specified/i )
        {
            $err_code=60;
        }
        elsif( /there is no attribute "(.*)".*/i )
        {
            $err_code=61;
            $extra=$1;
        }
        elsif( /unknown declaration type "(.*)"/i )
        {
            $err_code=62;
            $extra=$1;
        }
        elsif( /unknown entity "(.*)"/i )
        {
            $err_code=63;
            $extra=$1;
        }
        elsif( /unterminated comment.*/i )
        {
            $err_code=64;
        }
        elsif( /value of attribute "(.*)" cannot be "(.*)".*/i )
        {
            $err_code=65;
            $extra="$1 $2";
        }
        elsif( /value of attribute "(.*)" invalid/i )
        {
            $err_code=66;
            $extra=$1;
        }
        elsif( /value of attribute "(.*)" must be a single token/i )
        {
            $err_code=67;
            $extra=$1;
        }
        
        
        elsif( /entity reference illegal after document element/i )
        {
            $err_code=68;
        }
        elsif( /cannot generate system identifier for public text "(.*)"/i )
        {
            $err_code=69;
            $extra=$1;
        }
        elsif( /named character reference/i )
        {
            $err_code=70;
        }
        elsif( /"(.*)" is not a function name/i )
        {
            $err_code=71;
            $extra=$1;
        }
        elsif( /number of open elements exceeds TAGLVL \(100\)/i )
        {
            $err_code=72;
        }
        elsif( /unclosed end-tag requires SHORTTAG YES/i )
        {
            $err_code=73;
        }
        elsif( /could not get "(.*)" from "(.*)".*/i )
        {
            $err_code=74;
            $extra="$1$2";
        }
        elsif( /DTDs other than base allowed only if CONCUR YES or EXPLICIT YES/i )
        {
            $err_code=75;
        }
        elsif( /document type "(.*)" already defined/i )
        {
            $err_code=76;
            $extra=$1;
        }
        elsif( /S separator in comment declaration/i )
        {
            $err_code=77;
        }
        elsif( /value of fixed attribute "(.*)" not equal to default/i )
        {
            $err_code=78;
            $extra=$1;
        }
        elsif( /reference to non-existent ID "(.*)"/i )
        {
            $err_code=79;
            $extra=$1;
        }
        elsif( /an entity end in a literal must terminate an entity referenced in the same literal/i )
        {
            $err_code=80;
        }
        elsif( /unclosed start-tag requires SHORTTAG YES/i )
        {
            $err_code=81;
        }
        elsif( /entity end not allowed in end tag/i )
        {
            $err_code=82;
        }
        elsif( /name character invalid.*/i )
        {
            $err_code=83;
        }
        elsif( /no start tag specified for implied empty element "(.*)"/i )
        {
            $err_code=84;
            $extra=$1;
        }
        elsif( /entity end not allowed in attribute specification list except in attribute value literal/i )
        {
            $err_code=85;
        }
        elsif( /digit invalid.*/i )
        {
            $err_code=86;
        }
        elsif( /"(.*)" is not a character number in the document character set/i )
        {
            $err_code=87;
            $extra=$1;
        }
        elsif( /processing instruction does not start with name/i )
        {
            $err_code=88;
        }
        
        
        
        elsif( /cannot continue because of previous errors/i )
        {
            print "Cannot continue because of previous errors!\n";
            exit(7); # Cannot continue because of previous errors!
        }
        elsif(/this is not an SGML document/i)
        {
            print "This is not an SGML document!\n";
            exit(8); # This is not an SGML document!
        }

        print "$err_cnt. $err_code: $extra: $message\n";
        if ($err_code == 0)
        {
            print "Unknown Error\n";
            exit(3);
        }
        $errors{$err_code}=$errors{$err_code}+1;
    }
}



if ($valid eq "" or $doctype eq "")
{
    "Mystery Error!";
    exit(6);
}


# Output results into a file
open(OUT, ">>$outfile");

foreach $entry (@before)
{
    print OUT "$entry,";
}

print OUT "$valid,$doctype";

for ($i=1;$i<89;$i++)
{
    if ($errors{$i} eq "")
    {
        $errors{$i}=0;
    }
    print OUT ",$errors{$i}";
}

print OUT ",$err_cnt";

foreach $entry (@after)
{
    print OUT ",$entry";
}

print OUT "\n";

close(OUT);























