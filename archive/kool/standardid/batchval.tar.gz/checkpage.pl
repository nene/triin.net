#!/usr/bin/perl

$charset="";
$site="";
$outfile="sitestat.csv";

# array of HTML-elements, which our program detects
%elements = (
    "a",0,
    "applet",0,
    "b",0,
    "base",0,
    "body",0,
    "br",0,
    "center",0,
    "div",0,
    "dl",0,
    "em",0,
    "font",0,
    "frameset",0,
    "h1",0,
    "h2",0,
    "h3",0,
    "h4",0,
    "h5",0,
    "h6",0,
    "head",0,
    "hr",0,
    "html",0,
    "i",0,
    "iframe",0,
    "img",0,
    "link",0,
    "map",0,
    "meta",0,
    "object",0,
    "ol",0,
    "p",0,
    "script",0,
    "span",0,
    "strong",0,
    "style",0,
    "table",0,
    "title",0,
    "u",0,
    "ul",0);


# parse arguments
foreach $arg (@ARGV)
{    
    if ($arg=~/^--?/)
    {
        if ($arg eq "-t" or $arg eq "--titles")
        {
            $method="titles";
        }
        elsif ($arg eq "-w" or $arg eq "--www")
        {
            $method="www";
        }
        elsif ($arg eq "-h" or $arg eq "--help")
        {
            print "Usage: ./checkpage.pl [options] <outputfile> < <inputfile>\n\n";
            print "Options:\n--------\n";
            print "-h --help                       Print this message and exit.\n\n";
            print "-t --titles                     Truncate <outputfile>, output column headers\n";
            print "                                to it and exit.\n\n";
            print "-w --www <address>              Sets the address of the page being checked.\n";
            exit(0);
        }
        else
        {
            print "Invalid argument: '$arg'\n";
            exit(99);
        }
    }
    else
    {
        if ($method eq "titles")
        {
            open(OUT, ">$arg");
            print OUT "site,charset";
            foreach $element (keys %elements)
            {
                print OUT ",$element";
            }
            print OUT "\n";
            close OUT;
            exit(0);
        }
        elsif ($method eq "www")
        {
            $site=$arg;
            $method="";
        }
        else
        {
            $outfile=$arg;
        }
    }
}


open(IN, '-');
@lines=<IN>;

foreach $_ (@lines)
{
    
    # check to determine, if the page happens to be an errorpage
    # or page that is under construction.
    
    if ( /<title>.*(viga|forbidden).*<\/title>/i )
    {
        exit(1);
    }
    elsif ( /(<b>|<strong>).*Teenus peatatud.*(<\/b>|<\/strong>)/i )
    {
        exit(1);
    }
    elsif ( /<meta\s+http-equiv=["']?refresh["']?\s+content=["'][0-9]+\s*;\s*URL=([^"'><]+)["']/i )
    {
        if ( !($1 =~ /^https?:\/\/$site\/?$/i) )
        {
            exit(3); #redirect
        }
    }
    
    # look for characterset declaration
    if ( /<meta\s+http-equiv=["']?content-type["']?\s+content=["']text\/html;\s+charset=([^"']*)["']/i )
    {
        $charset=$1;
        $charset =~ tr/A-Z/a-z/;  # convert to lowercase
    }
    
    # count html-elements
    while ( /^([^<]*)<([a-z0-9:]+)[^a-z0-9:]/i )
    {
        $e = lc($2);
        if (exists $elements{$e})
        {
                $elements{$e}++;
        }
        $_ = substr($_, length($1)+1);
    }
}

$element_sum=0;
foreach $count (values %elements)
{
    $element_sum+=$count;
}
if ($element_sum==0)
{
    exit(2); # not an HTML document
}

open(OUT, ">>$outfile");
print OUT "$site,$charset";
foreach $count (values %elements)
{
    print OUT ",$count";
}
print OUT "\n";
close OUT;


print "Page OK!\n";
exit(0);






