#!/usr/bin/python

import os
import urllib2
import sys

def FetchW3C(site, encoding="auto"):
    os.system("date")
    if encoding=="auto":
        encoding="%28detect+automatically%29"
    print 'Waiting for W3C validator...'
    try:
        web = urllib2.urlopen('http://validator.w3.org/check?uri=http%3A%2F%2F'+site+'&charset='+encoding+'&doctype=Inline')
    except:
        return 1
    
    print 'Downloading validator output...'
    f = open(prefs['download_file'], 'w')
    f.write( web.read())
    f.close()
    return 0


def PerlValidator(site,encoding):
    print "Invoking perl script ./validate.pl -b "+site+" "+encoding+" -o "+prefs['validation_file']+" < "+prefs['download_file']
    print '-----------------------------------'
    status =         os.system("./validate.pl -b "+site+" "+encoding+" -o "+prefs['validation_file']+" < "+prefs['download_file'])
    print '-----------------------------------'
    return status/256


def FetchPage(site):
    os.system("date")
    print 'Waiting for '+site+'...'
    try:
        web = urllib2.urlopen('http://'+site)
    except:
        return 1
    print 'Downloading source...'
    f = open(prefs['download_file'], 'w')
    f.write( web.read())
    f.close()
    return 0
    
def PerlTest(site):
    # print "Extra information request: ./triin.pl"
    # status = os.system("./triin.pl "+site+" < "+prefs['download_file']+" >> triin.log")
    
    print "Invoking perl script ./checkpage.pl -w "+site+" "+ prefs['check_file'] +" < "+prefs['download_file']
    print '-----------------------------------'
    status =         os.system("./checkpage.pl -w "+site+" "+ prefs['check_file'] +" < "+prefs['download_file'])
    print '-----------------------------------'
    return status/256
    

def Prepare():
    print "Preparing output files:"
    print "Empty "+prefs['error_log']
    os.system("touch "+prefs['error_log']+"; rm "+prefs['error_log'])
    print "Headers into "+prefs['check_file']
    os.system("./checkpage.pl -t "+prefs['check_file'])
    print "Headers into "+prefs['check_file']
    os.system("./validate.pl -b site encoding -t "+prefs['validation_file'])
    

def Help():
    print "Usage: ./batchval.py [options]"
    print
    print "Options:"
    print "--------"
    print
    print "-i --input <filename>      Set the name of the input file."
    print "                           Default is 'servers.list'"
    print
    print "-v --validation <filename> Set the name of the output file for validation"
    print "                           results. Default is 'results.csv'"
    print
    print "-c --check <filename>      Set the name of the output file for pagecheck"
    print "                           results. Default is 'sitestat.csv'"
    print
    print "-d --download <filename>   Set the name of the download file."
    print "                           This is the file where downloaded"
    print "                           data is temporarily(!) stored."
    print "                           Default is 'check.html'"
    print
    print "-e --error <filename>      Set the name of the error log file."
    print "                           Default is 'err.log'"
    print
    print "-b --debug                 Stop execution when unknown W3C Validator"
    print "                           error message is encountered."
    print
    print "-h --help                  Print this message and exit."
    print
    print "-p --prepare               Initialize outputfiles."
    sys.exit(0)
    

def ParseArguments(prefs):
    mode=""
    for arg in sys.argv[1:]:
        if arg[:2]=="--":
            mode=arg[2:]
            if mode=="help":
                Help()
            elif mode=="debug":
                prefs['debug']="true"
                mode=""
            elif mode=="prepare":
                prefs['prepare']="true"
                mode=""
        elif arg[:1]=="-":
            mode=arg[1:]
            if mode=="h":
                Help()
            elif mode=="b":
                prefs['debug']="true"
                mode=""
            elif mode=="p":
                prefs['prepare']="true"
                mode=""
        else:
            if mode=="i" or mode=="input":
                prefs['input_file']=arg
            elif mode=="c" or mode=="check":
                prefs['check_file']=arg
            elif mode=="v" or mode=="validation":
                prefs['validation_file']=arg
            elif mode=="d" or mode=="download":
                prefs['download_file']=arg
            elif mode=="e" or mode=="errorlog":
                prefs['error_log']=arg
            else:
                print "Invalid arguments!"
                sys.exit(1)
            mode=""

# Open and close the errorlog file before and after each error
# so that when program crashes last error messages won't get lost.
# Also writes error message to stdout
def LogError(site, err):
    errlog = open(prefs['error_log'], 'a')
    errlog.write(site+" : "+err+"\n")
    errlog.close()
    print err

def RemoveLastCheckFileLine():
    x=os.system("head --lines=-1 "+prefs['check_file']+" > temporary")
    x=os.system("mv temporary "+prefs['check_file'])
    




prefs={"input_file":"servers.list", "validation_file":"results.csv","check_file":"sitestat.csv", "download_file":"check.html", "error_log":"err.log", "debug":"false", "prepare":"false"}
ParseArguments(prefs)

if prefs['prepare']=="true":
    Prepare()

f = open(prefs['input_file'], 'r')

for site in f.readlines():
    site = site[:-1]
    encoding="auto"
    status=2
    
    print 'site:',site
    
    if FetchPage(site)==1:
        LogError(site, "URL unreachable!")
    else:
        pt = PerlTest(site)
        
        if pt==1:
            LogError(site,"Page unavailable or access denied!")
        elif pt==2:
            LogError(site,"Not an HTML-document!")
        elif pt==3:
            LogError(site,"Page redirected!")
        else:
            while status>0:
                if FetchW3C(site, encoding)==1:
                    LogError(site,"Error downloading wrom W3C validator!")
                    RemoveLastCheckFileLine()
                    if prefs['debug']=="true":
                        sys.exit(1)
                    break
                else:
                    status = PerlValidator(site,encoding)
                    if status==1:
                        if encoding=="auto":
                            encoding="iso-8859-1"
                            print "Character encoding override:",encoding
                        else:
                            LogError(site,"No Character encoding specified!")
                            RemoveLastCheckFileLine()
                            break
                    elif status==3:
                        LogError(site,"Unknown Error message recovered!")
                        RemoveLastCheckFileLine()
                        if prefs['debug']=="true":
                            sys.exit(1)
                        break
                    elif status==4:
                        LogError(site,"Page unavailable or access denied for W3C validator!")
                        RemoveLastCheckFileLine()
                        break
                    elif status==5:
                        if encoding=="auto":
                            encoding="iso-8859-1"
                            print "Character encoding override:",encoding
                        else:
                            LogError(site,"A Fatal Error occurred (with encoding or DTD)!")
                            RemoveLastCheckFileLine()
                            break
                    elif status==6:
                        LogError(site,"A Mystery Error!")
                        RemoveLastCheckFileLine()
                        if prefs['debug']=="true":
                            sys.exit(1)
                        break
                    elif status==7:
                        LogError(site,"Cannot continue because of previous errors!")
                        RemoveLastCheckFileLine()
                        if prefs['debug']=="true":
                            sys.exit(1)
                        break
                    elif status==8:
                        LogError(site,"This is not an SGML document!")
                        RemoveLastCheckFileLine()
                        if prefs['debug']=="true":
                            sys.exit(1)
                        break
                    elif status==0:
                        pass
                    else:
                        LogError(site,"Error in script!")
                        RemoveLastCheckFileLine()
                        if prefs['debug']=="true":
                            sys.exit(1)
                        break
                    
    

    
print "Done"
print

f.close()
