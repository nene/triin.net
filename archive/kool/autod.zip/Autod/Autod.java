import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class Autod
{
    public static void main( String argumendid[] )
    {
        if (argumendid.length==1)
        {
            Liiklus f=new Liiklus(argumendid[0]);
            f.setSize(1024,768);
            f.setVisible(true);
        }
        else
        {
            System.out.println("Sa pead andma parameetrina serveri aadressi!");
        }
     
    }

}
