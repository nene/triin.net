import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.net.*;

public class Liiklus extends Frame implements KeyListener, Runnable, WindowListener
{
    static int NONE=0;
    static int MOVE=1;
    static int LEAVE=2;
    static int JOIN=3;

    Vector autod=new Vector();
    boolean gas=false;
    boolean left=false;
    boolean right=false;
    boolean brake=false;
    Auto autoke=null;
    KlientThread waiter = new KlientThread(this);
    Socket sc=null;
    DataInputStream sisend=null;
    DataOutputStream valjund=null;
    Vector majad=new Vector();
    Vector foorid=new Vector();

    public Liiklus(String aadress)
    {
        autoke=new Auto(365,100,0,majad,autod,foorid);
        for (int i=0;i<10;i++)
        {
            autod.add(null);
        }

        try
        {
            sc = new Socket(aadress, 3001);
            // Ksime sisend- ja v�jundvoo
            valjund = new DataOutputStream(sc.getOutputStream());
            sisend = new DataInputStream(sc.getInputStream());


            int id = sisend.readInt();
            autod.set(id, autoke);
        }
        catch(Exception e)
        {
            System.out.println("Error when connecting to server! "+e);
            System.exit(1);
        }

        majad.add(new Maja(0,0,300,300));
        majad.add(new Maja(0,380,300,300));
        majad.add(new Maja(380,0,300,300));
        majad.add(new Maja(380,380,300,300));
        majad.add(new Maja(760,0,300,300));
        majad.add(new Maja(760,380,300,300));

        foorid.add(new Foor(300,300,80,0));
        foorid.add(new Foor(680,300,80,2));

        addKeyListener(this);
        addWindowListener(this);
        new Thread(this).start();
        waiter.start();
    }

    public void paint(Graphics g)
    {
        int xxx=0;

        // joonistame foorid
        Foor foor=null;
        for (int i=0;i<foorid.size();i++)
        {
            foor = (Foor)foorid.get(i);
            xxx=foor.draw(g);
        }

        // joonistame autod
        Auto auto = null;
        for (int i=0;i<autod.size();i++)
        {
            auto=(Auto)autod.get(i);
            if (auto!=null)
            {
              xxx=auto.draw(g);
            }
        }

        // joonistame majad
        Maja maja=null;
        for (int i=0;i<majad.size();i++)
        {
            maja = (Maja)majad.get(i);
            xxx=maja.draw(g);
        }

    }

    public void keyPressed(KeyEvent e)
    {
        switch (e.getKeyCode())
        {
            case KeyEvent.VK_UP: gas=true; break;
            case KeyEvent.VK_LEFT: left=true; break;
            case KeyEvent.VK_RIGHT: right=true; break;
            case KeyEvent.VK_DOWN: brake=true; break;
        }
    }
    public void keyReleased(KeyEvent e)
    {
        switch (e.getKeyCode())
        {
            case KeyEvent.VK_UP: gas=false; break;
            case KeyEvent.VK_LEFT: left=false; break;
            case KeyEvent.VK_RIGHT: right=false; break;
            case KeyEvent.VK_DOWN: brake=false; break;
        }
    }
    public void keyTyped(KeyEvent e){}

    public void run()
    {
        sendLocation(JOIN);
        Foor foor=null;
        int foorcnt=0;
        while (true)
        {
            //System.out.println(""+gas+" "+brake+" "+left+" "+right);

            if (gas)
            {
                autoke.accelerate();
            }
            if (brake)
            {
                autoke.brake();
            }
            if (left)
            {
                if (autoke.v>0)
                {
                    autoke.turnLeft();
                }
                if (autoke.v<0)
                {
                    autoke.turnRight();
                }

            }
            if (right)
            {
                if (autoke.v>0)
                {
                    autoke.turnRight();
                }
                if (autoke.v<0)
                {
                    autoke.turnLeft();
                }
            }

            if (foorcnt>30)
            {
                foorcnt=0;
                for (int i=0;i<foorid.size();i++)
                {
                    foor=(Foor)foorid.get(i);
                    foor.change();
                }
            }
            else
            {
                foorcnt++;
            }

            autoke.drive();
            repaint();
            sendLocation(MOVE);
            try
            {
                Thread.sleep(100);
            }
            catch(Exception e){}
        }
    }

    public void sendLocation(int action)
    {
        try
        {
        valjund.writeInt(action);
        valjund.writeInt(autoke.x);
        valjund.writeInt(autoke.y);
        valjund.writeDouble(autoke.dir);
        }
        catch(Exception e){}
    }

    public void windowClosing(WindowEvent e)
    {
        sendLocation(LEAVE);
        System.exit(0);
    }

    public void windowActivated(WindowEvent e){}
    public void windowClosed(WindowEvent e){}
    public void windowDeactivated(WindowEvent e){}
    public void windowDeiconified(WindowEvent e){}
    public void windowIconified(WindowEvent e){}
    public void windowOpened(WindowEvent e){}


}
