public class KlientThread extends Thread
{
    Liiklus liiklus=null;

    public KlientThread(Liiklus nliiklus)
    {
    	liiklus=nliiklus;
    }


    public void run()
    {
    	int action=0;
    	int id=0;
    	int x=0;
    	int y=0;
    	double dir=0;
    	Auto auto=null;

		try
		{
            while (true)
        	{
            	action=liiklus.sisend.readInt();
                id=liiklus.sisend.readInt();
                x=liiklus.sisend.readInt();
                y=liiklus.sisend.readInt();
                dir=liiklus.sisend.readDouble();

            	if (action==Liiklus.JOIN)
            	{
            		liiklus.autod.set(id, new Auto(x,y,dir,liiklus.majad,liiklus.autod,liiklus.foorid));
                }
                else
                {
                	if (action==Liiklus.MOVE)
                	{
                		auto = (Auto)liiklus.autod.get(id);
                		auto.x=x;
                		auto.y=y;
                		auto.dir=dir;
                	}
                    else
                    {
                    	liiklus.autod.set(id,null);
                    }
                }
        	}
		}
        catch(Exception e){}
    }

}
