import java.awt.*;

public class Foor
{
    static int RED=0;
    static int GREEN=1;
    static int YELLOW=2;
    int x;
    int y;
    int width;
    int height=20;
    int state=0;

    int south=0;
    int east=0;
    int north=0;
    int west=0;


    public Foor(int nx,int ny,int nwidth,int init)
    {
        x=nx;
        y=ny;
        width=nwidth;
        state=init;
        change();
    }

    public void change()
    {
    	state++;
    	if (state>5)
    	{
    		state=0;
    	}

    	switch (state)
    	{
    		case 0: {west=RED; east=RED; north=GREEN; south=GREEN;} break;
    		case 1: {west=GREEN; east=GREEN; north=RED; south=RED;} break;
    		case 2: {west=RED; east=GREEN; north=GREEN; south=RED;} break;
    		case 3: {west=GREEN; east=RED; north=RED; south=GREEN;} break;
    		case 4: {west=GREEN; east=RED; north=GREEN; south=RED;} break;
    		case 5: {west=RED; east=GREEN; north=RED; south=GREEN;} break;
    	}
    }

    public int setColor(int code, Graphics g)
    {
    	switch (code)
    	{
    		case 0: g.setColor(Color.RED); break;
    		case 1: g.setColor(Color.GREEN); break;
    		case 2: g.setColor(Color.YELLOW); break;
    	}
    	return 0;
    }

    public int draw(Graphics g)
    {

        int xxx=0;
        xxx=setColor(north,g);
        g.fillRect(x,y-height, width,height);
        xxx=setColor(south,g);
        g.fillRect(x,y+width, width,height);

        xxx=setColor(west,g);
        g.fillRect(x-height,y, height,width);
        xxx=setColor(east,g);
        g.fillRect(x+width,y, height,width);

        g.setColor(Color.black);

    	return 0;
    }
}
