import java.awt.*;

public class Maja
{
    int x;
    int y;
    int width;
    int height;

    public Maja(int nx,int ny,int nxw,int nxh)
    {
        x=nx;
        y=ny;
        width=nxw;
        height=nxh;
    }
    
    public int draw(Graphics g)
    {
    	g.drawRect(x,y,width,height);
    	return 0;
    }
}
