import java.awt.*;
import java.util.*;

public class Auto
{
    int x=0;
    int y=0;
    int v=0;
    double dir=0;
    double cosa=0;
    double sina=0;
    double cosb=0;
    double sinb=0;
    Vector majad=null;
    Vector autod=null;
    Vector foorid=null;

    public Auto(int nx, int ny, double ndir, Vector nmajad, Vector nautod, Vector nfoorid)
    {
    	x=nx;
    	y=ny;
    	dir=ndir;
    	majad = nmajad;
    	autod = nautod;
    	foorid = nfoorid;

        cosa=Math.cos(dir);
        sina=Math.sin(dir);
        cosb=Math.cos(dir+Math.PI/2);
        sinb=Math.sin(dir+Math.PI/2);
    }

    public int draw(Graphics g)
    {
        cosa=Math.cos(dir);
        sina=Math.sin(dir);
        cosb=Math.cos(dir+Math.PI/2);
        sinb=Math.sin(dir+Math.PI/2);

        int dx=(int)(cosa*10);
        int dy=(int)(sina*10);
        int fx=(int)(cosb*5);
        int fy=(int)(sinb*5);
        g.drawLine(x-dx+fx,y-dy+fy, x+dx, y+dy);
        g.drawLine(x-dx-fx,y-dy-fy, x+dx, y+dy);

        g.drawLine(x+dx+fx,y+dy+fy, x-dx+fx,y-dy+fy);
        g.drawLine(x+dx-fx,y+dy-fy, x-dx-fx,y-dy-fy);
        g.drawLine(x-dx+fx,y-dy+fy, x-dx-fx,y-dy-fy);
        g.drawLine(x+dx-fx,y+dy-fy, x+dx+fx,y+dy+fy);

    	return 0;
    }

    public void accelerate()
    {
    	v++;
    }

    public void brake()
    {
    	if (v>1)
    	{
            if (v>9)
            {
            	v-=4;
            }
            else
            {
                v-=2;
            }
        }
        else
        {
            if (v>-7)
            {
                v--;
            }
        }
    }

    public void turnLeft()
    {
    	dir-=0.01*Math.abs(v)+0.1;
    }

    public void turnRight()
    {
    	dir+=0.01*Math.abs(v)+0.1;
    }

    public void drive()
    {
        int dx=(int)(cosa*v);
        int dy=(int)(sina*v);
        int newx=x+dx;
        int newy=y+dy;
        boolean crash=false;
        Maja maja=null;

        for (int i=0;i<majad.size();i++)
        {
        	maja=(Maja)majad.get(i);
            if (newx > maja.x && newx < maja.x+maja.width && newy > maja.y && newy < maja.y+maja.height)
            {
                crash=true;
            	break;
            }
        }

        if (crash)
        {
        	v=(int)(-v/2);
        	x-=dx;
        	y-=dy;
        }
        else
        {
        	Auto auto=null;
            for (int i=0;i<autod.size();i++)
        	{
        		auto=(Auto)autod.get(i);
        		if (auto!=null && auto!=this)
        		{
                    if (newx > auto.x-10 && newx < auto.x+10 && newy > auto.y-10 && newy < auto.y+10)
                    {
                    	crash=true;
                    	break;
                    }
                }
            }
            if (crash)
            {
            	v=(int)(-v/2);
            	x-=dx;
            	y-=dy;
            }
            else
            {
                Foor foor=null;
                for (int i=0;i<foorid.size();i++)
                {
                	foor=(Foor)foorid.get(i);
                	if (foor.north==Foor.RED)
                	{
                		if (newx > foor.x && newx < foor.x+foor.width && newy > foor.y - foor.height && newy < foor.y)
                		{
                			crash=true;
                			break;
                		}
                	}
                	if (foor.south==Foor.RED)
                	{
                		if (newx > foor.x && newx < foor.x+foor.width && newy > foor.y + foor.width && newy < foor.y+foor.height+foor.width)
                		{
                			crash=true;
                			break;
                		}
                	}
                	if (foor.west==Foor.RED)
                	{
                		if (newx > foor.x-foor.height && newx < foor.x && newy > foor.y && newy < foor.y+foor.width)
                		{
                			crash=true;
                			break;
                		}
                	}
                	if (foor.east==Foor.RED)
                	{
                		if (newx > foor.x+foor.width && newx < foor.x+foor.width+foor.height && newy > foor.y && newy < foor.y+foor.width)
                		{
                			crash=true;
                			break;
                		}
                	}
                }
                if (crash)
                {
                	v=(int)(-v/2);
                	x-=dx;
                	y-=dy;
                }
                else
                {
                    x=newx;
                	y=newy;
            	}
            }
        }


    }
}










