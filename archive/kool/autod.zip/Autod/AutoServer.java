import java.io.*;
import java.net.*;
import java.util.*;

public class AutoServer
{
    public static void main(String argumendid[]) throws IOException
    {
        ServerSocket ss=new ServerSocket(3001);
        Vector uhendused=new Vector();
        while(true)
        {
            Socket sc=ss.accept();
            uhendused.add(new AutoThread(sc, uhendused));
        }
    }
}

class AutoThread extends Thread
{
    static int NONE=0;
    static int MOVE=1;
    static int LEAVE=2;
    static int JOIN=3;

    Vector v;
    Socket sc;
    int id;
    int x, y;
    double dir;
    DataInputStream sisend;
    DataOutputStream valjund;

    public AutoThread(Socket uus_sc, Vector uus_v)
    {
        v=uus_v;
        sc=uus_sc;
        start();
    }

    // Genereerib l�imele uue ID
    public boolean generateId()
    {
        int[] id_array = new int[v.size()];
        int i;
        // loeme k�ik ID-d massiivi
        for (i=0; i<v.size(); i++)
        {
            id_array[i] = ((AutoThread)v.elementAt(i)).id;
        }
        // sorteerime
        Arrays.sort(id_array);
        // otsime v�ikseima vaba ID v��rtuse
        for (i=0; i<v.size(); i++)
        {
            if (id_array[i]>i)
            {
                id = i;
                break;
            }
        }
        if (i==v.size())
        {
            id=i;
        }

        // kontrollime, et id oleks lubatud pirides
        if (id < 256)
        {
            return true;
        }else
        {
            return false;
        }
    }

    public void sendLocation(AutoThread th, int action) throws IOException
    {
        valjund.writeInt(action);
        valjund.writeInt(th.id);
        valjund.writeInt(th.x);
        valjund.writeInt(th.y);
        valjund.writeDouble(th.dir);
    }

    public void sendId() throws IOException
    {
        valjund.writeInt(id);
    }

    public void sendLocationToOthers(int action) throws IOException
    {
        AutoThread th = null;
        for(int i=0;i<v.size();i++)
        {
            th = (AutoThread)v.get(i);
            if (th!=this)
            {
                th.sendLocation(this, action);
            }
        }
    }

    public void sendOtherUsersInfo() throws IOException
    {
        AutoThread th = null;
        for(int i=0;i<v.size();i++)
        {
            th = (AutoThread)v.get(i);
            if (th!=this)
            {
                valjund.writeInt(JOIN);
                valjund.writeInt(th.id);
                valjund.writeInt(th.x);
                valjund.writeInt(th.y);
                valjund.writeDouble(th.dir);
            }
        }
    }

    public int receiveAction() throws IOException
    {
    	int action=sisend.readInt();
    	if (action==MOVE || action==JOIN)
    	{
            x=sisend.readInt();
            y=sisend.readInt();
            dir=sisend.readDouble();
        }
        return action;
    }

    public void run(){
        try
        {
            sisend=new DataInputStream(sc.getInputStream());
            valjund=new DataOutputStream(sc.getOutputStream());

            if (generateId())
            {
                sendId();
                sendOtherUsersInfo();

                int action=NONE;
                while(true)
                {
                    action=receiveAction();
                    if (action==MOVE || action==JOIN)
                	{
                		sendLocationToOthers(action);
                	}
                    else
                    {
                  		sendLocationToOthers(LEAVE);
                  		break;
                    }

                }
            }

            sc.close();
        } catch(Exception e)
        {
            terminal("Probleem: "+e);
        }
        v.remove(this);
    }



    /***********************************
        DEBUGIMISEKS
    ***********************************/
    public void terminal(String text)
    {
    	System.out.println(text);
    }


}
