import java.awt.event.*;
import java.awt.*;

class SplashWindowFrame extends Frame {
    SplashWindow sw;
    Image splashIm;

    SplashWindowFrame()
    {
       super();

        /* Add the window listener */
/*        addWindowListener
        (
            new WindowAdapter()
            {
                public void windowClosing(WindowEvent evt)
                {
                    dispose();
                    System.exit(0);
                }
            }
        );
*/

       /* Center the frame */
       Dimension screenDim = 
            Toolkit.getDefaultToolkit().getScreenSize();
       Rectangle frameDim = getBounds();
       setLocation((screenDim.width - frameDim.width) / 2,
        (screenDim.height - frameDim.height) / 2);

       MediaTracker mt = new MediaTracker(this);
       splashIm = Toolkit.getDefaultToolkit(
           ).getImage("img/splash.gif");
       mt.addImage(splashIm,0);
       try {
          mt.waitForID(0);
       } catch(InterruptedException ie){}

       sw = new SplashWindow(this,splashIm);

       try {
      Thread.sleep(3000);
       } catch(InterruptedException ie){}

       sw.dispose();

      
       }
}

class SplashWindow extends Window {
    Image splashIm;

    SplashWindow(Frame parent, Image splashIm) {
        super(parent);
        this.splashIm = splashIm;
        setSize(300,200);

        /* Center the window */
        Dimension screenDim = 
             Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle winDim = getBounds();
        setLocation((screenDim.width - winDim.width) / 2,
        (screenDim.height - winDim.height) / 2);
        setVisible(true);
    }

    public void paint(Graphics g) {
       if (splashIm != null) {
           g.drawImage(splashIm,0,0,this);
       }
    }
}
