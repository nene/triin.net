

public class Player
{
    int id;
    int x;
    int y;
    int image;
    String name;

    public Player (int new_id, int new_image, String new_name)
    {
    	id = new_id;
    	image = new_image;
    	name = new_name;
    }
    
    public void setPosition (int X, int Y)
    {
    	x = X;
    	y = Y;
    }
    
}
