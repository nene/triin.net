import java.util.*;

public class Players
{
    int PLAYER_COUNT = 10;
    Player[] players = new Player[PLAYER_COUNT];


    public Players()
    {
    	//players.add(0, new Player(1,0,""));
    	//players.add(1, new Player(2,1,""));
    	for (int i=0; i<PLAYER_COUNT; i++)
    	{
            players[i] = null;
        }
        setPosition(0,0);
    }

    public int getCount()
    {
    	return PLAYER_COUNT;
    }

    public Player getPlayer(int id)
    {
    	return players[id];
    }

    public void setPosition(int x, int y)
    {
        for (int i=0; i<PLAYER_COUNT; i++)
        {
        	if (players[i]!=null)
        	{
                players[i].setPosition(x,y);
            }
        }
    }

    public void add(Player p)
    {
    	players[p.id] = p;
    }

    public void remove(int id)
    {
    	players[id] = null;
    }
}
