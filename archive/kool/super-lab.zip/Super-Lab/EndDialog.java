import java.awt.*;
import java.awt.event.*;

public class EndDialog extends Dialog implements ActionListener
{
    private Button exit = new Button("L�peta");
    private Label teade = new Label("", 1 );

    public EndDialog(Frame f)
    {
        super(f);

        setTitle("M�ng on l�bi!");
        setSize(300,250);
        
        /* Center the window */
        Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle winDim = getBounds();
        setLocation((screenDim.width - winDim.width) / 2,
        (screenDim.height - winDim.height) / 2);
        
        setModal(true); // valida saab ainult ConnectionDialog akent
        setLayout(new BorderLayout());
        add(teade, BorderLayout.CENTER);
        add(exit, BorderLayout.SOUTH);

        exit.addActionListener(this);
    }

    public void actionPerformed (ActionEvent e)
    {
        hide();
    }

    public String getMessageText(){ return teade.getText(); }

    public void setMessageText(String message_text){ teade.setText(message_text); }

}
