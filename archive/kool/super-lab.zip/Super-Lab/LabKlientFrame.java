import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class LabKlientFrame extends Frame implements ActionListener, WindowListener, KeyListener, Runnable, ItemListener
{
    // andmehulgad
    int[][] map = new int[50][50];
    Images pildid = new Images();
    Players players = new Players();
    Point startPos = new Point(0,0);
    Point finishPos = new Point(0,0);
    Player klientPlayer = null;
    int id=0;
    boolean gameStarted = false;
    String fileName = "map/001.map";

    // Sisend ja v�ljundvood
    DataOutputStream output = null;
    DataInputStream input = null;
    byte[] inputBuffer = new byte[4];

    // Kasutajaliidese objektid
    LabCanvas kaart = new LabCanvas(map, pildid);
    Button reload = new Button("Reload");
    Panel panel = new Panel();
    Button exit = new Button("V�lju");
    Button start = new Button("Start!");
    TextField sisestus = new TextField("");
    Choice kaardiMenyy = new Choice();
    ConnectionDialog dialog = new ConnectionDialog(this, pildid);



    // konstruktor
    public LabKlientFrame()
    {
        // kasutajaliidese elementide paigutamine
        setTitle("Super-Lab");
        setLayout(new BorderLayout());
        panel.setLayout(new GridLayout(0,4));
        add(kaart, BorderLayout.CENTER);
        add(panel, BorderLayout.SOUTH);
        panel.add(reload);
        panel.add(start);
        panel.add(kaardiMenyy);
        panel.add(exit);

        start.setEnabled(false);
        kaardiMenyy.setEnabled(false);

        kaardiMenyy.add("Kaart 1");
        kaardiMenyy.add("Kaart 2");
        kaardiMenyy.add("Kaart 3");
        kaardiMenyy.add("Kaart 4");

        // S�ndmuste kuularite m��ramine
        addWindowListener(this);
        reload.addActionListener(this);
        start.addActionListener(this);
        kaardiMenyy.addItemListener(this);
        exit.addActionListener(this);
        reload.addKeyListener(this);
        start.addKeyListener(this);
        exit.addKeyListener(this);
        kaart.addKeyListener(this);
    }

    // Ootab kasutajalt andmete sisestamist
    // ning proovib seej�rel serveriga �henduda
    public void waitState()
    {
        boolean connection = false;
        do
        {
            dialog.show();
            if (dialog.getConnect())
            {
                connection = connect(dialog.getServerAddress());
                if (connection)
                {
                    dialog.setMessageText("Server Connected!");
                }else{
                    dialog.setMessageText("Can't connect to the server!");
                }
            }else
            {
                System.exit(0);
            }
        }while (connection==false);
        sendMessage(4, 0, (dialog.getUserName()).length(), dialog.getImageIndex());
        sendTextMessage(dialog.getUserName());
    }

    // Serveriga �hendumine
    // kui k�ik �nnestub, siis tagastatakse true
    public boolean connect(String address)
    {
        try
        {
            Socket sc = new Socket(address, 3001);
            // K�sime sisend- ja v�ljundvoo
            output = new DataOutputStream(sc.getOutputStream());
            input = new DataInputStream(sc.getInputStream());
            // Lubame k�sureakasti
            sisestus.setEnabled(true);
            // Alustame uut l�ime
            new Thread(this).start();
            return true;
        }catch (Exception e)
        {
            return false;
        }
    }

    // Saadab k�sureale kirjutatud v��rtused baitidena serverile
    public void interpretCommandLine()
    {
        try
        {
            String msg = sisestus.getText();
            if (msg.length()>0)
            {
                String word;
                int i=0;
                StringTokenizer st = new StringTokenizer(msg);
                while (st.hasMoreTokens() && i<4) {
                    word = st.nextToken();
                    if (word.length()>0)
                    {
                        output.write(Integer.parseInt(word));
                    }
                    i++;
                }
                while (i<4)
                {
                    output.write(0);
                    i++;
                }
                sisestus.setText("");
            }
        }catch (Exception e)
        {
            System.out.println("Error: "+e);
        }
    }


    // reageerimine nupuvajutustele ning k�sureale
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==reload)
        {
            loadFile(fileName);
        }
        if (e.getSource()==sisestus)
        {
            interpretCommandLine();
        }
        if (e.getSource()==exit)
        {
            sendMessage(5,0,0,0);
        }
        if (e.getSource()==start)
        {
            sendMessage(2,0,startPos.x,startPos.y);
        }
    }

    public void itemStateChanged(ItemEvent e)
    {
        sendMessage(6,0,kaardiMenyy.getSelectedIndex(),0);
    }


    // loeb neli baiti sisendvoost ja kirjutab massiivi
    public void read4Bytes() throws IOException
    {
        inputBuffer[0]=input.readByte();
        inputBuffer[1]=input.readByte();
        inputBuffer[2]=input.readByte();
        inputBuffer[3]=input.readByte();
        //System.out.println("Sisend: "+inputBuffer[0]+":"+inputBuffer[1]+":"+inputBuffer[2]+":"+inputBuffer[3]);
    }

    public void threadLoop() throws IOException
    {
        boolean veel=true;
        while(veel==true)
        {
            read4Bytes();

            if (inputBuffer[0]==0)
            {
                movePlayer(players.getPlayer(inputBuffer[1]), inputBuffer[2], inputBuffer[3]);
            }

            if (inputBuffer[0]==1)
            {
                gameStarted = false;
                setTitle("Super-Lab");
            	EndDialog d = new EndDialog(this);
            	if (inputBuffer[1]==id)
            	{
                    d.setMessageText("Oled v�itnud!");
                }else
                {
                	d.setMessageText("Kahjuks kaotasid. M�ngu v�itis "+(players.getPlayer(inputBuffer[1])).name);
                }
                d.show();
            }

            // START!
            if (inputBuffer[0]==2)
            {
                players.setPosition(inputBuffer[2], inputBuffer[3]);
                kaart.redrawBuffer(0,0,49,49);
                kaart.repaint();
                drawAllPlayers();
                setTitle("Super-Lab: START! START! START!");
                gameStarted = true;
            }

            if (inputBuffer[0]==4)
            {
                String name = "";
                for (int i=0;i<inputBuffer[2];i++)
                {
                    name += input.readChar();
                }
                players.add(new Player(inputBuffer[1],inputBuffer[3],name));
                drawAllPlayers();
            }

            if (inputBuffer[0]==5)
            {
                if (inputBuffer[1]==id)
                {
                    sisestus.setEnabled(false);
                    veel=false;
                    // TODO
                    System.exit(0);
                }else
                {
                    Player p = players.getPlayer(inputBuffer[1]);
                    kaart.restorePosition(p.x, p.y);
                    players.remove(inputBuffer[1]);
                }
            }

            if (inputBuffer[0]==6)
            {
                fileName = "map/00"+(inputBuffer[2]+1)+".map";
                loadFile(fileName);
                kaardiMenyy.select(inputBuffer[2]);
            }

        }
    }       

    // L�im
    public void run()
    {
        try
        {
            read4Bytes();
            if (inputBuffer[0]==7 && inputBuffer[2]==1)
            {
                id=inputBuffer[1];
                klientPlayer = new Player(id,dialog.getImageIndex(),dialog.getUserName());
                players.add(klientPlayer);

                // juhul kui kasutaja saab adminni �igused
                if (inputBuffer[3]==1)
                {
                    start.setEnabled(true);
                    kaardiMenyy.setEnabled(true);
                }

                // ts�kkel kuni lahkumisteate saamiseni
                threadLoop();
            }else
            {
                dialog.setMessageText("Server responded: Can not connect at this time. (Server might be full.)");
                
            }
        } catch (Exception e)
        {
            System.out.println("Error: "+e);
        }
    }


    public void drawAllPlayers()
    {
        for (int i=0; i<players.getCount(); i++)
        {
            if (players.getPlayer(i)!=null)
            {
                kaart.drawPlayer(players.getPlayer(i));
            }
        }
    }

    public void movePlayer(Player p, int new_x, int new_y)
    {
        kaart.restorePosition(p.x, p.y);
        p.setPosition(new_x, new_y);
        //kaart.drawPlayer(p);
        drawAllPlayers();
    }

    public void sendMessage(int a, int b, int c, int d)
    {
        try
        {
            output.write(a);
            output.write(b);
            output.write(c);
            output.write(d);
            //System.out.println("Sending: "+a+"."+b+"."+c+"."+d);
        } catch (Exception e)
        {
            System.out.println("Error on sending message to server: "+e);
        }
    }

    public void sendTextMessage(String text)
    {
        try
        {
            output.writeChars(text);
            //System.out.println("Sending: "+text);
        } catch (Exception e)
        {
            System.out.println("Error on sending message to server: "+e);
        }
    }
    
    
    public void sendPlayerMoveMessage(Player p)
    {
        sendMessage(0,0,p.x,p.y);
    }

    public void keyReleased(KeyEvent e)
    {
        Player p = players.getPlayer(id);

        int new_x = p.x;
        int new_y = p.y;

        switch (e.getKeyCode())
        {
            case KeyEvent.VK_UP:
                new_y = p.y-1;
                break;
            case KeyEvent.VK_LEFT:
                new_x = p.x-1;
                break;
            case KeyEvent.VK_RIGHT:
                new_x = p.x+1;
                break;
            case KeyEvent.VK_DOWN:
                new_y = p.y+1;
                break;
        }

        if (map[new_x][new_y]<128)
        {
            movePlayer(p, new_x, new_y);
            sendPlayerMoveMessage(p);
        }
        // kui on fini�
        if (map[new_x][new_y]==1 && gameStarted)
        {
        	sendMessage(1,0,0,0);
        }
    }

    public void loadFile(String fileName)
    {
        try
        {
            FileInputStream sisse = new FileInputStream( new File(fileName));
            for (int x=0; x<50; x++)
            {
                for (int y=0; y<50; y++)
                {
                    map[x][y]=sisse.read();
                    if (map[x][y]==pildid.START)
                    {
                        startPos.x = x;
                        startPos.y = y;
                    }else{
                        if (map[x][y]==pildid.FINISH)
                        {
                            finishPos.x = x;
                            finishPos.y = y;
                        }
                    }
                }
            }
            sisse.close();
            kaart.redrawBuffer(0,0,49,49);
            kaart.repaint();
            klientPlayer.setPosition(startPos.x, startPos.y);
            sendMessage(0,0,startPos.x,startPos.y);
            drawAllPlayers();
        } catch (Exception e)
        {
            System.out.println("Viga: "+e);
        }
    }

    
    public void windowOpened(WindowEvent e)
    {
        waitState();
    }
    
    
    public void windowClosing(WindowEvent e)
    {
        sendMessage(5,0,0,0);
    }

    
    // implementeerimata
    public void keyPressed(KeyEvent e){}
    public void keyTyped(KeyEvent e){}
    public void windowActivated(WindowEvent e){}
    public void windowClosed(WindowEvent e){}
    public void windowDeactivated(WindowEvent e){}
    public void windowDeiconified(WindowEvent e){}
    public void windowIconified(WindowEvent e){}
}
