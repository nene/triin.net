import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import java.io.*;
import java.util.*;

public class Klient extends Applet implements ActionListener, Runnable
{
    TextArea ta = new TextArea("");
    TextField sisestus = new TextField("");
    Button btn = new Button("�henda");
    DataOutputStream valja;
    DataInputStream sisse;
    boolean veel=false;
    int id = 0;

    public Klient()
    {
        setLayout(new BorderLayout());
        add(sisestus, BorderLayout.SOUTH);
        add(btn, BorderLayout.NORTH);
        add(ta, BorderLayout.CENTER);
        btn.addActionListener(this);
        sisestus.addActionListener(this);
        sisestus.setEnabled(false);
        ta.setEnabled(false);
    }

    public void actionPerformed(ActionEvent e)
    {
        try
        {
            if (e.getSource()==btn)
            {
                Socket sc = new Socket("193.40.81.23", 3001);
                valja = new DataOutputStream(sc.getOutputStream());
                sisse = new DataInputStream( sc.getInputStream());
                sisestus.setEnabled(true);
                btn.setEnabled(false);
                ta.setEnabled(true);
                veel=true;
                new Thread(this).start();
            }
            if (e.getSource()==sisestus)
            {
                String msg = sisestus.getText();
                if (msg.length()>0)
                {
                    String word;
                    int i=0;
                    StringTokenizer st = new StringTokenizer(msg);
                    while (st.hasMoreTokens() && i<4) {
                        word = st.nextToken();
                        if (word.length()>0)
                        {
                            valja.write(Integer.parseInt(word));
                        }
                        i++;
                    }
                    while (i<4)
                    {
                        valja.write(0);
                        i++;
                    }
                    sisestus.setText("");
                }
            }
        } catch (Exception x)
        {
            System.out.println("Error: "+x);
        }
    }

    public void run()
    {
        try
        {
            byte[] data = new byte[4];
            while(veel==true)
            {
                data[0]=sisse.readByte();
                data[1]=sisse.readByte();
                data[2]=sisse.readByte();
                data[3]=sisse.readByte();
                
                if (data[0]==7)
                {
                    id=data[1];
                }
                
                if (data[0]!=5 || data[1]!=id)
                {
                    ta.append(""+data[0]+":"+data[1]+":"+data[2]+":"+data[3]+"\n");
                }else
                {
                    veel=false;
                    btn.setEnabled(true);
                    sisestus.setEnabled(false);
                    ta.setEnabled(false);
                }
                
            }
        } catch (Exception x)
        {
            System.out.println("Error: "+x);
        }
    }

    public static void main(String[] argumendid)
    {
        Frame f=new Frame();
        f.setSize(300,300);

        f.add(new Klient());
        f.setVisible(true);
        f.addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
    }
}



