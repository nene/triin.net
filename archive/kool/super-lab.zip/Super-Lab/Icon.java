import java.awt.*;

public class Icon extends Canvas
{
    private Images pildid;
    private int imageIndex=0;

    public Icon(Images pildiViit)
    {
    	pildid = pildiViit;
    	repaint();
    }

    public void setImageIndex(int index)
    {
    	imageIndex = index;
    	repaint();
    }

    public int getImageIndex(int index)
    {
    	return imageIndex;
    }

    public void paint(Graphics g)
    {
        g.drawImage(pildid.getPlayerImage(imageIndex), 4, 4, null);
    }

}
