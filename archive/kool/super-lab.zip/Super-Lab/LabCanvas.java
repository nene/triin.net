import java.awt.*;


public class LabCanvas extends Canvas
{
    int[][] map;
    Images pildid;
    Image buffer;

    public LabCanvas(int[][] kaart, Images pildiviit)
    {
    	map = kaart;
    	pildid = pildiviit;
    }

    public void addNotify()
    {
        super.addNotify();
        buffer = createImage(600, 600);
        redrawBuffer(0,0,49,49);
    }

    public void redrawBuffer(int x1, int y1, int x2, int y2)
    {
        Graphics memoryG = buffer.getGraphics();
        for (int x=x1; x<=x2; x++)
        {
            for (int y=y1; y<=y2; y++)
            {
                memoryG.drawImage(pildid.getImage(map[x][y]), x*12, y*12, null);
            }
        }
    }

    public void restorePosition(int x, int y)
    {
    	Graphics b = buffer.getGraphics();
    	Graphics g = getGraphics();
    	b.drawImage(pildid.getImage(map[x][y]), x*12, y*12, null);
    	g.drawImage(pildid.getImage(map[x][y]), x*12, y*12, null);
    }

    public void drawPlayer(Player p)
    {
    	Graphics b = buffer.getGraphics();
    	Graphics g = getGraphics();
    	b.drawImage(pildid.getPlayerImage(p.image), p.x*12, p.y*12, null);
    	g.drawImage(pildid.getPlayerImage(p.image), p.x*12, p.y*12, null);
    }


    public void paint(Graphics g)
    {
        g.drawImage(buffer, 0, 0, null);
    }
}


