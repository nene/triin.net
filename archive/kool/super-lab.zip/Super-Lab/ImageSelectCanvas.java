import java.awt.*;
import java.awt.event.*;



public class ImageSelectCanvas extends Canvas implements MouseListener
{
    private Images pildid;
    private int active=0;

    public ImageSelectCanvas(Images pildiviit)
    {
    	pildid = pildiviit;
    }

    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}

    public void mouseClicked(MouseEvent e)
    {
    	int x = (int)(e.getX()-2)/14;
        if (x<(4+pildid.getWallSetCount()+pildid.getFloorSetCount()))
        {
        	active=x;
        }
        repaint();
    }

    public int getActive()
    {
    	if (active<3+pildid.getFloorSetCount())
    	{
    	    if (active<3)
    	    {
                return active;
            }else
            {
            	return (active-3)*16+3;
            }
    	}else
        {
        	if (active==3+pildid.getFloorSetCount())
        	{
        		return 128;
        	}else
            {
                return 128+(active-pildid.getFloorSetCount()-4)*16+1;
            }
        }
    }

    public void paint(Graphics g)
    {
        g.drawImage(pildid.getImage(0), 0*14+2, 2, null);
        g.drawImage(pildid.getImage(1), 1*14+2, 2, null);
        g.drawImage(pildid.getImage(2), 2*14+2, 2, null);
        for (int i=0; i<pildid.getFloorSetCount(); i++)
        {
        	g.drawImage(pildid.getFloorSetImage(i,0), (i+3)*14+2, 2, null);
        }
        g.drawImage(pildid.getImage(128), (pildid.getFloorSetCount()+3)*14+2, 2, null);
        for (int i=0; i<pildid.getWallSetCount(); i++)
        {
        	g.drawImage(pildid.getWallSetImage(i,0), (i+pildid.getFloorSetCount()+4)*14+2, 2, null);
        }
        g.setColor(Color.red);
        g.drawRect(active*14+1, 1, 13, 13);
    }
}


