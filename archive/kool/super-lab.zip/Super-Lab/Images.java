import java.awt.*;

public class Images
{
    private int WALL_SET_COUNT=3;
    private int WALL_COUNT=1 + WALL_SET_COUNT*16;
    private Image[] walls = new Image[WALL_COUNT];
    private int FLOOR_SET_COUNT=2;
    private int FLOOR_COUNT= 3 + FLOOR_SET_COUNT*16;
    private Image[] floors = new Image[FLOOR_COUNT];
    private int PLAYER_COUNT=4;
    private Image[] players = new Image[PLAYER_COUNT];
    public int FINISH=1;
    public int START=2;

    public Images()
    {
    	Toolkit toolkit = Toolkit.getDefaultToolkit();
        floors[0] = toolkit.getImage("img/tile.gif");
        floors[1] = toolkit.getImage("img/start.gif");
        floors[2] = toolkit.getImage("img/finish.gif");
        walls[0] = toolkit.getImage("img/ruudud.gif");

        loadWallSet("img/toru/", 0);
        loadWallSet("img/toru2/", 1);
        loadWallSet("img/geitoru/", 2);
        loadFloorSet("img/geitaust/", 0);
        loadFloorSet("img/toru2/", 1);

        players[0] = toolkit.getImage("img/tegelane4.gif");
        players[1] = toolkit.getImage("img/tegelane3.gif");
        players[2] = toolkit.getImage("img/tegelane2.gif");
        players[3] = toolkit.getImage("img/tegelane1.gif");
    }

    public void loadWallSet(String path, int setIndex)
    {
    	int start = 1+setIndex*16;
    	Toolkit toolkit = Toolkit.getDefaultToolkit();
        walls[start+0] = toolkit.getImage(path+"0000.gif");
        walls[start+1] = toolkit.getImage(path+"0001.gif");
        walls[start+2] = toolkit.getImage(path+"0010.gif");
        walls[start+3] = toolkit.getImage(path+"0011.gif");
        walls[start+4] = toolkit.getImage(path+"0100.gif");
        walls[start+5] = toolkit.getImage(path+"0101.gif");
        walls[start+6] = toolkit.getImage(path+"0110.gif");
        walls[start+7] = toolkit.getImage(path+"0111.gif");
        walls[start+8] = toolkit.getImage(path+"1000.gif");
        walls[start+9] = toolkit.getImage(path+"1001.gif");
        walls[start+10] = toolkit.getImage(path+"1010.gif");
        walls[start+11] = toolkit.getImage(path+"1011.gif");
        walls[start+12] = toolkit.getImage(path+"1100.gif");
        walls[start+13] = toolkit.getImage(path+"1101.gif");
        walls[start+14] = toolkit.getImage(path+"1110.gif");
        walls[start+15] = toolkit.getImage(path+"1111.gif");
    }

    public void loadFloorSet(String path, int setIndex)
    {
    	int start = 3+setIndex*16;
    	Toolkit toolkit = Toolkit.getDefaultToolkit();
        floors[start+0] = toolkit.getImage(path+"0000.gif");
        floors[start+1] = toolkit.getImage(path+"0001.gif");
        floors[start+2] = toolkit.getImage(path+"0010.gif");
        floors[start+3] = toolkit.getImage(path+"0011.gif");
        floors[start+4] = toolkit.getImage(path+"0100.gif");
        floors[start+5] = toolkit.getImage(path+"0101.gif");
        floors[start+6] = toolkit.getImage(path+"0110.gif");
        floors[start+7] = toolkit.getImage(path+"0111.gif");
        floors[start+8] = toolkit.getImage(path+"1000.gif");
        floors[start+9] = toolkit.getImage(path+"1001.gif");
        floors[start+10] = toolkit.getImage(path+"1010.gif");
        floors[start+11] = toolkit.getImage(path+"1011.gif");
        floors[start+12] = toolkit.getImage(path+"1100.gif");
        floors[start+13] = toolkit.getImage(path+"1101.gif");
        floors[start+14] = toolkit.getImage(path+"1110.gif");
        floors[start+15] = toolkit.getImage(path+"1111.gif");
    }

    public int getCount()
    {
    	return WALL_COUNT + FLOOR_COUNT;
    }

    public int getFloorCount()
    {
    	return FLOOR_COUNT;
    }

    public int getWallCount()
    {
    	return WALL_COUNT;
    }

    public int getFloorSetCount()
    {
    	return FLOOR_SET_COUNT;
    }

    public int getWallSetCount()
    {
    	return WALL_SET_COUNT;
    }

    public Image getStartImage()
    {
    	return floors[START];
    }

    public Image getFinishImage()
    {
    	return floors[FINISH];
    }

    public Image getFloorSetImage(int set, int index)
    {
    	return floors[3+set*16+index];
    }

    public Image getWallSetImage(int set, int index)
    {
    	return walls[1+set*16+index];
    }


    public Image getImage(int index)
    {
    	if (index<128)
    	{
    		return floors[index];
    	}else
        {
        	return walls[index-128];
    	}
    }

    public Image getPlayerImage(int index)
    {
    	return players[index];
    }
    
    public int getPlayerImageCount()
    {
    	return PLAYER_COUNT;
    }

}
