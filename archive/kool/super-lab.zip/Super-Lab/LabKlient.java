import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

class LabKlient extends Applet
{
    public static void main(String argumendid[])
    {
        new SplashWindowFrame();
    	LabKlientFrame f=new LabKlientFrame();
    	
        f.setSize(608,650);
        /* Center the window */
        Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle winDim = f.getBounds();
        f.setLocation((screenDim.width - winDim.width) / 2,
        (screenDim.height - winDim.height) / 2);
    	f.setVisible(true);
    }
}
