import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class EditorFrame extends Frame implements ActionListener, MouseListener
{
    int[][] map = new int[50][50];
    Images pildid = new Images();
    LabCanvas kaart = new LabCanvas(map, pildid);
    ImageSelectCanvas imageSelect = new ImageSelectCanvas(pildid);
    Button replaceF = new Button("Replace floor");
    Button replaceW = new Button("Replace wall");
    Button reset = new Button("Repaint");
    Button save = new Button("Save");
    Button open = new Button("Load");
    Panel panel = new Panel();
    Panel panel2 = new Panel();
    FileDialog openDialog = new FileDialog(this, "Open");
    FileDialog saveDialog = new FileDialog(this, "Save");

    int mouseStartX=-1;
    int mouseStartY=-1;


    public EditorFrame()
    {
    	panel.setLayout(new GridLayout(2,0));
    	panel2.setLayout(new GridLayout(0,5));
    	panel.add(panel2);
    	panel.add(imageSelect);
        setLayout(new BorderLayout());
    	add(kaart, BorderLayout.CENTER);
    	panel2.add(open);
    	panel2.add(save);
    	panel2.add(reset);
    	panel2.add(replaceF);
    	panel2.add(replaceW);

        add(panel, BorderLayout.SOUTH);
        saveDialog.setMode(FileDialog.SAVE);

        save.addActionListener(this);
        open.addActionListener(this);
        replaceF.addActionListener(this);
        replaceW.addActionListener(this);
    	reset.addActionListener(this);
    	kaart.addMouseListener(this);
        imageSelect.addMouseListener(imageSelect);
    	initMap();

    }

    void initMap()
    {
    	// nothing at the moment
    }

    public void actionPerformed(ActionEvent e)
    {
    	if (e.getSource()==replaceW)
    	{
    		int z=0;
    		int f=imageSelect.getActive();
    		if (f>128)
    		{
            for (int y=0; y<50; y++)
            {
            	for (int x=0; x<50; x++)
            	{
                    if (map[x][y]>=128)
                    {
                    	z=0;
                        if (y>0)
                        {
                            if (map[x][y-1]>=128) z++;
                        }
                        z=z*2;
                        if (x<49)
                        {
                            if (map[x+1][y]>=128) z++;
                        }
                        z=z*2;
                        if (y<49)
                        {
                            if (map[x][y+1]>=128) z++;
                        }
                        z=z*2;
                        if (x>0)
                        {
                            if (map[x-1][y]>=128) z++;
                        }

                        map[x][y]=z+f;
                    }
                }
            }
            }
            kaart.redrawBuffer(0,0,49,49);
            kaart.repaint();
            imageSelect.repaint();
        }
    	if (e.getSource()==replaceF)
    	{
    		int z=0;
    		int f=imageSelect.getActive();
    		if (f<128 && f>2)
    		{
            for (int y=0; y<50; y++)
            {
            	for (int x=0; x<50; x++)
            	{
                    if (map[x][y]<128)
                    {
                    	z=0;
                        if (y>0)
                        {
                            if (map[x][y-1]<128) z++;
                        }
                        z=z*2;
                        if (x<49)
                        {
                            if (map[x+1][y]<128) z++;
                        }
                        z=z*2;
                        if (y<49)
                        {
                            if (map[x][y+1]<128) z++;
                        }
                        z=z*2;
                        if (x>0)
                        {
                            if (map[x-1][y]<128) z++;
                        }

                        map[x][y]=z+f;
                    }
                }
            }
            }
            kaart.redrawBuffer(0,0,49,49);
            kaart.repaint();
            imageSelect.repaint();
        }
    	if (e.getSource()==reset)
    	{
            kaart.redrawBuffer(0,0,49,49);
            kaart.repaint();
            imageSelect.repaint();
        }
        if (e.getSource()==open)
        {
        	openDialog.show();
        	if (openDialog.getFile()!=null)
        	{
                openFile(openDialog.getDirectory()+openDialog.getFile());
            }
        }
        if (e.getSource()==save)
        {
        	saveDialog.show();
        	if (saveDialog.getFile()!=null)
        	{
                saveFile(saveDialog.getDirectory()+saveDialog.getFile());
            }
        }
    }

    public void openFile(String fileName)
    {
        try
        {
            FileInputStream sisse = new FileInputStream( new File(fileName));
            for (int x=0; x<50; x++)
            {
                for (int y=0; y<50; y++)
                {
                    map[x][y]=sisse.read();
                }
            }
            sisse.close();
            kaart.redrawBuffer(0,0,49,49);
            kaart.repaint();
        } catch (Exception e)
        {
            System.out.println("Viga: "+e);
        }
    }

    public void saveFile(String fileName)
    {
        try
        {
            FileOutputStream valja = new FileOutputStream( new File(fileName));
            for (int x=0; x<50; x++)
            {
                for (int y=0; y<50; y++)
                {
                    valja.write(map[x][y]);
                }
            }
            valja.close();
        } catch (Exception e)
        {
            System.out.println("Viga: "+e);
        }
    }

    public void mousePressed(MouseEvent e)
    {
        int x = (int)(e.getX()/12);
        int y = (int)(e.getY()/12);
        if (x<50 && y<50)
        {
            mouseStartX = (int)(e.getX()/12);
            mouseStartY = (int)(e.getY()/12);
        }
    }

    public void mouseReleased(MouseEvent e)
    {
        if (e.getSource()==kaart)
        {
            int stopX = (int)(e.getX()/12);
            int stopY = (int)(e.getY()/12);
            if (stopX<50 && stopY<50 && mouseStartX !=-1)
            {
                if (mouseStartX > stopX)
                {
                    int tmp = mouseStartX;
                    mouseStartX=stopX;
                    stopX=tmp;
                }
                if (mouseStartY > stopY)
                {
                    int tmp = mouseStartY;
                    mouseStartY=stopY;
                    stopY=tmp;
                }

                for (int x=mouseStartX; x<=stopX; x++)
                {
                    for (int y=mouseStartY; y<=stopY; y++)
                    {
                        map[x][y] = imageSelect.getActive();
                    }
                }
                kaart.redrawBuffer(mouseStartX,mouseStartY,stopX,stopY);
                kaart.repaint();
            }
            mouseStartX=-1;
            mouseStartY=-1;
        }
    }
    public void mouseExited(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseClicked(MouseEvent e){}

}
