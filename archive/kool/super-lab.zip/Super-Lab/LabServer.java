import java.io.*;
import java.net.*;
import java.util.*;

public class LabServer
{
    public static void main(String argumendid[]) throws IOException
    {
        ServerSocket ss=new ServerSocket(3001);
        Vector uhendused=new Vector();
        while(true)
        {
            Socket sc=ss.accept();
            uhendused.add(new LabThread(sc, uhendused));
        }
    }

}

class LabThread extends Thread
{
    Vector v;
    Socket sc;
    int id;
    int image;
    String name = "";
    boolean admin = false;
    int x, y;
    DataInputStream sisend;
    DataOutputStream valjund;
    byte[] inputBuffer = new byte[4];
    byte[] outputBuffer = new byte[4];

    public LabThread(Socket uus_sc, Vector uus_v)
    {
        v=uus_v;
        sc=uus_sc;
        start();
    }

    // Genereerib l�imele uue ID 
    public boolean generateId()
    {
        int[] id_array = new int[v.size()];
        int i;
        // loeme k�ik ID-d massiivi
        for (i=0; i<v.size(); i++)
        {
            id_array[i] = ((LabThread)v.elementAt(i)).id;
        }
        // sorteerime
        Arrays.sort(id_array);
        // otsime v�ikseima vaba ID v��rtuse
        for (i=0; i<v.size(); i++)
        {
            if (id_array[i]>i)
            {
                id = i;
                break;
            }
        }
        if (i==v.size())
        {
            id=i;
        }

        // kontrollime, et id oleks lubatud pirides
        if (id < 256)
        {
            return true;
        }else
        {
            return false;
        }
    }

    public boolean checkAdminExistance()
    {
        for (int i=0; i<v.size(); i++)
        {
            if ( ((LabThread)v.elementAt(i)).admin)
            {
                return true;
            }
        }
        return false;
    }

    // loeb neli baiti sisendvoost ja kirjutab massiivi
    public void read4Bytes() throws IOException
    {
        inputBuffer[0]=sisend.readByte();
        inputBuffer[1]=sisend.readByte();
        inputBuffer[2]=sisend.readByte();
        inputBuffer[3]=sisend.readByte();
    }

    public void output4Bytes(int a, int b, int c, int d) throws IOException
    {
        outputBuffer[0]=(byte)a;
        outputBuffer[1]=(byte)b;
        outputBuffer[2]=(byte)c;
        outputBuffer[3]=(byte)d;
        output4Bytes();
    }

    public void output4Bytes() throws IOException
    {
        valjund.write(outputBuffer, 0, 4);
    }

    public boolean authenticate() throws IOException
    {
        terminalOutput("New user connecting...");
        read4Bytes();
        if (inputBuffer[0]==4)
        {
            for (int i=0;i<inputBuffer[2];i++)
            {
                name += sisend.readChar();
            }
            if (generateId())
            {
                image = inputBuffer[3];
                // kui admin-i ei eksisteeri
                // siis m��rame kasutaja adminniks,
                // muidu saadame hariliku teate
                if (checkAdminExistance())
                {
                    output4Bytes(7,id,1,0);
                }else
                {
                    admin = true;
                    output4Bytes(7,id,1,1);
                }
                terminalOutput("New user "+name+" accepted!");
                messageToOthers(4,id,name.length(),inputBuffer[3]);
                messageToOthers(name);
                return true;
            }else
            {
                output4Bytes(7,0,0,0);
                return false;
            }
        }else
        {
            output4Bytes(7,0,0,0);
            return false;
        }
    }

    public void messageToOthers() throws IOException
    {
        terminalOutput("From "+name+" to others: ", outputBuffer);
        LabThread th = null;
        for(int i=0;i<v.size();i++)
        {
            th = (LabThread)v.elementAt(i);
            if (th!=this)
            {
                th.valjund.write(outputBuffer, 0, 4);
            }
        }
    }

    public void messageToOthers(byte[] msg) throws IOException
    {
        outputBuffer[0] = msg[0];
        outputBuffer[1] = msg[1];
        outputBuffer[2] = msg[2];
        outputBuffer[3] = msg[3];
        messageToOthers();
    }

    public void messageToOthers(int a, int b, int c, int d) throws IOException
    {
        outputBuffer[0]=(byte)a;
        outputBuffer[1]=(byte)b;
        outputBuffer[2]=(byte)c;
        outputBuffer[3]=(byte)d;
        messageToOthers();
    }
    
    public void messageToOthers(String text) throws IOException
    {
        terminalOutput("From "+name+" to others: "+text);
        LabThread th = null;
        for(int i=0;i<v.size();i++)
        {
            th = (LabThread)v.elementAt(i);
            if (th!=this)
            {
                th.valjund.writeChars(text);
            }
        }
    }
    
    public void sendOtherUsersInfo() throws IOException
    {
        LabThread th = null;
        for(int i=0;i<v.size();i++)
        {
            th = (LabThread)v.elementAt(i);
            if (th!=this)
            {
            	// saadame id, nimepikkuse ja pildinumbri
                output4Bytes(4,th.id,th.name.length(),th.image);
                // saadame nime
                valjund.writeChars(th.name);
                // saadame asukoha
                output4Bytes(0,th.id,th.x,th.y);
                terminalOutput("Sending other users info to "+name+": "+th.name+", ", outputBuffer);
            }
        }
    }

    public void run(){
        try
        {
            sisend=new DataInputStream(sc.getInputStream());
            valjund=new DataOutputStream(sc.getOutputStream());
            boolean veel=true;

            if (authenticate())
            {
                sendOtherUsersInfo();
                while(true)
                {
                    read4Bytes();
                    terminalOutput(name+": ", inputBuffer);

                    if (inputBuffer[0]!=5)
                    {
                        if (inputBuffer[0]==0)
                        {
                            x = inputBuffer[2];
                            y = inputBuffer[3];
                            messageToOthers(0,id,x,y);
                        }else
                        {
                            if (inputBuffer[0]==2)
                            {
                                messageToOthers(inputBuffer);
                                output4Bytes(2,inputBuffer[1],inputBuffer[2],inputBuffer[3]);
                            }else
                            {
                                if (inputBuffer[0]==1)
                                {
                                	messageToOthers(1,id,0,0);
                                	output4Bytes(1,id,0,0);
                                }else
                                {
                                    if (inputBuffer[0]==6)
                                    {
                                        messageToOthers(inputBuffer);
                                    	output4Bytes(6,0,inputBuffer[2],0);
                                    }else
                                    {
                                        messageToOthers(inputBuffer);
                                    }
                                }
                            }
                        }
                    }else
                    {
                        messageToOthers(5,id,0,0);
                        terminalOutput("User "+name+" disconnected.");
                        break;
                    }
                }
            }
            output4Bytes(5,id,0,0);
            sc.close();
        } catch(Exception e)
        {
            System.out.println("Probleem: "+e);
        }
        v.remove(this);
    }



    /***********************************
        DEBUGIMISEKS
    ***********************************/
    public void terminalOutput(byte[] buffer)
    {
/*        System.out.println(""+(buffer[0]&0xff)+":"+
                              (buffer[1]&0xff)+":"+
                              (buffer[2]&0xff)+":"+
                              (buffer[3]&0xff));*/
    }

    public void terminalOutput(String text, byte[] buffer)
    {
/*    	System.out.print(text);
        terminalOutput(buffer);*/
    }

    public void terminalOutput(String text)
    {
    	System.out.println(text);
    }


}
