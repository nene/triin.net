import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

class LabEdit extends Applet
{
    public static void main(String argumendid[])
    {
    	EditorFrame f=new EditorFrame();
    	f.setSize(650,700);
    	f.setVisible(true);
    	f.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){System.exit(0);}});
    }
}
