import java.awt.*;
import java.awt.event.*;

public class ConnectionDialog extends Dialog implements ActionListener, ItemListener
{
    private Button connect = new Button("�henda!");
    private Button exit = new Button("V�lju");
    private TextField nimi = new TextField("", 20);
    private TextField serveriaadress = new TextField("193.40.81.23", 20);
    private Label teade = new Label("Tere!", 1 );
    private Icon playerIcon = null;

    Choice pildimenyy = new Choice();
    Panel paneel = new Panel();
    Panel paneel_nimerida = new Panel();
    Panel paneel_serveririda = new Panel();
    Panel paneel_pildirida = new Panel();
    Panel paneel_teaterida = new Panel();
    private boolean exitStatus = false;

    public ConnectionDialog(Frame f, Images pildid)
    {
        super(f);
        int i;

        playerIcon = new Icon(pildid);

        setTitle("Serveriga �hendumine");

        setSize(300,250);
        /* Center the window */
        Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle winDim = getBounds();
        setLocation((screenDim.width - winDim.width) / 2,
        (screenDim.height - winDim.height) / 2);



        setModal(true); // valida saab ainult ConnectionDialog akent
        paneel.setLayout(new GridLayout(9,1));
        add(paneel, BorderLayout.NORTH);

        // tyhi rida
        paneel.add(new Label(" "));

        // serveriaadressi sisestus
        paneel_serveririda.setLayout(new GridLayout(1,2));
        paneel_serveririda.add(new Label("Serveri aadress: ", 2 ));
        paneel_serveririda.add(serveriaadress);
        paneel.add(paneel_serveririda);


        // nime sisestus
        paneel_nimerida.setLayout(new GridLayout(1,2));
        paneel_nimerida.add(new Label("Nimi: ", 2 ));
        paneel_nimerida.add(nimi);
        paneel.add(paneel_nimerida);

        // pildi valimine
        for (i=0;i<pildid.getPlayerImageCount();i++ )
        {
            pildimenyy.add("Mehike "+(i+1) ) ;
        }
        paneel_pildirida.setLayout(new GridLayout(1,3));
        paneel_pildirida.add(new Label("Pildid: ", 2 ));
        paneel_pildirida.add(pildimenyy);
        paneel_pildirida.add(playerIcon);
        paneel.add(paneel_pildirida);

        // tyhi rida
        paneel.add(new Label(" "));

        // Mingisuge teade
        paneel_teaterida.setLayout(new GridLayout(1,2));
        paneel_teaterida.add(teade);
        paneel.add(paneel_teaterida);

        // tyhi rida
        paneel.add(new Label(" "));

        // ja nupud
        paneel.add(connect);
        paneel.add(exit);

        connect.addActionListener(this);
        exit.addActionListener(this);
        pildimenyy.addItemListener(this);
    }

    public void actionPerformed (ActionEvent e)
    {
        if (e.getSource()==connect)
        {
            exitStatus = true;
        }else{
            exitStatus = false;
        }
        hide();
    }
    
    public void itemStateChanged(ItemEvent e)
    {
    	playerIcon.setImageIndex(pildimenyy.getSelectedIndex());
    }

    // tagastab true, siis kui vajutati connect-nuppu
    // false, siis kui vajutati exit v�i sulgeti lihtsalt aken.
    public boolean getConnect(){ return exitStatus; }
    
    public String getServerAddress(){ return serveriaadress.getText(); }
    public String getUserName(){ return nimi.getText(); }
    public int getImageIndex(){ return pildimenyy.getSelectedIndex(); }
    public String getMessageText(){ return teade.getText(); }

    public void setServerAddress(String server_address){serveriaadress.setText(server_address);}
    public void setUserName(String user_name){nimi.setText(user_name); }
    public void setImageIndex(int image_index){pildimenyy.select(image_index); }
    public void setMessageText(String message_text){ teade.setText(message_text); }

}
