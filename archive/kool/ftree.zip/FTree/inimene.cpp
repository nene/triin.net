#include "inimene.h"

Inimene::Inimene(void)
{
    sugu=MEES;
    eesnimi="";
    perekonnanimi="";
    synniaasta=0;
    ema=NULL;
    isa=NULL;
}

Inimene::Inimene(int sex)
{
    sugu=sex;
    eesnimi="";
    perekonnanimi="";
    synniaasta=0;
    ema=NULL;
    isa=NULL;
}

Inimene::Inimene(int sex, string ees, string pere, int aasta)
{
    sugu=sex;
    eesnimi=ees;
    perekonnanimi=pere;
    synniaasta=aasta;
    ema=NULL;
    isa=NULL;
}

Inimene::~Inimene(void)
{
    if (ema!=NULL)
    {
        delete ema;
    }
    if (isa!=NULL)
    {
        delete isa;
    }
}

void Inimene::output(int level, int sex)
{
    cout << indent(level);
    cout << "ID:            " << id << endl;
    cout << indent(level);
    cout << "Eesnimi:       " << eesnimi << endl;
    cout << indent(level);
    cout << "Perekonnanimi: " << perekonnanimi << endl;
    cout << indent(level);
    cout << "S�nniaasta:    " << synniaasta << endl;
    
    if (ema!=NULL && sex!=MEES)
    {
        cout << indent(level);
        cout << "Ema:" << endl;
        ema->output(level+4, sex);
    }
    if (isa!=NULL && sex!=NAINE)
    {
        cout << indent(level);
        cout << "Isa:" << endl;
        isa->output(level+4,sex);
    }
    return;
}



void Inimene::savetofile(string filename)
{
    ofstream f;
    f.open(filename.c_str());
    
    savetofile(&f,0);
    
    f.close();
    return;
}
    
void Inimene::savetofile(ofstream *f, int level)
{
    
    *f << level << endl;
    *f << sugu << endl;
    *f << eesnimi << endl;
    *f << perekonnanimi << endl;
    *f << synniaasta << endl;
    
    if (ema!=NULL)
    {
        ema->savetofile(f,level+1);
    }
    if (isa!=NULL)
    {
        isa->savetofile(f,level+1);
    }
    return;
}
    

string Inimene::indent(int level)
{
    int i;
    string sum;
    for (i=0;i<level;i++)
    {
        sum = sum + " ";
    }
    return sum;
}



void Inimene::loadfromfile(string filename)
{
    int lev;
    ifstream f;
    f.open(filename.c_str());
    
    f >> lev;
    f >> sugu;
    lev=loadfromfile(&f,0);
    
    f.close();
    return;
}

int Inimene::loadfromfile(ifstream *f, int level)
{
    string ees;
    string pere;
    int aasta;
    int lev;
    int sex;
    
    id=id_counter++;
    
    *f >> eesnimi;
    *f >> perekonnanimi;
    *f >> synniaasta;
    
    if (!f->eof())
    {
        *f >> lev;
        *f >> sex;
        
        
        if (lev > level && sex==NAINE)
        {
            ema=new Inimene(NAINE);
            lev=ema->loadfromfile(f,level+1);
        }
        if (lev > level)
        {
            isa=new Inimene(MEES);
            lev=isa->loadfromfile(f,level+1);
        }
                    
    }
    return lev;
}


int Inimene::grep(string search, int otsieesnime)
{
    int count=0;
    if (otsieesnime)
    {
        if (eesnimi==search)
        {
            count++;
        }
    }
    else
    {
        if (perekonnanimi==search)
        {
            count++;
        }
    }    
    
    if (ema!=NULL)
    {
        count+=ema->grep(search, otsieesnime);
    }
    if (isa!=NULL)
    {
        count+=isa->grep(search, otsieesnime);
    }
    return count;
}    


int Inimene::remove(int fid)
{
    if (isa!=NULL)
    {
        if (isa->id <= fid)
        {
            if (isa->id==fid)
            {
                delete isa;
                isa=NULL;
                return TRUE;
            }
            if (isa->remove(fid))
            {
                return TRUE;
            }
        }
    }
    if (ema!=NULL)
    {
        if (ema->id==fid)
        {
            delete ema;
            ema=NULL;
            return TRUE;
        }
        return ema->remove(fid);
    }
    return FALSE;
    
}

Inimene* Inimene::find(int fid)
{
    Inimene * result;
    if (fid==id)
    {
        return this;
    }
    
    if (isa!=NULL)
    {
        if (isa->id <= fid)
        {
            result=isa->find(fid);
            if (result!=NULL)
            {
                return result;
            }
        }
    }
    if (ema!=NULL)
    {
        return ema->find(fid);
    }
    return NULL;
}







