#ifndef INIMENE_H
#define INIMENE_H

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

const int MEES=0;
const int NAINE=1;
const int BOTH=-1;

const int FALSE=0;
const int TRUE=-1;



static int id_counter=0;

class Inimene;

class Inimene
{
  private:
    string indent(int level);
  
  public:
    int id;
    int sugu;
    string eesnimi;
    string perekonnanimi;
    int synniaasta;
    Inimene *ema;
    Inimene *isa;
    
    Inimene(void);
    Inimene(int sex);
    Inimene(int sex, string ees, string pere, int aasta);
    ~Inimene(void);
    void output(int level,int sex);
    void savetofile(string filename);
    void savetofile(ofstream *f, int level);
    void loadfromfile(string filename);
    int  loadfromfile(ifstream *f, int level);
    
    int grep(string search, int otsieesnime);
    
    int remove(int fid);
    
    Inimene* find(int fid);
    
  
};

#endif
