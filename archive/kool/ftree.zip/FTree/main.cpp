#include <iostream>
#include <string>
using namespace std;

#include "inimene.h"


const int NONE=0;
const int COUNT_FIRSTNAMES=1;
const int COUNT_LASTNAMES=2;
const int RENAME=3;
const int KILL=4;
const int ADD_FATHER=5;
const int ADD_MOTHER=6;


bool string2int(char* digit, int& result) {
   result = 0;

   //--- Convert each digit char and add into result.
   while (*digit >= '0' && *digit <='9') {
      result = (result * 10) + (*digit - '0');
      digit++;
   }

   //--- Check that there were no non-digits at end.
   if (*digit != 0) {
      return false;
   }

   return true;
}



int main(int argc, char *args[])
{
    Inimene * inimene = new Inimene();
    Inimene * p_inimene;
    string filename="";
    string search;
    int sex=BOTH;
    int action=NONE;
    int visual=FALSE;
    int visualize_id=0;
    int save=FALSE;
    int save_id=0;
    char option1=' ';
    char option2=' ';
    int i;
    int id=0;
    
    int year=0;
    string firstname="";
    string lastname="";
    
    if (argc>1)
    {
        
        for (i=1;i<argc;i++)
        {
            if (args[i][0]=='-')
            {
                option1=args[i][1];
                option2=args[i][2];
            }
            else
            {
                switch (option1)
                {
                    case 'v':
                    {
                        visual=TRUE;
                        string2int(args[i],visualize_id);
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 's':
                    {
                        save=TRUE;
                        string2int(args[i],save_id);
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'c':
                    {
                        if (option2=='f')
                        {
                            action=COUNT_FIRSTNAMES;
                        }
                        else
                        {
                            action=COUNT_LASTNAMES;
                        }
                        search=args[i];
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'a':
                    {
                        if (option2=='f')
                        {
                            action=ADD_FATHER;
                        }
                        else
                        {
                            action=ADD_MOTHER;
                        }
                        string2int(args[i],id);
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'x':
                    {
                        if (args[i][0]=='f')
                        {
                            sex=NAINE;
                        }
                        else
                        {
                            sex=MEES;
                        }
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'r':
                    {
                        action=RENAME;
                        string2int(args[i],id);
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'k':
                    {
                        action=KILL;
                        string2int(args[i],id);
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'f':
                    {
                        firstname=args[i];
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'l':
                    {
                        lastname=args[i];
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    case 'y':
                    {
                        string2int(args[i],year);
                        option1=' ';
                        option2=' ';
                    }
                    break;
                    default:
                    {
                        filename=args[i];
                    }
                }
            }
        }
        
        
        if (filename!="")
        {
            inimene->loadfromfile(filename);
            if (action==COUNT_FIRSTNAMES)
            {
                cout << "count: " << inimene->grep(search, true) << endl;
            }
            if (action==COUNT_LASTNAMES)
            {
                cout << "count: " << inimene->grep(search, false) << endl;
            }
            if (action==RENAME)
            {
                p_inimene = inimene->find(id);
                p_inimene->eesnimi=firstname;
                p_inimene->perekonnanimi=lastname;
                p_inimene->synniaasta=year;
                
            }
            if (action==KILL)
            {
                if (id==0)
                {
                    cout << "Kui soovid kõike eemaldada, siis parem kustuta juba kogu fail." << endl;
                    cout << "Mina ei kavatse 'rm'-i eest tema tööd ära tegema!!!" << endl;
                }
                else
                {
                    if (inimene->remove(id))
                    {
                        cout << "Edukalt eemaldatud!" << endl;
                    }
                }
            }
            
            if (action==ADD_FATHER)
            {
                p_inimene = inimene->find(id);
                if (p_inimene->isa!=NULL)
                {
                    delete p_inimene->isa;
                }
                p_inimene->isa=new Inimene(MEES, firstname, lastname, year);
            }
            
            if (action==ADD_MOTHER)
            {
                p_inimene = inimene->find(id);
                if (p_inimene->ema!=NULL)
                {
                    delete p_inimene->ema;
                }
                p_inimene->ema=new Inimene(NAINE, firstname, lastname, year);
            }
            
            if (visual==TRUE)
            {
                p_inimene = inimene->find(visualize_id);
                p_inimene->output(0,sex);
            }
            
            if (save==TRUE)
            {
                p_inimene = inimene->find(save_id);
                p_inimene->savetofile(filename);
            }
            
            
            delete inimene;
        }
        else
        {
            cout << "No filename specified!" << endl;
        }
    }
    else
    {
        cout << "Wrong parameters!" << endl;
        return 1;
    }
    
    
    return 0;

}
