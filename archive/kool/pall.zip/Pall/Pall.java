import java.awt.*;
import java.applet.Applet;

public class Pall extends Applet 
{
    public static void main(String[] argumendid){
        Frame f=new PallFrame();
        f.setSize(1024, 789);
        f.setVisible(true);
    }
}