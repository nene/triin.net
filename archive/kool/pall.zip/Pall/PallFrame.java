import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class PallFrame extends Frame implements MouseMotionListener, WindowListener, Runnable{
    
    XPall pall = new XPall(15);
    XPall old_pall = new XPall(15);
    XPall cursor = new XPall(100);
    
    public PallFrame()
    {
        addMouseMotionListener(this);
        addWindowListener(this);
        new Thread(this).start();
    }
    
    public void paint(Graphics g)
    {
        g.drawOval(pall.getLeft(), pall.getTop(), pall.d, pall.d);
//        g.drawOval(cursor.getLeft(), cursor.getTop(), cursor.d, cursor.d);
//        g.drawLine((int)pall.x, (int)pall.y, (int)cursor.x, (int)cursor.y);
    }
    
    public void changePosition()
    {
        double dx=cursor.x-pall.x;
        double dy=cursor.y-pall.y;
        double d=Math.sqrt(dx*dx + dy*dy);
        if (d>cursor.r)
        {
            double sina=dy/d;
            double cosa=dx/d;
            dx=Math.abs(d-cursor.r)*cosa;
            dy=Math.abs(d-cursor.r)*sina;
            //pall.x=cursor.x-dx;
            //pall.y=cursor.y-dy;
            pall.vx+=dx/10;
            pall.vy+=dy/10;
        }
        pall.vy+=2;
        pall.x+=pall.vx;
        pall.y+=pall.vy;
        if (pall.vx>0)
        {
            pall.vx--;
        }else{
            pall.vx++;
        }
        if (pall.vy>0)
        {
            pall.vy--;
        }else{
            pall.vy++;
        }
        
        
        // joonistame vaid siis kui asukoht on muutunud
        if (old_pall.x!=pall.x || old_pall.y!=pall.y)
        {
            repaint();
            old_pall.x=pall.x;
            old_pall.y=pall.y;
        }
    }
    
    
    public void mouseMoved(MouseEvent e)
    {
        Point p = e.getPoint();
        cursor.setLocation(p);
    }
    
    public void run()
    {
        while(true)
        {
            changePosition();
            try 
            {
                Thread.sleep(5);
            }catch (Exception e){}
        }
    }
    
    public void windowClosed(WindowEvent e) {}
    public void windowActivated(WindowEvent e) {}
    public void windowClosing(WindowEvent e) { System.exit(0); }
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowOpened(WindowEvent e) {}
    
    public void mouseDragged(MouseEvent e){}
    
}
