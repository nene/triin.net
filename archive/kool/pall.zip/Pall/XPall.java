import java.awt.*;

class XPall
{
    int r=0;
    int d=0;
    double x=200;
    double y=200;
    double vx=0;
    double vy=0;
    
    public XPall(int radius)
    {
        r=radius;
        d=radius*2;
    }
    
    public int getTop()
    {
        return (int)(y-r);
    }
    
    public int getLeft()
    {
        return (int)(x-r);
    }
    
    public void setLocation(Point p)
    {
        x=p.x;
        y=p.y;
    }
}